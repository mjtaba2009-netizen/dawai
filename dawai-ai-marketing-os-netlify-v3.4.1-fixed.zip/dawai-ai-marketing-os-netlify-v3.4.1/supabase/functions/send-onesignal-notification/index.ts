import { createClient } from 'npm:@supabase/supabase-js@2';

const jsonHeaders = { 'Content-Type': 'application/json' };

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: jsonHeaders });
}

async function sendWithRetry(url: string, init: RequestInit, attempts = 3) {
  let lastResponse: Response | null = null;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    lastResponse = await fetch(url, init);
    if (lastResponse.ok || (lastResponse.status < 500 && lastResponse.status !== 429)) return lastResponse;
    if (attempt < attempts) await new Promise((resolve) => setTimeout(resolve, 350 * 2 ** (attempt - 1)));
  }
  return lastResponse!;
}

Deno.serve(async (request) => {
  if (request.method !== 'POST') return response({ error: 'Method not allowed' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const oneSignalAppId = Deno.env.get('ONESIGNAL_APP_ID');
  const oneSignalApiKey = Deno.env.get('ONESIGNAL_API_KEY');
  const siteUrl = (Deno.env.get('DAWAI_SITE_URL') || 'https://aesthetic-syrniki-550b9a.netlify.app').replace(/\/$/, '');
  const webhookToken = request.headers.get('x-dawai-webhook-token') || '';

  if (!supabaseUrl || !serviceRoleKey || !oneSignalAppId || !oneSignalApiKey) {
    return response({ error: 'Missing server secrets' }, 500);
  }

  let body: { notification_id?: number | string };
  try { body = await request.json(); } catch { return response({ error: 'Invalid JSON' }, 400); }
  const notificationId = Number(body.notification_id);
  if (!Number.isInteger(notificationId) || notificationId <= 0) return response({ error: 'Invalid notification_id' }, 400);

  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: claim, error: claimError } = await admin.rpc('dawai_claim_push_notification_v30', {
    p_notification_id: notificationId,
    p_webhook_token: webhookToken,
  });

  if (claimError) return response({ error: claimError.message }, claimError.code === '42501' ? 401 : 500);
  if (!claim?.claimed) return response({ ok: true, skipped: true, reason: claim?.reason || 'already_processed' });

  const actionPath = typeof claim.action_url === 'string' && claim.action_url.startsWith('/') ? claim.action_url : '/notifications';
  const targetUrl = `${siteUrl}${actionPath}`;
  const title = String(claim.title || 'منصة دوائي');
  const message = String(claim.message || 'لديك إشعار جديد');

  try {
    const oneSignalResponse = await sendWithRetry('https://api.onesignal.com/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Key ${oneSignalApiKey}`,
      },
      body: JSON.stringify({
        app_id: oneSignalAppId,
        target_channel: 'push',
        include_aliases: { external_id: [String(claim.user_id)] },
        headings: { en: title, ar: title },
        contents: { en: message, ar: message },
        url: targetUrl,
        chrome_web_icon: `${siteUrl}/logo.png`,
        chrome_web_badge: `${siteUrl}/favicon-32x32.png`,
        firefox_icon: `${siteUrl}/logo.png`,
        data: {
          notification_id: notificationId,
          type: claim.type,
          action_url: actionPath,
        },
      }),
    });

    const oneSignalBody = await oneSignalResponse.json().catch(() => ({}));
    if (!oneSignalResponse.ok) {
      const errorMessage = typeof oneSignalBody?.errors === 'string'
        ? oneSignalBody.errors
        : JSON.stringify(oneSignalBody?.errors || oneSignalBody || { status: oneSignalResponse.status });
      await admin.rpc('dawai_complete_push_notification_v30', {
        p_notification_id: notificationId,
        p_webhook_token: webhookToken,
        p_status: 'failed',
        p_message_id: null,
        p_error: errorMessage.slice(0, 1500),
      });
      return response({ error: errorMessage }, 502);
    }

    const messageId = typeof oneSignalBody?.id === 'string' ? oneSignalBody.id : null;
    const finalStatus = messageId ? 'sent' : 'skipped';
    const noAudience = messageId ? null : 'No subscribed OneSignal user matched this external_id';
    await admin.rpc('dawai_complete_push_notification_v30', {
      p_notification_id: notificationId,
      p_webhook_token: webhookToken,
      p_status: finalStatus,
      p_message_id: messageId,
      p_error: noAudience,
    });

    return response({ ok: true, status: finalStatus, message_id: messageId });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown OneSignal error';
    await admin.rpc('dawai_complete_push_notification_v30', {
      p_notification_id: notificationId,
      p_webhook_token: webhookToken,
      p_status: 'failed',
      p_message_id: null,
      p_error: message.slice(0, 1500),
    }).catch(() => undefined);
    return response({ error: message }, 500);
  }
});
