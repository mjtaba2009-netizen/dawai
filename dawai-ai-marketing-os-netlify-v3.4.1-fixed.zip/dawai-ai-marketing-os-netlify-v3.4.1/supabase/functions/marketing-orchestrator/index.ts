import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const authHeader = request.headers.get('Authorization') ?? ''

    const userClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } })
    const { data: { user }, error: userError } = await userClient.auth.getUser()
    if (userError || !user) throw new Error('يجب تسجيل الدخول')

    const admin = createClient(supabaseUrl, serviceRoleKey)
    const { data: profile } = await admin.from('profiles').select('role').eq('id', user.id).single()
    if (profile?.role !== 'owner') throw new Error('هذه العملية متاحة لمالك المنصة فقط')

    const body = await request.json()
    const action = String(body.action ?? '')

    if (action === 'generate_week_plan') {
      const campaignId = String(body.campaign_id ?? '')
      const { data: campaign, error } = await admin.from('marketing_campaigns').select('*').eq('id', campaignId).single()
      if (error || !campaign) throw new Error('الحملة غير موجودة')

      const topics = [
        ['شنو هي Dawai؟', 'تدور على دواء وما تعرف وين متوفر؟ مع Dawai البحث صار أسهل.', 'reel'],
        ['البحث عن الدواء', 'شرح رحلة البحث بخطوات واضحة وبسيطة.', 'reel'],
        ['قارن واختر', 'وضح المقارنة عندما تتوفر بيانات السعر والمسافة ووقت التوصيل.', 'carousel'],
        ['خصوصية الوصفة', 'اشرح رفع الوصفة بخصوصية بدون عرض بيانات أي مريض.', 'story'],
        ['إعادة الطلب', 'عرض ميزة إعادة الطلب بصورة سريعة.', 'reel'],
        ['تذكيرات Dawai', 'شرح التذكيرات بدون نصيحة أو ادعاء طبي.', 'carousel'],
        ['اكتشف Dawai', 'دعوة واضحة لتجربة المنصة.', 'reel'],
      ]

      const rows = topics.map(([title, text, contentType], index) => {
        const date = new Date(`${campaign.start_date}T16:00:00.000Z`)
        date.setUTCDate(date.getUTCDate() + index)
        const channel = campaign.channels[index % campaign.channels.length] ?? 'instagram'
        return {
          campaign_id: campaign.id,
          title,
          body: text,
          content_type: channel === 'email' ? 'email' : contentType,
          channel,
          status: 'draft',
          scheduled_at: date.toISOString(),
          created_by: user.id,
        }
      })

      const { data, error: insertError } = await admin.from('marketing_content_items').insert(rows).select()
      if (insertError) throw insertError
      return Response.json({ success: true, items: data }, { headers: corsHeaders })
    }

    if (action === 'run_due_jobs') {
      const { data: jobs, error } = await admin
        .from('marketing_jobs')
        .select('*, marketing_content_items(*)')
        .eq('status', 'queued')
        .lte('run_after', new Date().toISOString())
        .limit(20)
      if (error) throw error

      // هذه النسخة لا تنشر خارجياً قبل إضافة OAuth الرسمي لكل قناة.
      // تسجّل الوظائف كـ failed برسالة واضحة بدلاً من تسريب توكنات أو استخدام كلمات مرور.
      for (const job of jobs ?? []) {
        await admin.from('marketing_jobs').update({
          status: 'failed',
          attempt_count: job.attempt_count + 1,
          last_error: 'القناة غير مربوطة عبر OAuth الرسمي بعد',
          updated_at: new Date().toISOString(),
        }).eq('id', job.id)
      }
      return Response.json({ success: true, processed: jobs?.length ?? 0 }, { headers: corsHeaders })
    }

    throw new Error('الإجراء غير مدعوم')
  } catch (error) {
    return Response.json({ success: false, error: error instanceof Error ? error.message : 'خطأ غير معروف' }, { status: 400, headers: corsHeaders })
  }
})
