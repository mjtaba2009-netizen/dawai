begin;

create extension if not exists pgcrypto;

create table if not exists public.marketing_brand_profiles (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Dawai',
  tagline text not null default 'دواؤك أقرب',
  primary_language text not null default 'ar-IQ',
  tone jsonb not null default '{"style":"clear, trustworthy, modern","avoid":["unverified medical claims","invented partnerships","invented numbers"]}'::jsonb,
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.marketing_channels (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider in ('instagram','tiktok','email')),
  display_name text not null,
  status text not null default 'disconnected' check (status in ('disconnected','pending','connected','error')),
  external_account_id text,
  config jsonb not null default '{}'::jsonb,
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider, external_account_id)
);

create table if not exists public.marketing_campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  objective text not null,
  audience text not null,
  channels text[] not null default '{}',
  status text not null default 'draft' check (status in ('draft','active','paused','completed','archived')),
  progress integer not null default 0 check (progress between 0 and 100),
  start_date date not null,
  end_date date not null,
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (end_date >= start_date)
);

alter table public.marketing_campaigns add column if not exists progress integer not null default 0;

create table if not exists public.marketing_content_items (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid references public.marketing_campaigns(id) on delete cascade,
  title text not null,
  body text not null,
  content_type text not null check (content_type in ('reel','story','carousel','email','static_post')),
  channel text not null check (channel in ('instagram','tiktok','email')),
  status text not null default 'draft' check (status in ('draft','review','approved','scheduled','publishing','published','failed','rejected')),
  scheduled_at timestamptz,
  published_at timestamptz,
  external_post_id text,
  compliance jsonb not null default '{"owner_approval_required":true,"medical_claims_checked":false,"privacy_checked":false}'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists marketing_content_schedule_idx on public.marketing_content_items(status, scheduled_at);
create index if not exists marketing_content_campaign_idx on public.marketing_content_items(campaign_id);

create table if not exists public.marketing_approvals (
  id uuid primary key default gen_random_uuid(),
  content_id uuid not null references public.marketing_content_items(id) on delete cascade,
  decision text not null check (decision in ('approved','rejected','changes_requested')),
  note text,
  decided_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  decided_at timestamptz not null default now()
);

create table if not exists public.marketing_assets (
  id uuid primary key default gen_random_uuid(),
  content_id uuid references public.marketing_content_items(id) on delete set null,
  storage_path text not null,
  mime_type text,
  license_status text not null default 'owned' check (license_status in ('owned','licensed','pending_review')),
  metadata jsonb not null default '{}'::jsonb,
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.marketing_jobs (
  id uuid primary key default gen_random_uuid(),
  content_id uuid references public.marketing_content_items(id) on delete cascade,
  job_type text not null check (job_type in ('generate_plan','generate_copy','render_asset','publish','sync_metrics','send_email')),
  status text not null default 'queued' check (status in ('queued','running','completed','failed','cancelled')),
  run_after timestamptz not null default now(),
  attempt_count integer not null default 0,
  max_attempts integer not null default 3,
  payload jsonb not null default '{}'::jsonb,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists marketing_jobs_queue_idx on public.marketing_jobs(status, run_after);

create table if not exists public.marketing_metrics (
  id bigint generated by default as identity primary key,
  content_id uuid not null references public.marketing_content_items(id) on delete cascade,
  measured_at timestamptz not null default now(),
  impressions bigint not null default 0,
  reach bigint not null default 0,
  views bigint not null default 0,
  likes bigint not null default 0,
  comments bigint not null default 0,
  shares bigint not null default 0,
  saves bigint not null default 0,
  clicks bigint not null default 0,
  conversions bigint not null default 0,
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.marketing_email_contacts (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  display_name text,
  consent_source text not null,
  consented_at timestamptz not null,
  unsubscribed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.dawai_marketing_is_owner()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'owner'
  );
$$;

create or replace function public.dawai_marketing_approve_content(p_content_id uuid, p_decision text, p_note text default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.dawai_marketing_is_owner() then
    raise exception using message = 'هذه العملية متاحة لمالك المنصة فقط', errcode = '42501';
  end if;
  if p_decision not in ('approved','rejected','changes_requested') then
    raise exception using message = 'قرار الموافقة غير صالح', errcode = '22023';
  end if;

  insert into public.marketing_approvals(content_id, decision, note)
  values (p_content_id, p_decision, p_note);

  update public.marketing_content_items
  set status = case p_decision when 'approved' then 'approved' when 'rejected' then 'rejected' else 'draft' end,
      compliance = compliance || jsonb_build_object('owner_approved', p_decision = 'approved', 'owner_approved_at', now()),
      updated_at = now()
  where id = p_content_id;

  if not found then
    raise exception using message = 'المحتوى غير موجود', errcode = 'P0002';
  end if;

  return jsonb_build_object('success', true, 'decision', p_decision);
end;
$$;

create or replace function public.dawai_marketing_queue_publish(p_content_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_status text;
  v_scheduled timestamptz;
begin
  if not public.dawai_marketing_is_owner() then
    raise exception using message = 'هذه العملية متاحة لمالك المنصة فقط', errcode = '42501';
  end if;

  select status, scheduled_at into v_status, v_scheduled
  from public.marketing_content_items
  where id = p_content_id
  for update;

  if not found then raise exception using message = 'المحتوى غير موجود', errcode = 'P0002'; end if;
  if v_status not in ('approved','scheduled') then
    raise exception using message = 'يجب الموافقة على المحتوى قبل النشر', errcode = 'P0001';
  end if;

  insert into public.marketing_jobs(content_id, job_type, status, run_after)
  values (p_content_id, 'publish', 'queued', coalesce(v_scheduled, now()));

  update public.marketing_content_items
  set status = 'scheduled', updated_at = now()
  where id = p_content_id;

  return jsonb_build_object('success', true, 'queued_for', coalesce(v_scheduled, now()));
end;
$$;

alter table public.marketing_brand_profiles enable row level security;
alter table public.marketing_channels enable row level security;
alter table public.marketing_campaigns enable row level security;
alter table public.marketing_content_items enable row level security;
alter table public.marketing_approvals enable row level security;
alter table public.marketing_assets enable row level security;
alter table public.marketing_jobs enable row level security;
alter table public.marketing_metrics enable row level security;
alter table public.marketing_email_contacts enable row level security;

do $$
declare t text;
begin
  foreach t in array array[
    'marketing_brand_profiles','marketing_channels','marketing_campaigns','marketing_content_items',
    'marketing_approvals','marketing_assets','marketing_jobs','marketing_metrics','marketing_email_contacts'
  ] loop
    execute format('drop policy if exists dawai_marketing_owner_all on public.%I', t);
    execute format(
      'create policy dawai_marketing_owner_all on public.%I for all to authenticated using (public.dawai_marketing_is_owner()) with check (public.dawai_marketing_is_owner())',
      t
    );
  end loop;
end $$;

grant execute on function public.dawai_marketing_approve_content(uuid,text,text) to authenticated;
grant execute on function public.dawai_marketing_queue_publish(uuid) to authenticated;

insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('marketing-assets', 'marketing-assets', false, 52428800, array['image/jpeg','image/png','image/webp','video/mp4'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists dawai_marketing_assets_owner_storage on storage.objects;
create policy dawai_marketing_assets_owner_storage on storage.objects
for all to authenticated
using (bucket_id = 'marketing-assets' and public.dawai_marketing_is_owner())
with check (bucket_id = 'marketing-assets' and public.dawai_marketing_is_owner());

notify pgrst, 'reload schema';
commit;
