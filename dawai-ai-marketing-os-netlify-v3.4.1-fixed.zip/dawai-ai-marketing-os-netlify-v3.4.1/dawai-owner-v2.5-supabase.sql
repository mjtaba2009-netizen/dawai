-- منصة دوائي 2.5
-- إصلاح حذف الصيدليات والكوزمتك وعرض نتيجة واضحة للتطبيق.
-- شغّل هذا الملف كاملاً مرة واحدة داخل Supabase > SQL Editor.

begin;

-- التأكد من أن قيد أدوار profiles يسمح بـ owner و patient
-- مع الاحتفاظ بجميع القيم القديمة الموجودة في القيد.
do $$
declare
  item record;
  definition text;
  expression text;
begin
  for item in
    select c.conname, c.oid
    from pg_constraint c
    where c.conrelid = 'public.profiles'::regclass
      and c.contype = 'c'
      and pg_get_constraintdef(c.oid) ilike '%role%'
  loop
    definition := pg_get_constraintdef(item.oid);
    expression := regexp_replace(definition, '^CHECK \((.*)\)$', '\1');

    execute format('alter table public.profiles drop constraint %I', item.conname);
    execute format(
      'alter table public.profiles add constraint %I check ((%s) or role in (%L, %L))',
      item.conname,
      expression,
      'owner',
      'patient'
    );
  end loop;
end
$$;

-- التأكد من أن قيد حالة المتجر يسمح بالحالة deleted.
do $$
declare
  item record;
  definition text;
  expression text;
begin
  for item in
    select c.conname, c.oid
    from pg_constraint c
    where c.conrelid = 'public.pharmacies'::regclass
      and c.contype = 'c'
      and pg_get_constraintdef(c.oid) ilike '%status%'
  loop
    definition := pg_get_constraintdef(item.oid);

    if definition not ilike '%deleted%' then
      expression := regexp_replace(definition, '^CHECK \((.*)\)$', '\1');
      execute format('alter table public.pharmacies drop constraint %I', item.conname);
      execute format(
        'alter table public.pharmacies add constraint %I check ((%s) or status = %L)',
        item.conname,
        expression,
        'deleted'
      );
    end if;
  end loop;
end
$$;

-- دالة حذف آمن جديدة باسم مختلف لتجنب مشكلة ذاكرة مخطط PostgREST القديمة.
create or replace function public.dawai_owner_delete_vendor_v2(p_vendor_id text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_vendor_id bigint;
  v_owner_id uuid;
  v_vendor_name text;
  v_notification_warning text := null;
begin
  -- التحقق من جلسة المستخدم وصلاحية المالك مباشرة.
  if auth.uid() is null then
    raise exception using message = 'يجب تسجيل الدخول أولاً', errcode = '42501';
  end if;

  if not exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and role = 'owner'
  ) then
    raise exception using message = 'هذه العملية متاحة لمالك المنصة فقط', errcode = '42501';
  end if;

  if p_vendor_id is null or btrim(p_vendor_id) !~ '^[0-9]+$' then
    raise exception using message = 'معرّف المتجر غير صالح', errcode = '22023';
  end if;

  v_vendor_id := p_vendor_id::bigint;

  select owner_id, name
  into v_owner_id, v_vendor_name
  from public.pharmacies
  where id = v_vendor_id
    and coalesce(status, '') <> 'deleted'
  for update;

  if not found then
    raise exception using message = 'المتجر غير موجود أو محذوف مسبقاً', errcode = 'P0002';
  end if;

  update public.pharmacies
  set status = 'deleted'
  where id = v_vendor_id;

  -- تحديث is_open فقط إذا كان العمود موجوداً.
  if exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'pharmacies'
      and column_name = 'is_open'
  ) then
    execute 'update public.pharmacies set is_open = false where id = $1'
    using v_vendor_id;
  end if;

  -- يعاد حساب صاحب المتجر إلى مستخدم عادي.
  if v_owner_id is not null then
    update public.profiles
    set role = 'patient',
        status = 'active',
        pharmacy_id = null
    where id = v_owner_id
      and role in ('pharmacy', 'cosmetic');
  end if;

  -- فشل الإشعار لا يلغي عملية حذف المتجر.
  if v_owner_id is not null then
    begin
      insert into public.notifications (user_id, title, message, type, is_read)
      values (
        v_owner_id,
        'تم حذف المتجر من المنصة',
        'تم حذف ' || coalesce(v_vendor_name, 'المتجر') || ' من منصة دوائي. يمكنك الاستمرار باستخدام حسابك كمستخدم عادي.',
        'vendor_approval',
        false
      );
    exception when others then
      v_notification_warning := sqlerrm;
    end;
  end if;

  return jsonb_build_object(
    'success', true,
    'vendor_id', v_vendor_id,
    'vendor_name', v_vendor_name,
    'notification_warning', v_notification_warning
  );
end;
$$;

revoke all on function public.dawai_owner_delete_vendor_v2(text) from public;
grant execute on function public.dawai_owner_delete_vendor_v2(text) to authenticated;

-- تحديث مخطط PostgREST مباشرة بعد إنشاء الدالة.
notify pgrst, 'reload schema';

commit;

-- فحص وجود الدالة بعد التنفيذ.
select
  routine_name,
  data_type
from information_schema.routines
where routine_schema = 'public'
  and routine_name = 'dawai_owner_delete_vendor_v2';
