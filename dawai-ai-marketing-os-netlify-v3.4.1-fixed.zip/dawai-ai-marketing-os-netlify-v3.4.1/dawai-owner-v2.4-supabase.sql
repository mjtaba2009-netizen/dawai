-- دوائي 2.4: حذف المتاجر من المنصة وصلاحيات حساب المالك المزدوج
-- شغّل هذا الكود مرة واحدة داخل Supabase > SQL Editor.

begin;

-- إضافة حالة deleted إلى قيد حالة الصيدليات/الكوزمتك، مع الحفاظ على الحالات الحالية.
do $$
declare
  item record;
  constraint_definition text;
  constraint_expression text;
begin
  for item in
    select c.conname, c.oid
    from pg_constraint c
    where c.conrelid = 'public.pharmacies'::regclass
      and c.contype = 'c'
      and pg_get_constraintdef(c.oid) ilike '%status%'
  loop
    constraint_definition := pg_get_constraintdef(item.oid);

    if constraint_definition not ilike '%deleted%' then
      -- إزالة CHECK ( من البداية والقوس الأخير فقط.
      constraint_expression := substring(
        constraint_definition from 8 for char_length(constraint_definition) - 8
      );

      execute format(
        'alter table public.pharmacies drop constraint %I',
        item.conname
      );

      execute format(
        'alter table public.pharmacies add constraint %I check ((%s) or status = %L)',
        item.conname,
        constraint_expression,
        'deleted'
      );
    end if;
  end loop;
end
$$;

-- حذف آمن من المنصة: يخفي المتجر ويحافظ على سجل الطلبات السابقة.
-- حساب صاحب المتجر يرجع إلى حساب مستخدم عادي بعد الحذف.
create or replace function public.dawai_owner_delete_vendor(p_vendor_id bigint)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  vendor_owner_id uuid;
  vendor_name text;
begin
  if not public.dawai_is_platform_owner() then
    raise exception 'هذه العملية متاحة لمالك المنصة فقط';
  end if;

  select owner_id, name
  into vendor_owner_id, vendor_name
  from public.pharmacies
  where id = p_vendor_id
    and coalesce(status, '') <> 'deleted'
  for update;

  if not found then
    raise exception 'المتجر غير موجود أو محذوف مسبقاً';
  end if;

  update public.pharmacies
  set status = 'deleted'
  where id = p_vendor_id;

  -- بعض النسخ القديمة قد لا تحتوي عمود is_open، لذلك يُحدّث بشكل اختياري.
  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public'
      and table_name = 'pharmacies'
      and column_name = 'is_open'
  ) then
    execute 'update public.pharmacies set is_open = false where id = $1'
    using p_vendor_id;
  end if;

  update public.profiles
  set role = 'patient',
      status = 'active',
      pharmacy_id = null
  where id = vendor_owner_id
    and role in ('pharmacy', 'cosmetic');

  if vendor_owner_id is not null then
    insert into public.notifications (
      user_id,
      title,
      message,
      type,
      is_read
    ) values (
      vendor_owner_id,
      'تم حذف المتجر من المنصة',
      'تم حذف ' || coalesce(vendor_name, 'المتجر') || ' من منصة دوائي. ما زال بإمكانك استخدام حسابك كمستخدم عادي.',
      'vendor_approval',
      false
    );
  end if;
end;
$$;

revoke all on function public.dawai_owner_delete_vendor(bigint) from public;
grant execute on function public.dawai_owner_delete_vendor(bigint) to authenticated;

commit;
