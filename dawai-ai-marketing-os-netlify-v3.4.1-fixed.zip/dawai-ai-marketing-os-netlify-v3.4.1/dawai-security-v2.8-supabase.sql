begin;

-- ============================================================
-- منصة دوائي 2.8: التوثيق، حماية الوصفات، سجل الطلب، النزاعات،
-- أصالة المنتجات، التقييمات، سجل المالك، OTP/MFA policies.
-- يبدأ الملف مباشرة بـ begin; حتى يمكن نسخه بأمان إلى SQL Editor.
-- ============================================================

create extension if not exists pgcrypto;

-- 1) أعمدة التوثيق والأمان
alter table public.pharmacies add column if not exists verification_status text not null default 'not_submitted';
alter table public.pharmacies add column if not exists license_number text;
alter table public.pharmacies add column if not exists license_expires_at date;
alter table public.pharmacies add column if not exists verified_at timestamptz;
alter table public.pharmacies add column if not exists verified_by uuid;
alter table public.pharmacies add column if not exists verification_notes text;
alter table public.pharmacies add column if not exists suspended_at timestamptz;
alter table public.pharmacies add column if not exists suspension_reason text;

alter table public.medications add column if not exists manufacturer text;
alter table public.medications add column if not exists country_of_origin text;
alter table public.medications add column if not exists batch_number text;
alter table public.medications add column if not exists expiry_date date;
alter table public.medications add column if not exists original_price numeric(14,2);
alter table public.medications add column if not exists authenticity_status text not null default 'unverified';

alter table public.orders add column if not exists payment_method text not null default 'cash_on_delivery';
alter table public.orders add column if not exists client_request_id uuid;
alter table public.orders add column if not exists received_at timestamptz;

alter table public.notifications add column if not exists dedupe_key text;
alter table public.notifications add column if not exists action_url text;

alter table public.prescriptions add column if not exists review_notes text;
alter table public.prescriptions add column if not exists reviewed_by uuid;
alter table public.prescriptions add column if not exists reviewed_at timestamptz;
alter table public.prescriptions add column if not exists deleted_at timestamptz;

-- توافق الأدوار والحالات مع الإصدارات السابقة، حتى يكون ملف 2.8 قابلاً للتشغيل بأمان بعد 2.7.
do $$
declare item record; definition text; expression text;
begin
  for item in select conname, oid from pg_constraint
    where conrelid='public.profiles'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%role%'
  loop
    definition:=pg_get_constraintdef(item.oid);
    if definition not ilike '%owner%' or definition not ilike '%patient%' then
      expression:=regexp_replace(definition,'^CHECK \((.*)\)$','\1');
      execute format('alter table public.profiles drop constraint %I',item.conname);
      execute format('alter table public.profiles add constraint %I check ((%s) or role in (%L,%L))',item.conname,expression,'owner','patient');
    end if;
  end loop;

  for item in select conname, oid from pg_constraint
    where conrelid='public.pharmacies'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%status%'
      and pg_get_constraintdef(oid) not ilike '%verification_status%'
  loop
    definition:=pg_get_constraintdef(item.oid);
    if definition not ilike '%deleted%' then
      expression:=regexp_replace(definition,'^CHECK \((.*)\)$','\1');
      execute format('alter table public.pharmacies drop constraint %I',item.conname);
      execute format('alter table public.pharmacies add constraint %I check ((%s) or status=%L)',item.conname,expression,'deleted');
    end if;
  end loop;

  for item in select conname, oid from pg_constraint
    where conrelid='public.orders'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%status%'
  loop
    definition:=pg_get_constraintdef(item.oid);
    if definition not ilike '%received%' then
      expression:=regexp_replace(definition,'^CHECK \((.*)\)$','\1');
      execute format('alter table public.orders drop constraint %I',item.conname);
      execute format('alter table public.orders add constraint %I check ((%s) or status in (%L,%L,%L,%L,%L,%L,%L))',
        item.conname,expression,'pending','confirmed','ready','received','completed','cancelled','rejected');
    end if;
  end loop;

  for item in select conname, oid from pg_constraint
    where conrelid='public.notifications'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%type%'
  loop
    definition:=pg_get_constraintdef(item.oid);
    if definition not ilike '%dispute%' or definition not ilike '%prescription%' then
      expression:=regexp_replace(definition,'^CHECK \((.*)\)$','\1');
      execute format('alter table public.notifications drop constraint %I',item.conname);
      execute format('alter table public.notifications add constraint %I check ((%s) or type in (%L,%L,%L,%L,%L,%L,%L))',
        item.conname,expression,'new_order','order_update','vendor_approval','prescription','dispute','security','reminder');
    end if;
  end loop;
end $$;

-- إزالة قيود CHECK القديمة الضيقة ثم إضافة قيود مرنة ومعروفة.
do $$
declare item record;
begin
  for item in select conname from pg_constraint
    where conrelid='public.pharmacies'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%verification_status%'
  loop execute format('alter table public.pharmacies drop constraint %I', item.conname); end loop;
  for item in select conname from pg_constraint
    where conrelid='public.medications'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%authenticity_status%'
  loop execute format('alter table public.medications drop constraint %I', item.conname); end loop;
  for item in select conname from pg_constraint
    where conrelid='public.orders'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%payment_method%'
  loop execute format('alter table public.orders drop constraint %I', item.conname); end loop;
  for item in select conname from pg_constraint
    where conrelid='public.prescriptions'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%status%'
  loop execute format('alter table public.prescriptions drop constraint %I', item.conname); end loop;
end $$;

alter table public.pharmacies add constraint pharmacies_verification_status_v28_check
  check (verification_status in ('not_submitted','submitted','verified','rejected','suspended','expired'));
alter table public.medications add constraint medications_authenticity_v28_check
  check (authenticity_status in ('unverified','declared_original','verified','flagged'));
alter table public.orders add constraint orders_payment_method_v28_check
  check (payment_method in ('cash_on_delivery','wallet','card_on_delivery'));
alter table public.prescriptions add constraint prescriptions_status_v28_check
  check (status in ('submitted','approved','reviewed','rejected','needs_clarification','deleted'));

create unique index if not exists orders_user_client_request_v28_idx
  on public.orders(user_id, client_request_id) where client_request_id is not null;
create unique index if not exists notifications_user_dedupe_v28_idx
  on public.notifications(user_id, dedupe_key) where dedupe_key is not null;

-- المتاجر المقبولة سابقاً تعتبر موثقة، والمتاجر الجديدة تبقى submitted.
update public.pharmacies set verification_status='verified', verified_at=coalesce(verified_at, now())
where status='approved' and verification_status='not_submitted';
update public.pharmacies set verification_status='submitted'
where coalesce(status,'pending')='pending' and verification_status='not_submitted'
  and (license_number is not null or license_expires_at is not null);

-- 2) جداول التوثيق والسجلات والدعم
create table if not exists public.vendor_documents (
  id bigint generated by default as identity primary key,
  pharmacy_id bigint not null references public.pharmacies(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  document_type text not null default 'license',
  file_path text not null,
  license_number text,
  expires_at date,
  status text not null default 'submitted' check (status in ('submitted','approved','rejected','expired')),
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_notes text,
  created_at timestamptz not null default now()
);
create index if not exists vendor_documents_vendor_idx on public.vendor_documents(pharmacy_id, created_at desc);

create table if not exists public.order_status_history (
  id bigint generated by default as identity primary key,
  order_id bigint not null references public.orders(id) on delete cascade,
  old_status text,
  new_status text not null,
  note text,
  changed_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists order_status_history_order_idx on public.order_status_history(order_id, created_at);

create table if not exists public.order_disputes (
  id bigint generated by default as identity primary key,
  order_id bigint not null references public.orders(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  reason text not null,
  description text,
  evidence_path text,
  status text not null default 'open' check (status in ('open','under_review','resolved','rejected')),
  owner_response text,
  resolved_by uuid,
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists order_disputes_one_open_idx on public.order_disputes(order_id)
  where status in ('open','under_review');

create table if not exists public.product_reports (
  id bigint generated by default as identity primary key,
  medication_id bigint not null references public.medications(id) on delete cascade,
  pharmacy_id bigint references public.pharmacies(id) on delete set null,
  order_id bigint references public.orders(id) on delete set null,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  reason text not null,
  details text,
  evidence_path text,
  status text not null default 'open' check (status in ('open','under_review','resolved','dismissed')),
  owner_notes text,
  resolved_by uuid,
  resolved_at timestamptz,
  created_at timestamptz not null default now()
);

-- توافق مع أي محاولة تشغيل سابقة لملف 2.8.
alter table public.order_disputes add column if not exists description text;
alter table public.order_disputes alter column user_id set default auth.uid();
alter table public.product_reports alter column user_id set default auth.uid();
do $$
begin
  if exists(select 1 from information_schema.columns where table_schema='public' and table_name='order_disputes' and column_name='details') then
    execute 'update public.order_disputes set description=coalesce(description,details) where description is null';
  end if;
end $$;

create table if not exists public.product_ratings (
  id bigint generated by default as identity primary key,
  order_id bigint not null unique references public.orders(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  pharmacy_id bigint not null references public.pharmacies(id) on delete cascade,
  medication_id bigint references public.medications(id) on delete set null,
  rating integer not null check (rating between 1 and 5),
  speed_rating integer check (speed_rating between 1 and 5),
  packaging_rating integer check (packaging_rating between 1 and 5),
  match_rating integer check (match_rating between 1 and 5),
  comment text,
  status text not null default 'pending' check (status in ('pending','published','hidden')),
  moderated_by uuid,
  moderated_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.owner_audit_logs (
  id bigint generated by default as identity primary key,
  owner_id uuid not null references auth.users(id) on delete cascade,
  action text not null,
  target_type text not null,
  target_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists owner_audit_logs_created_idx on public.owner_audit_logs(created_at desc);

create table if not exists public.security_events (
  id bigint generated by default as identity primary key,
  user_id uuid references auth.users(id) on delete cascade default auth.uid(),
  event_type text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- 3) دلائل الصلاحية
create or replace function public.dawai_has_aal2()
returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(auth.jwt()->>'aal','aal1')='aal2'; $$;

create or replace function public.dawai_is_vendor_owner(p_vendor_id bigint)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.pharmacies where id=p_vendor_id and owner_id=auth.uid()); $$;

create or replace function public.dawai_audit(p_action text, p_entity_type text, p_entity_id text, p_details jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path=public as $$
begin
  if public.dawai_is_platform_owner() then
    insert into public.owner_audit_logs(owner_id,action,target_type,target_id,details)
    values(auth.uid(),p_action,p_entity_type,p_entity_id,coalesce(p_details,'{}'::jsonb));
  end if;
end $$;

-- 4) سجل حالات الطلب تلقائياً
create or replace function public.dawai_order_history_trigger_v28()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if tg_op='INSERT' or old.status is distinct from new.status then
    insert into public.order_status_history(order_id,old_status,new_status,note,changed_by)
    values(new.id,case when tg_op='UPDATE' then old.status else null end,new.status,case when tg_op='INSERT' then 'تم إنشاء الطلب' else null end,auth.uid());
  end if;
  return new;
end $$;
drop trigger if exists dawai_order_history_trigger on public.orders;
create trigger dawai_order_history_trigger after insert or update of status on public.orders
for each row execute function public.dawai_order_history_trigger_v28();

insert into public.order_status_history(order_id,old_status,new_status,note,changed_by,created_at)
select o.id,null,o.status,'سجل أولي',o.user_id,o.created_at from public.orders o
where not exists(select 1 from public.order_status_history h where h.order_id=o.id);

-- 5) إنشاء طلب: منع التكرار، طريقة الدفع، متجر موثق فقط
create or replace function public.dawai_create_order_v28(
  p_pharmacy_id bigint,
  p_medication_id bigint,
  p_quantity integer,
  p_prescription_id bigint default null,
  p_coupon_code text default null,
  p_redeem_points integer default 0,
  p_payment_method text default 'cash_on_delivery',
  p_client_request_id uuid default gen_random_uuid()
)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  v_uid uuid:=auth.uid(); v_existing public.orders%rowtype; v_price numeric; v_stock integer;
  v_requires boolean; v_vendor_status text; v_verify text; v_owner uuid; v_subtotal numeric;
  v_quote jsonb; v_points integer; v_coupon_discount numeric; v_total_discount numeric;
  v_delivery numeric; v_total numeric; v_order_id bigint; v_tracking text; v_updated integer; v_coupon_id bigint;
begin
  if v_uid is null then raise exception using message='يجب تسجيل الدخول لإنشاء الطلب',errcode='42501'; end if;
  if p_payment_method not in ('cash_on_delivery','wallet','card_on_delivery') then raise exception using message='طريقة الدفع غير صالحة',errcode='22023'; end if;
  select * into v_existing from public.orders where user_id=v_uid and client_request_id=p_client_request_id limit 1;
  if found then return jsonb_build_object('success',true,'order_id',v_existing.id,'tracking_code',v_existing.tracking_code,'total',v_existing.total_price,'duplicate_prevented',true); end if;

  select pm.price,pm.quantity,m.requires_prescription,ph.status,ph.verification_status,ph.owner_id
  into v_price,v_stock,v_requires,v_vendor_status,v_verify,v_owner
  from public.pharmacy_medications pm join public.medications m on m.id=pm.medication_id
  join public.pharmacies ph on ph.id=pm.pharmacy_id
  where pm.pharmacy_id=p_pharmacy_id and pm.medication_id=p_medication_id limit 1 for update of pm;
  if not found then raise exception using message='المنتج غير متوفر في هذا المتجر',errcode='P0002'; end if;
  if v_vendor_status<>'approved' or v_verify<>'verified' then raise exception using message='المتجر غير موثّق أو غير متاح حالياً',errcode='P0001'; end if;
  if coalesce(v_stock,0)<greatest(coalesce(p_quantity,1),1) then raise exception using message='الكمية المطلوبة غير متوفرة',errcode='P0001'; end if;
  if coalesce(v_requires,false) and (p_prescription_id is null or not exists(select 1 from public.prescriptions where id=p_prescription_id and user_id=v_uid and status<>'deleted')) then
    raise exception using message='يجب رفع وصفة طبية صالحة لهذا الدواء',errcode='P0001';
  end if;

  v_subtotal:=coalesce(v_price,0)*greatest(coalesce(p_quantity,1),1);
  v_quote:=public.dawai_quote_order_v27(p_pharmacy_id,v_subtotal,p_coupon_code,p_redeem_points);
  if nullif(btrim(coalesce(p_coupon_code,'')),'') is not null and not coalesce((v_quote->>'valid')::boolean,false) then raise exception using message=coalesce(v_quote->>'message','الكوبون غير صالح'),errcode='P0001'; end if;
  v_points:=coalesce((v_quote->>'points_to_use')::integer,0);
  v_coupon_discount:=coalesce((v_quote->>'coupon_discount')::numeric,0);
  v_delivery:=coalesce((v_quote->>'delivery_fee')::numeric,0);
  v_total:=coalesce((v_quote->>'total')::numeric,v_subtotal+v_delivery);
  v_total_discount:=v_coupon_discount+coalesce((v_quote->>'points_discount')::numeric,0)+coalesce((v_quote->>'subscription_discount')::numeric,0);
  v_coupon_id:=nullif(v_quote->>'coupon_id','')::bigint;
  v_tracking:='#DW-'||lpad((floor(random()*9000)+1000)::integer::text,4,'0');

  if v_points>0 then
    insert into public.loyalty_wallets(user_id,points) values(v_uid,0) on conflict(user_id) do nothing;
    update public.loyalty_wallets set points=points-v_points,lifetime_redeemed=lifetime_redeemed+v_points,updated_at=now() where user_id=v_uid and points>=v_points;
    get diagnostics v_updated=row_count;
    if v_updated=0 then raise exception using message='رصيد نقاط الولاء غير كافٍ',errcode='P0001'; end if;
  end if;

  insert into public.orders(user_id,pharmacy_id,medication_id,quantity,subtotal,discount_amount,delivery_fee,total_price,coupon_code,loyalty_points_redeemed,prescription_id,tracking_code,status,payment_method,client_request_id)
  values(v_uid,p_pharmacy_id,p_medication_id,greatest(coalesce(p_quantity,1),1),v_subtotal,v_total_discount,v_delivery,v_total,nullif(upper(btrim(coalesce(p_coupon_code,''))),''),v_points,p_prescription_id,v_tracking,'pending',p_payment_method,p_client_request_id)
  returning id into v_order_id;

  if v_coupon_id is not null and v_coupon_discount>0 then
    insert into public.coupon_redemptions(coupon_id,user_id,order_id,discount_amount) values(v_coupon_id,v_uid,v_order_id,v_coupon_discount);
    update public.coupons set usage_count=usage_count+1 where id=v_coupon_id;
  end if;
  if v_points>0 then insert into public.loyalty_transactions(user_id,points,type,order_id,description) values(v_uid,-v_points,'redeem',v_order_id,'استبدال نقاط'); end if;

  if v_owner is not null then
    insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
    values(v_owner,'طلب جديد وصل لمتجرك','وصلك طلب جديد برقم '||v_tracking||'.','new_order',false,'new_order:'||v_order_id,'/dashboard')
    on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  end if;
  return jsonb_build_object('success',true,'order_id',v_order_id,'tracking_code',v_tracking,'total',v_total);
end $$;

-- 6) تغيير حالة الطلب بصلاحيات واضحة وموافقة الوصفة قبل القبول
create or replace function public.dawai_update_order_status_v28(p_order_id bigint,p_status text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_order public.orders%rowtype; v_vendor_owner uuid; v_requires boolean; v_prescription_status text; v_message text;
begin
  select o,ph.owner_id into v_order,v_vendor_owner from public.orders o join public.pharmacies ph on ph.id=o.pharmacy_id where o.id=p_order_id for update of o;
  if not found then raise exception using message='الطلب غير موجود',errcode='P0002'; end if;
  if p_status not in ('pending','confirmed','ready','received','completed','cancelled','rejected') then raise exception using message='حالة الطلب غير صالحة',errcode='22023'; end if;
  if auth.uid()=v_order.user_id then
    if p_status not in ('received','cancelled') then raise exception using message='لا تملك صلاحية تغيير هذه الحالة',errcode='42501'; end if;
  elsif auth.uid()=v_vendor_owner then
    if p_status not in ('confirmed','ready','completed','rejected') then raise exception using message='الحالة غير متاحة للمتجر',errcode='42501'; end if;
  elsif not public.dawai_is_platform_owner() then raise exception using message='لا تملك صلاحية تغيير الطلب',errcode='42501'; end if;

  if p_status='confirmed' then
    select m.requires_prescription into v_requires from public.medications m where m.id=v_order.medication_id;
    if coalesce(v_requires,false) then
      select status into v_prescription_status from public.prescriptions where id=v_order.prescription_id;
      if v_prescription_status<>'approved' then raise exception using message='يجب مراجعة الوصفة والموافقة عليها قبل قبول الطلب',errcode='P0001'; end if;
    end if;
  end if;

  update public.orders set status=p_status,received_at=case when p_status in ('received','completed') then coalesce(received_at,now()) else received_at end where id=p_order_id;
  update public.order_status_history set note=coalesce(p_note,note) where id=(select max(id) from public.order_status_history where order_id=p_order_id);
  v_message:=case p_status when 'confirmed' then 'تم قبول طلبك وبدأ التجهيز' when 'ready' then 'طلبك جاهز للاستلام أو التوصيل' when 'received' then 'تم تأكيد استلام الطلب' when 'rejected' then 'اعتذر المتجر عن تنفيذ الطلب' else 'تم تحديث حالة طلبك' end;
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  values(v_order.user_id,'تحديث الطلب',v_message,'order_update',false,'order_status:'||p_order_id||':'||p_status,'/orders')
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return jsonb_build_object('success',true,'status',p_status);
end $$;

-- 7) مراجعة الوصفات وحذفها منطقياً
create or replace function public.dawai_review_prescription_v28(p_prescription_id bigint,p_status text,p_notes text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_user uuid; v_order_id bigint; v_vendor bigint;
begin
  if p_status not in ('approved','rejected','needs_clarification') then raise exception using message='حالة المراجعة غير صالحة',errcode='22023'; end if;
  select pr.user_id,o.id,o.pharmacy_id into v_user,v_order_id,v_vendor from public.prescriptions pr join public.orders o on o.prescription_id=pr.id where pr.id=p_prescription_id order by o.created_at desc limit 1;
  if not found then raise exception using message='الوصفة غير مرتبطة بطلب',errcode='P0002'; end if;
  if not public.dawai_is_vendor_owner(v_vendor) and not public.dawai_is_platform_owner() then raise exception using message='الوصفة متاحة فقط للمتجر المرتبط بالطلب',errcode='42501'; end if;
  update public.prescriptions set status=p_status,review_notes=p_notes,reviewed_by=auth.uid(),reviewed_at=now() where id=p_prescription_id;
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  values(v_user,'مراجعة الوصفة',case p_status when 'approved' then 'تمت الموافقة على الوصفة' when 'needs_clarification' then 'الوصفة تحتاج صورة أوضح' else 'تعذّر اعتماد الوصفة' end,'prescription',false,'rx_review:'||p_prescription_id||':'||p_status,'/orders')
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return jsonb_build_object('success',true,'status',p_status);
end $$;

create or replace function public.dawai_delete_prescription_v28(p_prescription_id bigint)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if not exists(select 1 from public.prescriptions where id=p_prescription_id and (user_id=auth.uid() or public.dawai_is_platform_owner())) then raise exception using message='الوصفة غير موجودة أو غير مسموح بحذفها',errcode='42501'; end if;
  if exists(select 1 from public.orders where prescription_id=p_prescription_id and status in ('pending','confirmed','ready')) then raise exception using message='لا يمكن حذف الوصفة أثناء وجود طلب فعّال',errcode='P0001'; end if;
  update public.prescriptions set status='deleted',deleted_at=now() where id=p_prescription_id;
  return jsonb_build_object('success',true);
end $$;

-- 8) النزاعات وتقارير المنتجات والتقييم
create or replace function public.dawai_create_dispute_v28(p_order_id bigint,p_reason text,p_description text default null,p_evidence_path text default null)
returns public.order_disputes language plpgsql security definer set search_path=public as $$
declare v_result public.order_disputes;
begin
  if not exists(select 1 from public.orders where id=p_order_id and user_id=auth.uid()) then raise exception using message='الطلب غير موجود',errcode='42501'; end if;
  if exists(select 1 from public.order_disputes where order_id=p_order_id and status in ('open','under_review')) then raise exception using message='يوجد بلاغ مفتوح لهذا الطلب بالفعل',errcode='P0001'; end if;
  insert into public.order_disputes(order_id,user_id,reason,description,evidence_path) values(p_order_id,auth.uid(),p_reason,p_description,p_evidence_path) returning * into v_result;
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  select p.id,'نزاع جديد','تم فتح نزاع على طلب رقم '||p_order_id,'dispute',false,'dispute:'||v_result.id,'/owner'
  from public.profiles p where p.role='owner'
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return v_result;
end $$;

create or replace function public.dawai_owner_resolve_dispute_v28(p_dispute_id bigint,p_status text,p_response text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_user uuid;
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then raise exception using message='تحتاج صلاحية المالك والتحقق بخطوتين',errcode='42501'; end if;
  if p_status not in ('under_review','resolved','rejected') then raise exception using message='الحالة غير صالحة',errcode='22023'; end if;
  update public.order_disputes set status=p_status,owner_response=p_response,resolved_by=auth.uid(),resolved_at=case when p_status in ('resolved','rejected') then now() else null end,updated_at=now() where id=p_dispute_id returning user_id into v_user;
  if v_user is null then raise exception using message='النزاع غير موجود',errcode='P0002'; end if;
  perform public.dawai_audit('resolve_dispute','order_dispute',p_dispute_id::text,jsonb_build_object('status',p_status));
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url) values(v_user,'تحديث الشكوى',coalesce(p_response,'تم تحديث حالة الشكوى'),'dispute',false,'dispute_status:'||p_dispute_id||':'||p_status,'/orders') on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return jsonb_build_object('success',true);
end $$;

create or replace function public.dawai_owner_moderate_product_report_v28(p_report_id bigint,p_status text,p_notes text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_med bigint; v_user uuid;
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then raise exception using message='تحتاج صلاحية المالك والتحقق بخطوتين',errcode='42501'; end if;
  if p_status not in ('under_review','resolved','dismissed') then raise exception using message='حالة البلاغ غير صالحة',errcode='22023'; end if;
  update public.product_reports set status=p_status,owner_notes=p_notes,resolved_by=auth.uid(),resolved_at=case when p_status in ('resolved','dismissed') then now() else null end where id=p_report_id returning medication_id,user_id into v_med,v_user;
  if v_med is null then raise exception using message='البلاغ غير موجود',errcode='P0002'; end if;
  if p_status='resolved' then update public.medications set authenticity_status='flagged' where id=v_med; end if;
  perform public.dawai_audit('moderate_product_report','product_report',p_report_id::text,jsonb_build_object('status',p_status));
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  values(v_user,'تحديث بلاغ المنتج',coalesce(p_notes,case when p_status='resolved' then 'تم اعتماد البلاغ واتخاذ الإجراء المناسب.' when p_status='dismissed' then 'تمت مراجعة البلاغ ولم يثبت وجود مخالفة.' else 'بدأت الإدارة مراجعة البلاغ.' end),'order_update',false,'product_report_status:'||p_report_id||':'||p_status,'/notifications')
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return jsonb_build_object('success',true);
end $$;

create or replace function public.dawai_submit_rating_v28(p_order_id bigint,p_rating integer,p_speed_rating integer default null,p_packaging_rating integer default null,p_match_rating integer default null,p_comment text default null)
returns public.product_ratings language plpgsql security definer set search_path=public as $$
declare v_order public.orders%rowtype; v_result public.product_ratings;
begin
  select * into v_order from public.orders where id=p_order_id and user_id=auth.uid() and status in ('received','completed');
  if not found then raise exception using message='التقييم متاح فقط بعد استلام الطلب',errcode='42501'; end if;
  insert into public.product_ratings(order_id,user_id,pharmacy_id,medication_id,rating,speed_rating,packaging_rating,match_rating,comment)
  values(p_order_id,auth.uid(),v_order.pharmacy_id,v_order.medication_id,p_rating,p_speed_rating,p_packaging_rating,p_match_rating,p_comment)
  on conflict(order_id) do update set rating=excluded.rating,speed_rating=excluded.speed_rating,packaging_rating=excluded.packaging_rating,match_rating=excluded.match_rating,comment=excluded.comment,status='pending'
  returning * into v_result;
  return v_result;
end $$;

create or replace function public.dawai_owner_moderate_rating_v28(p_rating_id bigint,p_status text)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then raise exception using message='تحتاج صلاحية المالك والتحقق بخطوتين',errcode='42501'; end if;
  if p_status not in ('published','hidden') then raise exception using message='حالة التقييم غير صالحة',errcode='22023'; end if;
  update public.product_ratings set status=p_status,moderated_by=auth.uid(),moderated_at=now() where id=p_rating_id;
  perform public.dawai_audit('moderate_rating','rating',p_rating_id::text,jsonb_build_object('status',p_status));
  return jsonb_build_object('success',true);
end $$;

-- 9) إجراءات المالك الحساسة (AAL2)
create or replace function public.dawai_owner_review_vendor_v28(p_vendor_id bigint,p_action text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_owner uuid; v_name text; v_exp date;
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then raise exception using message='يجب تفعيل والتحقق بخطوتين قبل إدارة المتاجر',errcode='42501'; end if;
  if p_action not in ('approved','rejected') then raise exception using message='الإجراء غير صالح',errcode='22023'; end if;
  select owner_id,name,license_expires_at into v_owner,v_name,v_exp from public.pharmacies where id=p_vendor_id for update;
  if not found then raise exception using message='المتجر غير موجود',errcode='P0002'; end if;
  if p_action='approved' and (v_exp is null or v_exp<current_date or not exists(select 1 from public.vendor_documents where pharmacy_id=p_vendor_id and status in ('submitted','approved'))) then raise exception using message='يجب وجود وثيقة ترخيص غير منتهية قبل الموافقة',errcode='P0001'; end if;
  update public.pharmacies set status=p_action,verification_status=case when p_action='approved' then 'verified' else 'rejected' end,verified_at=case when p_action='approved' then now() else null end,verified_by=auth.uid(),verification_notes=p_note where id=p_vendor_id;
  update public.vendor_documents set status=case when p_action='approved' then 'approved' else 'rejected' end,reviewed_by=auth.uid(),reviewed_at=now(),review_notes=p_note where pharmacy_id=p_vendor_id and status in ('submitted','approved');
  update public.profiles set status=case when p_action='approved' then 'active' else 'rejected' end where id=v_owner;
  perform public.dawai_audit('review_vendor','vendor',p_vendor_id::text,jsonb_build_object('action',p_action,'note',p_note));
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url) values(v_owner,case when p_action='approved' then 'تم توثيق متجرك' else 'تعذّر توثيق المتجر' end,coalesce(p_note,case when p_action='approved' then 'أصبح متجرك موثّقاً وظاهراً للمستخدمين.' else 'راجع بيانات الترخيص وأعد التقديم.' end),'vendor_approval',false,'vendor_review:'||p_vendor_id||':'||p_action,'/dashboard') on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return jsonb_build_object('success',true,'status',p_action,'vendor_name',v_name);
end $$;

create or replace function public.dawai_owner_suspend_vendor_v28(p_vendor_id bigint,p_reason text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_owner uuid;
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then raise exception using message='تحتاج التحقق بخطوتين',errcode='42501'; end if;
  update public.pharmacies set verification_status='suspended',suspended_at=now(),suspension_reason=p_reason where id=p_vendor_id returning owner_id into v_owner;
  if v_owner is null then raise exception using message='المتجر غير موجود',errcode='P0002'; end if;
  perform public.dawai_audit('suspend_vendor','vendor',p_vendor_id::text,jsonb_build_object('reason',p_reason));
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  values(v_owner,'تم إيقاف المتجر مؤقتاً',coalesce(nullif(btrim(p_reason),''),'راجع إدارة المنصة لمعرفة سبب الإيقاف.'),'vendor_approval',false,'vendor_suspend:'||p_vendor_id,'/dashboard')
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return jsonb_build_object('success',true);
end $$;

create or replace function public.dawai_owner_delete_vendor_v28(p_vendor_id bigint)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_owner uuid; v_name text;
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then raise exception using message='تحتاج التحقق بخطوتين',errcode='42501'; end if;
  select owner_id,name into v_owner,v_name from public.pharmacies where id=p_vendor_id and coalesce(status,'')<>'deleted' for update;
  if not found then raise exception using message='المتجر غير موجود أو محذوف',errcode='P0002'; end if;
  update public.pharmacies set status='deleted',verification_status='suspended',suspended_at=now(),suspension_reason='حذف بواسطة المالك' where id=p_vendor_id;
  update public.profiles set role='patient',status='active',pharmacy_id=null where id=v_owner and role in ('pharmacy','cosmetic');
  perform public.dawai_audit('delete_vendor','vendor',p_vendor_id::text,jsonb_build_object('name',v_name));
  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  values(v_owner,'تم حذف المتجر من المنصة','تم حذف '||coalesce(v_name,'المتجر')||'، ويمكنك الاستمرار باستخدام الحساب كمستخدم عادي.','vendor_approval',false,'vendor_deleted:'||p_vendor_id,'/home')
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  return jsonb_build_object('success',true,'vendor_id',p_vendor_id,'vendor_name',v_name);
end $$;

create or replace function public.dawai_owner_set_subscription_v28(p_subscription_id bigint,p_action text)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then raise exception using message='تحتاج التحقق بخطوتين',errcode='42501'; end if;
  perform public.dawai_audit('subscription_review','subscription',p_subscription_id::text,jsonb_build_object('action',p_action));
  return public.dawai_owner_set_subscription_v27(p_subscription_id,p_action);
end $$;

create or replace function public.dawai_generate_license_expiry_alerts_v28()
returns integer language plpgsql security definer set search_path=public as $$
declare v_count integer:=0; v_rows integer:=0;
begin
  if not public.dawai_is_platform_owner() or not public.dawai_has_aal2() then
    raise exception using message='تحتاج صلاحية المالك والتحقق بخطوتين',errcode='42501';
  end if;

  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  select owners.id,
         case when ph.license_expires_at<current_date then 'ترخيص متجر منتهي' else 'ترخيص متجر يقترب من الانتهاء' end,
         ph.name||' — تاريخ الانتهاء: '||to_char(ph.license_expires_at,'YYYY-MM-DD'),
         'reminder',false,
         'owner_license_expiry:'||ph.id||':'||ph.license_expires_at,
         '/owner'
  from public.pharmacies ph
  cross join public.profiles owners
  where owners.role='owner'
    and coalesce(ph.status,'')<>'deleted'
    and ph.license_expires_at is not null
    and ph.license_expires_at<=current_date+30
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  get diagnostics v_rows=row_count; v_count:=v_count+v_rows;

  insert into public.notifications(user_id,title,message,type,is_read,dedupe_key,action_url)
  select ph.owner_id,
         case when ph.license_expires_at<current_date then 'انتهى ترخيص متجرك' else 'ترخيص متجرك يقترب من الانتهاء' end,
         'حدّث وثيقة '||ph.name||' قبل تاريخ '||to_char(ph.license_expires_at,'YYYY-MM-DD')||'.',
         'reminder',false,
         'vendor_license_expiry:'||ph.id||':'||ph.license_expires_at,
         '/dashboard'
  from public.pharmacies ph
  where ph.owner_id is not null
    and coalesce(ph.status,'')<>'deleted'
    and ph.license_expires_at is not null
    and ph.license_expires_at<=current_date+30
  on conflict(user_id,dedupe_key) where dedupe_key is not null do nothing;
  get diagnostics v_rows=row_count; v_count:=v_count+v_rows;
  return v_count;
end $$;

create or replace function public.dawai_mark_all_notifications_read_v28()
returns integer language plpgsql security definer set search_path=public as $$ declare v_count integer; begin update public.notifications set is_read=true where user_id=auth.uid() and not is_read; get diagnostics v_count=row_count; return v_count; end $$;

-- 10) Storage خاص (لا public URLs)
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values
 ('vendor-documents','vendor-documents',false,10485760,array['image/jpeg','image/png','image/webp','application/pdf']),
 ('dispute-evidence','dispute-evidence',false,10485760,array['image/jpeg','image/png','image/webp','application/pdf']),
 ('product-report-evidence','product-report-evidence',false,10485760,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

-- 11) RLS
alter table public.vendor_documents enable row level security;
alter table public.order_status_history enable row level security;
alter table public.order_disputes enable row level security;
alter table public.product_reports enable row level security;
alter table public.product_ratings enable row level security;
alter table public.owner_audit_logs enable row level security;
alter table public.security_events enable row level security;

drop policy if exists vendor_documents_read_v28 on public.vendor_documents;
create policy vendor_documents_read_v28 on public.vendor_documents for select to authenticated using(owner_id=auth.uid() or public.dawai_is_platform_owner());
drop policy if exists vendor_documents_insert_v28 on public.vendor_documents;
create policy vendor_documents_insert_v28 on public.vendor_documents for insert to authenticated with check(owner_id=auth.uid() and public.dawai_is_vendor_owner(pharmacy_id));

drop policy if exists order_history_read_v28 on public.order_status_history;
create policy order_history_read_v28 on public.order_status_history for select to authenticated using(exists(select 1 from public.orders o join public.pharmacies p on p.id=o.pharmacy_id where o.id=order_id and (o.user_id=auth.uid() or p.owner_id=auth.uid() or public.dawai_is_platform_owner())));

drop policy if exists disputes_read_v28 on public.order_disputes;
create policy disputes_read_v28 on public.order_disputes for select to authenticated using(user_id=auth.uid() or public.dawai_is_platform_owner());
drop policy if exists disputes_insert_v28 on public.order_disputes;
create policy disputes_insert_v28 on public.order_disputes for insert to authenticated with check(user_id=auth.uid());

drop policy if exists product_reports_read_v28 on public.product_reports;
create policy product_reports_read_v28 on public.product_reports for select to authenticated using(user_id=auth.uid() or public.dawai_is_platform_owner());
drop policy if exists product_reports_insert_v28 on public.product_reports;
create policy product_reports_insert_v28 on public.product_reports for insert to authenticated with check(user_id=auth.uid());

drop policy if exists ratings_read_v28 on public.product_ratings;
create policy ratings_read_v28 on public.product_ratings for select to authenticated using(user_id=auth.uid() or status='published' or public.dawai_is_platform_owner());
drop policy if exists ratings_insert_v28 on public.product_ratings;
create policy ratings_insert_v28 on public.product_ratings for insert to authenticated with check(user_id=auth.uid());

drop policy if exists owner_audit_read_v28 on public.owner_audit_logs;
create policy owner_audit_read_v28 on public.owner_audit_logs for select to authenticated using(public.dawai_is_platform_owner() and public.dawai_has_aal2());

drop policy if exists security_events_own_v28 on public.security_events;
create policy security_events_own_v28 on public.security_events for select to authenticated using(user_id=auth.uid() or public.dawai_is_platform_owner());
drop policy if exists security_events_insert_v28 on public.security_events;
create policy security_events_insert_v28 on public.security_events for insert to authenticated with check(user_id=auth.uid());

-- سياسات RESTRICTIVE: تمنع حساب المالك من قراءة بيانات الإدارة الحساسة قبل AAL2،
-- مع إبقاء بياناته الشخصية والمتاجر الموثقة متاحة أثناء الاستخدام العادي.
drop policy if exists profiles_owner_aal2_v28 on public.profiles;
create policy profiles_owner_aal2_v28 on public.profiles as restrictive for select to authenticated
using (id=auth.uid() or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

drop policy if exists pharmacies_owner_aal2_v28 on public.pharmacies;
create policy pharmacies_owner_aal2_v28 on public.pharmacies as restrictive for select to authenticated
using (not public.dawai_is_platform_owner() or public.dawai_has_aal2() or (status='approved' and verification_status='verified'));

drop policy if exists vendor_documents_owner_aal2_v28 on public.vendor_documents;
create policy vendor_documents_owner_aal2_v28 on public.vendor_documents as restrictive for select to authenticated
using (owner_id=auth.uid() or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

drop policy if exists prescriptions_owner_aal2_v28 on public.prescriptions;
create policy prescriptions_owner_aal2_v28 on public.prescriptions as restrictive for select to authenticated
using (user_id=auth.uid() or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

drop policy if exists disputes_owner_aal2_v28 on public.order_disputes;
create policy disputes_owner_aal2_v28 on public.order_disputes as restrictive for select to authenticated
using (user_id=auth.uid() or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

drop policy if exists reports_owner_aal2_v28 on public.product_reports;
create policy reports_owner_aal2_v28 on public.product_reports as restrictive for select to authenticated
using (user_id=auth.uid() or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

drop policy if exists ratings_owner_aal2_v28 on public.product_ratings;
create policy ratings_owner_aal2_v28 on public.product_ratings as restrictive for select to authenticated
using (user_id=auth.uid() or status='published' or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

drop policy if exists subscriptions_owner_aal2_v28 on public.user_subscriptions;
create policy subscriptions_owner_aal2_v28 on public.user_subscriptions as restrictive for select to authenticated
using (user_id=auth.uid() or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

drop policy if exists security_events_owner_aal2_v28 on public.security_events;
create policy security_events_owner_aal2_v28 on public.security_events as restrictive for select to authenticated
using (user_id=auth.uid() or not public.dawai_is_platform_owner() or public.dawai_has_aal2());

-- Storage: مجلد أول باسم uid.
drop policy if exists vendor_docs_upload_v28 on storage.objects;
create policy vendor_docs_upload_v28 on storage.objects for insert to authenticated with check(bucket_id='vendor-documents' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists vendor_docs_read_v28 on storage.objects;
create policy vendor_docs_read_v28 on storage.objects for select to authenticated using(bucket_id='vendor-documents' and ((storage.foldername(name))[1]=auth.uid()::text or public.dawai_is_platform_owner()));
drop policy if exists dispute_evidence_upload_v28 on storage.objects;
create policy dispute_evidence_upload_v28 on storage.objects for insert to authenticated with check(bucket_id='dispute-evidence' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists dispute_evidence_read_v28 on storage.objects;
create policy dispute_evidence_read_v28 on storage.objects for select to authenticated using(bucket_id='dispute-evidence' and ((storage.foldername(name))[1]=auth.uid()::text or public.dawai_is_platform_owner()));
drop policy if exists product_report_upload_v28 on storage.objects;
create policy product_report_upload_v28 on storage.objects for insert to authenticated with check(bucket_id='product-report-evidence' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists product_report_read_v28 on storage.objects;
create policy product_report_read_v28 on storage.objects for select to authenticated using(bucket_id='product-report-evidence' and ((storage.foldername(name))[1]=auth.uid()::text or public.dawai_is_platform_owner()));

drop policy if exists private_storage_owner_aal2_v28 on storage.objects;
create policy private_storage_owner_aal2_v28 on storage.objects as restrictive for select to authenticated
using (
  bucket_id not in ('prescriptions','vendor-documents','dispute-evidence','product-report-evidence')
  or (storage.foldername(name))[1]=auth.uid()::text
  or not public.dawai_is_platform_owner()
  or public.dawai_has_aal2()
);

-- 12) Grants وschema reload
grant execute on function public.dawai_create_order_v28(bigint,bigint,integer,bigint,text,integer,text,uuid) to authenticated;
grant execute on function public.dawai_update_order_status_v28(bigint,text,text) to authenticated;
grant execute on function public.dawai_review_prescription_v28(bigint,text,text) to authenticated;
grant execute on function public.dawai_delete_prescription_v28(bigint) to authenticated;
grant execute on function public.dawai_create_dispute_v28(bigint,text,text,text) to authenticated;
grant execute on function public.dawai_owner_resolve_dispute_v28(bigint,text,text) to authenticated;
grant execute on function public.dawai_owner_moderate_product_report_v28(bigint,text,text) to authenticated;
grant execute on function public.dawai_submit_rating_v28(bigint,integer,integer,integer,integer,text) to authenticated;
grant execute on function public.dawai_owner_moderate_rating_v28(bigint,text) to authenticated;
grant execute on function public.dawai_owner_review_vendor_v28(bigint,text,text) to authenticated;
grant execute on function public.dawai_owner_suspend_vendor_v28(bigint,text) to authenticated;
grant execute on function public.dawai_owner_delete_vendor_v28(bigint) to authenticated;
grant execute on function public.dawai_owner_set_subscription_v28(bigint,text) to authenticated;
grant execute on function public.dawai_generate_license_expiry_alerts_v28() to authenticated;
grant execute on function public.dawai_mark_all_notifications_read_v28() to authenticated;

notify pgrst,'reload schema';
commit;

select routine_name from information_schema.routines
where routine_schema='public' and routine_name like 'dawai_%_v28'
order by routine_name;
