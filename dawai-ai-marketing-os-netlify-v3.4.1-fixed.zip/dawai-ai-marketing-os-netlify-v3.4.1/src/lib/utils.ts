import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** تنسيق السعر بالدينار العراقي — أرقام بفواصل، بدون كسور (الدينار لا يستخدم كسوراً). */
export function formatIQD(amount: number): string {
  return new Intl.NumberFormat("en-US").format(Math.round(amount)) + " د.ع"
}
