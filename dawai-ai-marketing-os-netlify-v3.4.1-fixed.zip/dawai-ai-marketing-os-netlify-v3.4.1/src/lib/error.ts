export type AppErrorLike = {
  message?: unknown;
  details?: unknown;
  hint?: unknown;
  code?: unknown;
  error_description?: unknown;
};

/**
 * يحوّل أخطاء Supabase وJavaScript إلى رسالة مفهومة بدل [object Object].
 */
export function getErrorMessage(error: unknown, fallback = 'حدث خطأ غير متوقع'): string {
  if (error == null) return fallback;
  if (typeof error === 'string') return error.trim() || fallback;
  if (error instanceof Error) return error.message?.trim() || fallback;

  if (typeof error === 'object') {
    const value = error as AppErrorLike;
    const parts = [value.message, value.details, value.hint]
      .filter((item): item is string => typeof item === 'string' && item.trim().length > 0)
      .map((item) => item.trim());

    if (parts.length) {
      const unique = [...new Set(parts)];
      const code = typeof value.code === 'string' && value.code.trim() ? ` (${value.code.trim()})` : '';
      return `${unique.join(' — ')}${code}`;
    }

    if (typeof value.error_description === 'string' && value.error_description.trim()) {
      return value.error_description.trim();
    }

    try {
      const json = JSON.stringify(error);
      if (json && json !== '{}') return json;
    } catch {
      // تجاهل فشل التسلسل الدائري.
    }
  }

  const text = String(error).trim();
  return text && text !== '[object Object]' ? text : fallback;
}
