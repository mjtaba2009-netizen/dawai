const IMAGE_EXTENSIONS = /\.(png|jpe?g|webp|gif|heic|heif|bmp|avif)$/i;

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('تعذّر قراءة الصورة'));
    reader.readAsDataURL(file);
  });
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('صيغة الصورة غير مدعومة على هذا الجهاز'));
    image.src = url;
  });
}

export async function prepareProductImage(file: File): Promise<string> {
  const likelyImage = file.type.startsWith('image/') || IMAGE_EXTENSIONS.test(file.name);
  if (!likelyImage) throw new Error('اختر ملف صورة من الاستوديو أو الكاميرا');

  const objectUrl = URL.createObjectURL(file);
  try {
    const image = await loadImage(objectUrl);
    const maxDimension = 1400;
    const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
    const width = Math.max(1, Math.round(image.naturalWidth * scale));
    const height = Math.max(1, Math.round(image.naturalHeight * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) throw new Error('تعذّر تجهيز الصورة');
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, width, height);
    context.drawImage(image, 0, 0, width, height);

    let quality = 0.84;
    let result = canvas.toDataURL('image/jpeg', quality);
    while (result.length > 900_000 && quality > 0.46) {
      quality -= 0.08;
      result = canvas.toDataURL('image/jpeg', quality);
    }
    return result;
  } catch (error) {
    // الملفات التي يعرضها Safari لكن لا يمكن رسمها على Canvas تُقرأ مباشرة إذا كان حجمها معقولاً.
    if (file.size <= 1_800_000) return readFileAsDataUrl(file);
    throw error;
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}
