import type { Agent, Campaign, ContentItem } from './types'

export const initialCampaigns: Campaign[] = [
  {
    id: '11111111-1111-4111-8111-111111111111',
    name: 'حملة إطلاق Dawai — 30 يوم',
    objective: 'زيادة الوعي وجذب أول مستخدمين للمنصة',
    audience: 'مستخدمون يبحثون عن أدوية ومنتجات صحية داخل العراق',
    channels: ['instagram', 'tiktok', 'email'],
    status: 'active',
    startDate: '2026-07-14',
    endDate: '2026-08-12',
    progress: 18,
  },
  {
    id: '22222222-2222-4222-8222-222222222222',
    name: 'استقطاب الصيدليات والمتاجر',
    objective: 'توضيح أدوات الطلبات والعروض والتواصل',
    audience: 'أصحاب الصيدليات ومتاجر الكوزمتك',
    channels: ['instagram', 'email'],
    status: 'draft',
    startDate: '2026-07-20',
    endDate: '2026-08-20',
    progress: 4,
  },
]

export const initialContent: ContentItem[] = [
  {
    id: '31111111-1111-4111-8111-111111111111',
    title: 'شنو هي Dawai؟',
    body: 'تدور على دواء وما تعرف وين متوفر؟ مع Dawai البحث صار أسهل.',
    type: 'reel',
    channel: 'instagram',
    scheduledAt: '2026-07-14T19:00:00+03:00',
    status: 'approved',
    campaignId: '11111111-1111-4111-8111-111111111111',
  },
  {
    id: '32222222-2222-4222-8222-222222222222',
    title: 'قارن السعر والمسافة',
    body: 'اعرض تجربة البحث والمقارنة بشكل بصري سريع.',
    type: 'reel',
    channel: 'tiktok',
    scheduledAt: '2026-07-15T20:00:00+03:00',
    status: 'review',
    campaignId: '11111111-1111-4111-8111-111111111111',
  },
  {
    id: '33333333-3333-4333-8333-333333333333',
    title: 'رسالة الترحيب',
    body: 'Dawai — دواؤك أقرب. تعرّف على البحث والمقارنة ورفع الوصفة والتذكيرات.',
    type: 'email',
    channel: 'email',
    scheduledAt: '2026-07-16T11:00:00+03:00',
    status: 'draft',
    campaignId: '11111111-1111-4111-8111-111111111111',
  },
  {
    id: '34444444-4444-4444-8444-444444444444',
    title: 'طريقة رفع الوصفة',
    body: 'شرح مختصر يحافظ على الخصوصية ولا يقدم أي ادعاء طبي.',
    type: 'carousel',
    channel: 'instagram',
    scheduledAt: '2026-07-17T18:30:00+03:00',
    status: 'scheduled',
    campaignId: '11111111-1111-4111-8111-111111111111',
  },
]

export const agents: Agent[] = [
  { id: 'manager', name: 'مدير التسويق', role: 'يبني الخطة ويقسّم العمل', status: 'working', tasks: 3 },
  { id: 'copy', name: 'كاتب المحتوى', role: 'الكابشن، السكربت، والإيميلات', status: 'review', tasks: 7 },
  { id: 'design', name: 'المصمم', role: 'قوالب السوشل والهوية البصرية', status: 'idle', tasks: 4 },
  { id: 'video', name: 'محرر الفيديو', role: 'ريلز وتيك توك ومقاطع الواجهة', status: 'working', tasks: 2 },
  { id: 'analytics', name: 'محلل النمو', role: 'الأداء والتجارب والتحسين', status: 'idle', tasks: 1 },
]
