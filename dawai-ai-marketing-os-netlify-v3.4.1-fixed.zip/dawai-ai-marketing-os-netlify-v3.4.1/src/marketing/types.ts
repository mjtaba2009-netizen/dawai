export type Channel = 'instagram' | 'tiktok' | 'email'
export type ContentStatus = 'draft' | 'review' | 'approved' | 'scheduled' | 'published'

export interface Campaign {
  id: string
  name: string
  objective: string
  audience: string
  channels: Channel[]
  status: 'draft' | 'active' | 'paused' | 'completed'
  startDate: string
  endDate: string
  progress: number
}

export interface ContentItem {
  id: string
  title: string
  body: string
  type: 'reel' | 'story' | 'carousel' | 'email'
  channel: Channel
  scheduledAt: string
  status: ContentStatus
  campaignId: string
}

export interface Agent {
  id: string
  name: string
  role: string
  status: 'idle' | 'working' | 'review'
  tasks: number
}
