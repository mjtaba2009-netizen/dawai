import type { Campaign, Channel, ContentItem } from '../types'

const topics = [
  ['شنو هي Dawai؟', 'عرّف المشكلة والحل خلال 20 ثانية.', 'reel'],
  ['البحث عن الدواء', 'اعرض رحلة البحث بخطوات بسيطة بدون وعود غير مثبتة.', 'reel'],
  ['المقارنة الذكية', 'وضح مقارنة السعر والمسافة ووقت التوصيل عند توفر البيانات.', 'carousel'],
  ['رفع الوصفة بخصوصية', 'شرح خصوصية رفع الوصفة ومراجعتها داخل النظام.', 'story'],
  ['إعادة الطلب', 'محتوى سريع عن تسهيل إعادة طلب المنتجات السابقة.', 'reel'],
  ['التذكيرات', 'وضح ميزة التذكير بقرب نفاد الدواء بدون نصيحة طبية.', 'carousel'],
  ['دعوة للتجربة', 'CTA واضح لاكتشاف المنصة والتسجيل.', 'reel'],
] as const

export function generateWeekPlan(campaign: Campaign): ContentItem[] {
  return topics.map(([title, body, type], index) => {
    const date = new Date(`${campaign.startDate}T19:00:00+03:00`)
    date.setDate(date.getDate() + index)
    const channel: Channel = campaign.channels[index % campaign.channels.length] ?? 'instagram'
    return {
      id: crypto.randomUUID(),
      title,
      body,
      type: channel === 'email' ? 'email' : type,
      channel,
      scheduledAt: date.toISOString(),
      status: 'draft',
      campaignId: campaign.id,
    }
  })
}
