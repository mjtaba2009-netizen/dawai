import { supabase } from '@/services/supabase';
import type { Campaign, ContentItem, ContentStatus } from '@/marketing/types';

export type MarketingStorageMode = 'checking' | 'supabase' | 'local';

const missingTableCodes = new Set(['42P01', 'PGRST205', 'PGRST204', 'PGRST202']);

function isMissingMarketingSchema(error: { code?: string; message?: string } | null | undefined) {
  if (!error) return false;
  if (error.code && missingTableCodes.has(error.code)) return true;
  const message = String(error.message ?? '').toLowerCase();
  return message.includes('marketing_campaigns') || message.includes('marketing_content_items') || message.includes('dawai_marketing_approve_content');
}

function campaignToRow(campaign: Campaign) {
  return {
    id: campaign.id,
    name: campaign.name,
    objective: campaign.objective,
    audience: campaign.audience,
    channels: campaign.channels,
    status: campaign.status,
    start_date: campaign.startDate,
    end_date: campaign.endDate,
    progress: campaign.progress,
  };
}

function contentToRow(item: ContentItem) {
  return {
    id: item.id,
    campaign_id: item.campaignId,
    title: item.title,
    body: item.body,
    content_type: item.type,
    channel: item.channel,
    status: item.status,
    scheduled_at: item.scheduledAt,
  };
}

function campaignFromRow(row: Record<string, unknown>): Campaign {
  return {
    id: String(row.id),
    name: String(row.name ?? ''),
    objective: String(row.objective ?? ''),
    audience: String(row.audience ?? ''),
    channels: Array.isArray(row.channels) ? row.channels as Campaign['channels'] : [],
    status: String(row.status ?? 'draft') as Campaign['status'],
    startDate: String(row.start_date ?? ''),
    endDate: String(row.end_date ?? ''),
    progress: Number(row.progress ?? 0),
  };
}

function contentFromRow(row: Record<string, unknown>): ContentItem {
  return {
    id: String(row.id),
    title: String(row.title ?? ''),
    body: String(row.body ?? ''),
    type: String(row.content_type ?? 'reel') as ContentItem['type'],
    channel: String(row.channel ?? 'instagram') as ContentItem['channel'],
    scheduledAt: String(row.scheduled_at ?? new Date().toISOString()),
    status: String(row.status ?? 'draft') as ContentItem['status'],
    campaignId: String(row.campaign_id ?? ''),
  };
}

export async function loadRemoteWorkspace(seedCampaigns: Campaign[] = [], seedContent: ContentItem[] = []): Promise<{
  mode: MarketingStorageMode;
  campaigns: Campaign[];
  content: ContentItem[];
}> {
  const [campaignResult, contentResult] = await Promise.all([
    supabase.from('marketing_campaigns').select('*').order('created_at', { ascending: false }),
    supabase.from('marketing_content_items').select('*').order('scheduled_at', { ascending: true }),
  ]);

  if (campaignResult.error || contentResult.error) {
    const error = campaignResult.error ?? contentResult.error;
    if (isMissingMarketingSchema(error)) {
      return { mode: 'local', campaigns: [], content: [] };
    }
    throw error;
  }

  let campaigns = (campaignResult.data ?? []).map((row) => campaignFromRow(row as Record<string, unknown>));
  let content = (contentResult.data ?? []).map((row) => contentFromRow(row as Record<string, unknown>));

  if (!campaigns.length && seedCampaigns.length) {
    const seedCampaignResult = await supabase
      .from('marketing_campaigns')
      .upsert(seedCampaigns.map(campaignToRow), { onConflict: 'id' });
    if (seedCampaignResult.error) throw seedCampaignResult.error;

    if (seedContent.length) {
      const seedContentResult = await supabase
        .from('marketing_content_items')
        .upsert(seedContent.map(contentToRow), { onConflict: 'id' });
      if (seedContentResult.error) throw seedContentResult.error;
    }
    campaigns = seedCampaigns;
    content = seedContent;
  }

  return { mode: 'supabase', campaigns, content };
}

export async function upsertCampaignBundle(campaign: Campaign, items: ContentItem[]) {
  const campaignResult = await supabase.from('marketing_campaigns').upsert(campaignToRow(campaign), { onConflict: 'id' });
  if (campaignResult.error) throw campaignResult.error;
  if (!items.length) return;
  const contentResult = await supabase.from('marketing_content_items').upsert(items.map(contentToRow), { onConflict: 'id' });
  if (contentResult.error) throw contentResult.error;
}

export async function persistCampaignStatus(id: string, status: Campaign['status']) {
  const { error } = await supabase.from('marketing_campaigns').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
  if (error) throw error;
}

export async function persistContentStatus(id: string, status: ContentStatus) {
  if (status === 'approved') {
    const { error } = await supabase.rpc('dawai_marketing_approve_content', {
      p_content_id: id,
      p_decision: 'approved',
      p_note: 'تمت الموافقة من لوحة Dawai AI Marketing OS',
    });
    if (!error) return;
    if (!isMissingMarketingSchema(error)) throw error;
  }

  const { error } = await supabase
    .from('marketing_content_items')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;
}
