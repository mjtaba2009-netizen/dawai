import type { Campaign, ContentItem } from '../types'

const CAMPAIGNS_KEY = 'dawai-marketing-campaigns'
const CONTENT_KEY = 'dawai-marketing-content'

export function loadCampaigns(fallback: Campaign[]): Campaign[] {
  try {
    const value = localStorage.getItem(CAMPAIGNS_KEY)
    return value ? JSON.parse(value) as Campaign[] : fallback
  } catch {
    return fallback
  }
}

export function saveCampaigns(value: Campaign[]) {
  localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(value))
}

export function loadContent(fallback: ContentItem[]): ContentItem[] {
  try {
    const value = localStorage.getItem(CONTENT_KEY)
    return value ? JSON.parse(value) as ContentItem[] : fallback
  } catch {
    return fallback
  }
}

export function saveContent(value: ContentItem[]) {
  localStorage.setItem(CONTENT_KEY, JSON.stringify(value))
}
