import { useContext, useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { AuthContext, AuthProvider, isOwner, isVendor } from '@/contexts/AuthContext';
import { CartProvider } from '@/contexts/CartContext';
import { DawaiIntroCinematicV3 as SplashIntro, DAWAI_INTRO_DURATION_MS } from '@/components/intro/DawaiIntroCinematicV3';
import { PartnershipAgreementModal } from '@/components/PartnershipAgreementModal';
import { Layout } from '@/components/Layout';
import { ROUTER_BASENAME } from '@/lib/api-base';

// Pages
import { Login } from '@/pages/Login';
import { Home } from '@/pages/Home';
import { Search } from '@/pages/Search';
import { Orders } from '@/pages/Orders';
import { Cart } from '@/pages/Cart';
import { Notifications } from '@/pages/Notifications';
import { Account } from '@/pages/Account';
import { PharmacyDashboard } from '@/pages/PharmacyDashboard';
import { PharmacyRegister } from '@/pages/PharmacyRegister';
import { VendorProfile } from '@/pages/VendorProfile';
import { OwnerDashboard } from '@/pages/OwnerDashboard';
import { Benefits } from '@/pages/Benefits';
import { SecurityCenter } from '@/pages/SecurityCenter';
import { MarketingOS } from '@/pages/MarketingOS';
import { VendorStatusGate } from '@/components/VendorStatusGate';
import { ReminderWatcher } from '@/components/ReminderWatcher';
import { ConnectivityBanner } from '@/components/ConnectivityBanner';
import { OwnerSecurityGate } from '@/components/OwnerSecurityGate';
import { ToastProvider } from '@/hooks/use-toast';
import { PushNotificationsProvider } from '@/contexts/PushNotificationsContext';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false, refetchOnWindowFocus: false },
  },
});

const AppRoutes = () => {
  const { user } = useContext(AuthContext)!;

  if (!user) {
    return (
      <Routes>
        <Route path="*" element={<Login />} />
      </Routes>
    );
  }

  // حسابات الصيدليات والكوزمتك تبقى بانتظار موافقة الإدارة قبل فتح لوحة المتجر.
  if (isVendor(user) && (user.status === 'pending_approval' || user.status === 'rejected')) {
    return <VendorStatusGate />;
  }

  if (isVendor(user) && user.status === 'approved_pending_signature') {
    return <PartnershipAgreementModal />;
  }

  return (
    <Routes>
      {/* المسارات العادية متاحة للجميع، بما في ذلك مالك المنصة. */}
      <Route path="/home"          element={<Home />} />
      <Route path="/search"        element={<Search />} />
      <Route path="/orders"        element={<Orders />} />
      <Route path="/cart"          element={<Cart />} />
      <Route path="/notifications" element={<Notifications />} />
      <Route path="/account"       element={<Account />} />
      <Route path="/benefits"      element={<Benefits />} />
      <Route path="/security"      element={<SecurityCenter />} />
      <Route path="/vendor/:id"    element={<VendorProfile />} />

      {isVendor(user) && (
        <Route path="/dashboard" element={<PharmacyDashboard />} />
      )}

      {/* لوحة الإدارة منفصلة، ولا تمنع المالك من استخدام التطبيق كمستخدم عادي. */}
      {isOwner(user) && (
        <>
          <Route path="/owner" element={<OwnerSecurityGate><OwnerDashboard /></OwnerSecurityGate>} />
          <Route path="/owner/marketing" element={<OwnerSecurityGate><MarketingOS /></OwnerSecurityGate>} />
        </>
      )}

      <Route path="/pharmacy-register" element={<PharmacyRegister />} />
      <Route
        path="*"
        element={<Navigate to={isVendor(user) ? '/dashboard' : '/home'} replace />}
      />
    </Routes>
  );
};

export default function App() {
  const [showIntro, setShowIntro] = useState(() => {
    const connection = (navigator as Navigator & { connection?: { saveData?: boolean; effectiveType?: string } }).connection;
    const slow = connection?.saveData || connection?.effectiveType === '2g' || connection?.effectiveType === 'slow-2g';
    return !slow;
  });

  useEffect(() => {
    if (!showIntro) return;
    const timer = setTimeout(() => setShowIntro(false), DAWAI_INTRO_DURATION_MS);
    return () => clearTimeout(timer);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
      <TooltipProvider>
        <AuthProvider>
          <CartProvider>
            <PushNotificationsProvider>
            <BrowserRouter basename={ROUTER_BASENAME}>
              <AnimatePresence mode="wait">
                {showIntro && <SplashIntro key="splash" />}
              </AnimatePresence>

              <ConnectivityBanner />
              <ReminderWatcher />

              <Layout>
                <AppRoutes />
              </Layout>

              <Toaster />
            </BrowserRouter>
            </PushNotificationsProvider>
          </CartProvider>
        </AuthProvider>
      </TooltipProvider>
      </ToastProvider>
    </QueryClientProvider>
  );
}
