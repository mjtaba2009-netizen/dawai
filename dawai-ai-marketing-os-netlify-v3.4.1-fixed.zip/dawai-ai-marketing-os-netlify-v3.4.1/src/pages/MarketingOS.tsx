import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Activity,
  ArrowRight,
  BarChart3,
  Bot,
  CalendarDays,
  Check,
  ChevronLeft,
  CircleAlert,
  Clock3,
  FileText,
  Instagram,
  LayoutDashboard,
  Mail,
  Menu,
  Megaphone,
  Pause,
  Play,
  Plus,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Sparkles,
  Video,
  X,
} from 'lucide-react'
import { agents, initialCampaigns, initialContent } from '@/marketing/data'
import { generateWeekPlan } from '@/marketing/services/plan'
import { loadCampaigns, loadContent, saveCampaigns, saveContent } from '@/marketing/services/storage'
import { loadRemoteWorkspace, persistCampaignStatus, persistContentStatus, upsertCampaignBundle, type MarketingStorageMode } from '@/marketing/services/repository'
import type { Campaign, Channel, ContentItem, ContentStatus } from '@/marketing/types'
import { useToast } from '@/hooks/use-toast'
import '@/marketing/marketing-os.css'

const LOGO_URL = `${import.meta.env.BASE_URL}logo.png`

type View = 'overview' | 'campaigns' | 'calendar' | 'content' | 'agents' | 'analytics' | 'connections'

const navigation: Array<{ id: View; label: string; icon: typeof LayoutDashboard }> = [
  { id: 'overview', label: 'نظرة عامة', icon: LayoutDashboard },
  { id: 'campaigns', label: 'الحملات', icon: Megaphone },
  { id: 'calendar', label: 'تقويم المحتوى', icon: CalendarDays },
  { id: 'content', label: 'مكتبة المحتوى', icon: FileText },
  { id: 'agents', label: 'فريق الـ AI', icon: Bot },
  { id: 'analytics', label: 'التحليلات', icon: BarChart3 },
  { id: 'connections', label: 'الربط والإعدادات', icon: Settings },
]

const channelMeta: Record<Channel, { label: string; icon: typeof Instagram; className: string }> = {
  instagram: { label: 'Instagram', icon: Instagram, className: 'instagram' },
  tiktok: { label: 'TikTok', icon: Video, className: 'tiktok' },
  email: { label: 'Email', icon: Mail, className: 'email' },
}

const statusLabels: Record<ContentStatus, string> = {
  draft: 'مسودة',
  review: 'بانتظار المراجعة',
  approved: 'موافق عليه',
  scheduled: 'مجدول',
  published: 'منشور',
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat('ar-IQ', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
  }).format(new Date(value))
}

export function MarketingOS() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const [storageMode, setStorageMode] = useState<MarketingStorageMode>('checking')
  const [view, setView] = useState<View>('overview')
  const [menuOpen, setMenuOpen] = useState(false)
  const [campaigns, setCampaigns] = useState<Campaign[]>(() => loadCampaigns(initialCampaigns))
  const [content, setContent] = useState<ContentItem[]>(() => loadContent(initialContent))
  const [createOpen, setCreateOpen] = useState(false)
  const [selectedContent, setSelectedContent] = useState<ContentItem | null>(null)
  const [query, setQuery] = useState('')

  useEffect(() => saveCampaigns(campaigns), [campaigns])
  useEffect(() => saveContent(content), [content])

  useEffect(() => {
    let active = true
    loadRemoteWorkspace(initialCampaigns, initialContent)
      .then((workspace) => {
        if (!active) return
        setStorageMode(workspace.mode)
        if (workspace.mode === 'supabase') {
          if (workspace.campaigns.length) setCampaigns(workspace.campaigns)
          if (workspace.content.length) setContent(workspace.content)
        }
      })
      .catch((error: unknown) => {
        if (!active) return
        setStorageMode('local')
        toast({
          title: 'تعذّر تحميل قاعدة التسويق',
          description: error instanceof Error ? error.message : 'تم تشغيل الوضع المحلي مؤقتاً.',
          variant: 'destructive',
        })
      })
    return () => { active = false }
  }, [toast])

  const metrics = useMemo(() => ({
    activeCampaigns: campaigns.filter((item) => item.status === 'active').length,
    waitingApproval: content.filter((item) => item.status === 'review' || item.status === 'draft').length,
    scheduled: content.filter((item) => item.status === 'scheduled' || item.status === 'approved').length,
    published: content.filter((item) => item.status === 'published').length,
  }), [campaigns, content])

  const filteredContent = useMemo(() => content.filter((item) =>
    `${item.title} ${item.body}`.toLowerCase().includes(query.toLowerCase()),
  ), [content, query])

  function updateStatus(id: string, status: ContentStatus) {
    setContent((items) => items.map((item) => item.id === id ? { ...item, status } : item))
    setSelectedContent((item) => item?.id === id ? { ...item, status } : item)
    if (storageMode === 'supabase') {
      void persistContentStatus(id, status).catch((error: unknown) => {
        toast({ title: 'تعذّر حفظ حالة المحتوى', description: error instanceof Error ? error.message : 'جرّب مرة ثانية.', variant: 'destructive' })
      })
    }
  }

  function createCampaign(payload: Omit<Campaign, 'id' | 'progress' | 'status'>) {
    const campaign: Campaign = {
      ...payload,
      id: crypto.randomUUID(),
      progress: 0,
      status: 'draft',
    }
    const generatedItems = generateWeekPlan(campaign)
    setCampaigns((items) => [campaign, ...items])
    setContent((items) => [...generatedItems, ...items])
    setCreateOpen(false)
    setView('campaigns')
    if (storageMode === 'supabase') {
      void upsertCampaignBundle(campaign, generatedItems)
        .then(() => toast({ title: 'تم إنشاء الحملة', description: 'تم حفظ الحملة وخطة الأسبوع في Supabase.' }))
        .catch((error: unknown) => toast({ title: 'تم إنشاء الحملة محلياً فقط', description: error instanceof Error ? error.message : 'تعذّر الحفظ في Supabase.', variant: 'destructive' }))
    }
  }

  function toggleCampaign(id: string) {
    const campaign = campaigns.find((item) => item.id === id)
    if (!campaign) return
    const status: Campaign['status'] = campaign.status === 'active' ? 'paused' : 'active'
    setCampaigns((items) => items.map((item) => item.id === id ? { ...item, status } : item))
    if (storageMode === 'supabase') {
      void persistCampaignStatus(id, status).catch((error: unknown) => {
        toast({ title: 'تعذّر حفظ حالة الحملة', description: error instanceof Error ? error.message : 'جرّب مرة ثانية.', variant: 'destructive' })
      })
    }
  }

  return (
    <div className="marketing-os" dir="rtl">
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? 'open' : ''}`}>
        <button className="mobile-close" onClick={() => setMenuOpen(false)} aria-label="إغلاق القائمة"><X /></button>
        <div className="brand">
          <div className="brand-logo"><img src={LOGO_URL} alt="Dawai" /></div>
          <div><strong>Dawai</strong><span>AI Marketing OS</span></div>
        </div>
        <nav>
          {navigation.map((item) => {
            const Icon = item.icon
            return (
              <button key={item.id} className={view === item.id ? 'active' : ''} onClick={() => { setView(item.id); setMenuOpen(false) }}>
                <Icon size={19} /><span>{item.label}</span>
              </button>
            )
          })}
        </nav>
        <div className="sidebar-card">
          <ShieldCheck size={22} />
          <strong>بوابة الموافقة مفعّلة</strong>
          <p>لا يتم نشر أي محتوى قبل موافقة مالك المنصة.</p>
        </div>
        <div className="sidebar-footer">
          <div className={`connection-dot ${storageMode === 'supabase' ? 'online' : ''}`} />
          <span>{storageMode === 'checking' ? 'جاري فحص قاعدة التسويق' : storageMode === 'supabase' ? 'Supabase متصل' : 'وضع محلي — شغّل ملف SQL'}</span>
        </div>
      </aside>

      <main>
        <header className="topbar">
          <button className="menu-button" onClick={() => setMenuOpen(true)} aria-label="فتح القائمة"><Menu /></button>
          <div className="topbar-title">
            <span>دواؤك أقرب</span>
            <h1>{navigation.find((item) => item.id === view)?.label}</h1>
          </div>
          <div className="topbar-actions">
            <button className="ghost-button owner-back-button" onClick={() => navigate('/owner')}><ArrowRight size={17} />لوحة المالك</button>
            <div className="search-box"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="بحث في المحتوى..." /></div>
            <button className="primary-button" onClick={() => setCreateOpen(true)}><Plus size={18} />حملة جديدة</button>
          </div>
        </header>

        <section className="page-content">
          {view === 'overview' && <Overview metrics={metrics} campaigns={campaigns} content={content} setView={setView} setSelectedContent={setSelectedContent} />}
          {view === 'campaigns' && <Campaigns campaigns={campaigns} onToggle={toggleCampaign} />}
          {view === 'calendar' && <Calendar content={filteredContent} setSelectedContent={setSelectedContent} />}
          {view === 'content' && <ContentLibrary content={filteredContent} setSelectedContent={setSelectedContent} updateStatus={updateStatus} />}
          {view === 'agents' && <Agents />}
          {view === 'analytics' && <Analytics />}
          {view === 'connections' && <Connections storageMode={storageMode} />}
        </section>
      </main>

      {createOpen && <CampaignModal onClose={() => setCreateOpen(false)} onCreate={createCampaign} />}
      {selectedContent && <ContentDrawer item={selectedContent} onClose={() => setSelectedContent(null)} updateStatus={updateStatus} />}
      {menuOpen && <div className="sidebar-backdrop" onClick={() => setMenuOpen(false)} />}
    </div>
    </div>
  )
}

function Overview({ metrics, campaigns, content, setView, setSelectedContent }: {
  metrics: { activeCampaigns: number; waitingApproval: number; scheduled: number; published: number }
  campaigns: Campaign[]
  content: ContentItem[]
  setView: (view: View) => void
  setSelectedContent: (item: ContentItem) => void
}) {
  const cards = [
    { label: 'حملات فعّالة', value: metrics.activeCampaigns, icon: Megaphone, hint: 'قيد التنفيذ الآن' },
    { label: 'تحتاج موافقة', value: metrics.waitingApproval, icon: CircleAlert, hint: 'راجعها قبل النشر' },
    { label: 'جاهزة للجدولة', value: metrics.scheduled, icon: Clock3, hint: 'محتوى معتمد' },
    { label: 'تم نشره', value: metrics.published, icon: Send, hint: 'منذ بدء النظام' },
  ]
  return (
    <>
      <div className="hero-panel">
        <div>
          <span className="eyebrow"><Sparkles size={15} /> مركز قيادة تسويق Dawai</span>
          <h2>خطّط، راجع، وجدول كل محتوى المنصة من مكان واحد.</h2>
          <p>نسخة أولى عملية بهوية Dawai، مع موافقة إلزامية ومنع الادعاءات الطبية أو الأرقام والشراكات غير المثبتة.</p>
          <div className="hero-actions"><button className="primary-button" onClick={() => setView('calendar')}>فتح تقويم المحتوى <ChevronLeft size={18} /></button><button className="ghost-button" onClick={() => setView('agents')}>عرض فريق الـ AI</button></div>
        </div>
        <div className="hero-orbit" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="hero-mark"><img src={LOGO_URL} alt="" /></div></div>
      </div>

      <div className="metric-grid">
        {cards.map((card) => { const Icon = card.icon; return <article className="metric-card" key={card.label}><div className="metric-icon"><Icon size={21} /></div><div><span>{card.label}</span><strong>{card.value}</strong><small>{card.hint}</small></div></article> })}
      </div>

      <div className="two-column">
        <section className="panel">
          <div className="panel-heading"><div><span>الحملات</span><h3>الحملات الحالية</h3></div><button className="text-button" onClick={() => setView('campaigns')}>عرض الكل</button></div>
          <div className="campaign-stack">
            {campaigns.slice(0, 3).map((campaign) => <CampaignRow campaign={campaign} key={campaign.id} />)}
          </div>
        </section>
        <section className="panel">
          <div className="panel-heading"><div><span>الموافقة</span><h3>المحتوى الذي يحتاج قرارك</h3></div><button className="text-button" onClick={() => setView('content')}>مكتبة المحتوى</button></div>
          <div className="approval-list">
            {content.filter((item) => item.status === 'review' || item.status === 'draft').slice(0, 4).map((item) => <button key={item.id} className="approval-item" onClick={() => setSelectedContent(item)}><ChannelBadge channel={item.channel} /><div><strong>{item.title}</strong><span>{statusLabels[item.status]} · {formatDate(item.scheduledAt)}</span></div><ChevronLeft size={17} /></button>)}
          </div>
        </section>
      </div>
    </>
  )
}

function Campaigns({ campaigns, onToggle }: { campaigns: Campaign[]; onToggle: (id: string) => void }) {
  return <div className="panel full-panel"><div className="panel-heading"><div><span>إدارة الحملات</span><h3>كل الحملات التسويقية</h3></div><span className="muted">{campaigns.length} حملات</span></div><div className="campaign-table">{campaigns.map((campaign) => <div className="campaign-card" key={campaign.id}><div className="campaign-card-top"><div><span className={`status-pill ${campaign.status}`}>{campaign.status === 'active' ? 'فعّالة' : campaign.status === 'paused' ? 'متوقفة' : campaign.status === 'draft' ? 'مسودة' : 'مكتملة'}</span><h3>{campaign.name}</h3><p>{campaign.objective}</p></div><button className="icon-button" onClick={() => onToggle(campaign.id)}>{campaign.status === 'active' ? <Pause size={18} /> : <Play size={18} />}</button></div><div className="campaign-meta"><span>الجمهور: {campaign.audience}</span><span>{campaign.startDate} — {campaign.endDate}</span></div><div className="channel-row">{campaign.channels.map((channel) => <ChannelBadge channel={channel} key={channel} />)}</div><div className="progress-row"><div className="progress-track"><span style={{ width: `${campaign.progress}%` }} /></div><strong>{campaign.progress}%</strong></div></div>)}</div></div>
}

function Calendar({ content, setSelectedContent }: { content: ContentItem[]; setSelectedContent: (item: ContentItem) => void }) {
  const days = Array.from({ length: 7 }, (_, index) => {
    const day = new Date('2026-07-14T12:00:00+03:00')
    day.setDate(day.getDate() + index)
    return day
  })
  return <div className="panel full-panel"><div className="panel-heading"><div><span>أسبوع الإطلاق</span><h3>14 — 20 تموز 2026</h3></div><span className="legend"><i className="legend-approved" /> موافق عليه <i className="legend-review" /> مراجعة</span></div><div className="calendar-grid">{days.map((day) => { const dayItems = content.filter((item) => new Date(item.scheduledAt).toDateString() === day.toDateString()); return <div className="calendar-day" key={day.toISOString()}><div className="calendar-date"><span>{new Intl.DateTimeFormat('ar-IQ', { weekday: 'short' }).format(day)}</span><strong>{day.getDate()}</strong></div><div className="calendar-items">{dayItems.length ? dayItems.map((item) => <button key={item.id} onClick={() => setSelectedContent(item)} className={`calendar-item ${item.status}`}><ChannelBadge channel={item.channel} compact /><strong>{item.title}</strong><small>{new Intl.DateTimeFormat('ar-IQ', { hour: 'numeric', minute: '2-digit' }).format(new Date(item.scheduledAt))}</small></button>) : <span className="empty-day">لا يوجد محتوى</span>}</div></div> })}</div></div>
}

function ContentLibrary({ content, setSelectedContent, updateStatus }: { content: ContentItem[]; setSelectedContent: (item: ContentItem) => void; updateStatus: (id: string, status: ContentStatus) => void }) {
  return <div className="panel full-panel"><div className="panel-heading"><div><span>الأصول والنسخ</span><h3>مكتبة المحتوى</h3></div><span className="muted">{content.length} عناصر</span></div><div className="content-table"><div className="content-head"><span>المحتوى</span><span>القناة</span><span>الموعد</span><span>الحالة</span><span>إجراء</span></div>{content.map((item) => <div className="content-row" key={item.id}><button className="content-title" onClick={() => setSelectedContent(item)}><span className="type-icon">{item.type === 'email' ? <Mail size={18} /> : item.type === 'reel' ? <Video size={18} /> : <FileText size={18} />}</span><div><strong>{item.title}</strong><small>{item.body}</small></div></button><ChannelBadge channel={item.channel} /><span className="date-cell">{formatDate(item.scheduledAt)}</span><span className={`content-status ${item.status}`}>{statusLabels[item.status]}</span><div className="row-actions">{item.status !== 'approved' && item.status !== 'scheduled' && item.status !== 'published' && <button className="approve-button" onClick={() => updateStatus(item.id, 'approved')}><Check size={16} />موافقة</button>}<button className="icon-button" onClick={() => setSelectedContent(item)}><ChevronLeft size={17} /></button></div></div>)}</div></div>
}

function Agents() {
  return <><div className="agents-intro"><div><span className="eyebrow"><Bot size={16} /> فريق افتراضي منظم</span><h2>كل وكيل عنده وظيفة واضحة، والقرار النهائي يبقى إلك.</h2></div><div className="agent-pulse"><Activity size={22} /><span>3 مهام تعمل الآن</span></div></div><div className="agent-grid">{agents.map((agent) => <article className="agent-card" key={agent.id}><div className="agent-avatar"><Bot size={24} /></div><div className="agent-header"><span className={`agent-status ${agent.status}`}>{agent.status === 'working' ? 'يعمل الآن' : agent.status === 'review' ? 'مراجعة' : 'جاهز'}</span><strong>{agent.name}</strong></div><p>{agent.role}</p><div className="agent-footer"><span>{agent.tasks} مهام</span><button className="text-button">فتح السجل</button></div></article>)}</div><section className="panel workflow-panel"><div className="panel-heading"><div><span>تدفق العمل</span><h3>من الفكرة إلى النشر</h3></div></div><div className="workflow"><div><strong>1</strong><span>تخطيط الحملة</span></div><i /><div><strong>2</strong><span>إنشاء النص والتصميم</span></div><i /><div><strong>3</strong><span>فحص الادعاءات والخصوصية</span></div><i /><div><strong>4</strong><span>موافقة المالك</span></div><i /><div><strong>5</strong><span>جدولة ونشر</span></div></div></section></>
}

function Analytics() {
  const bars = [34, 52, 47, 68, 61, 82, 74]
  return <><div className="metric-grid"><article className="metric-card"><div className="metric-icon"><Activity /></div><div><span>الوصول</span><strong>—</strong><small>يظهر بعد ربط الحسابات</small></div></article><article className="metric-card"><div className="metric-icon"><Video /></div><div><span>المشاهدات</span><strong>—</strong><small>Instagram + TikTok</small></div></article><article className="metric-card"><div className="metric-icon"><Mail /></div><div><span>فتح الإيميل</span><strong>—</strong><small>يتطلب مزود بريد</small></div></article><article className="metric-card"><div className="metric-icon"><BarChart3 /></div><div><span>التسجيلات</span><strong>—</strong><small>يتطلب أحداث تحويل</small></div></article></div><section className="panel full-panel"><div className="panel-heading"><div><span>معاينة</span><h3>اتجاه الأداء الأسبوعي</h3></div><span className="muted">بيانات تجريبية للواجهة</span></div><div className="chart"><div className="chart-bars">{bars.map((height, index) => <div className="bar-column" key={index}><span style={{ height: `${height}%` }} /><small>{['س','ح','ن','ث','ر','خ','ج'][index]}</small></div>)}</div></div></section></>
}

function Connections({ storageMode }: { storageMode: MarketingStorageMode }) {
  const integrations = [
    { name: 'Instagram Business', description: 'النشر والجدولة وقراءة مؤشرات الأداء.', icon: Instagram, status: 'غير مربوط' },
    { name: 'TikTok Business', description: 'رفع الفيديوهات وجدولتها عبر التكامل الرسمي.', icon: Video, status: 'غير مربوط' },
    { name: 'Email Marketing', description: 'إرسال حملات فقط إلى جهات اتصال لديها موافقة.', icon: Mail, status: 'غير مربوط' },
    { name: 'Supabase', description: 'الحملات والمحتوى والموافقات والسجلات.', icon: Activity, status: storageMode === 'supabase' ? 'مربوط' : storageMode === 'checking' ? 'جاري الفحص' : 'شغّل SQL' },
  ]
  return <><div className="security-note"><ShieldCheck size={24} /><div><strong>لا تدخل كلمات المرور أو رموز التحقق داخل المشروع.</strong><p>الربط النهائي يتم عبر OAuth أو أسرار محفوظة داخل Supabase Edge Functions، وليس داخل واجهة React.</p></div></div><div className="connections-grid">{integrations.map((integration) => { const Icon = integration.icon; return <article className="connection-card" key={integration.name}><div className="connection-icon"><Icon size={25} /></div><div><strong>{integration.name}</strong><p>{integration.description}</p></div><div className="connection-footer"><span className={integration.status === 'مربوط' ? 'connected' : ''}>{integration.status}</span><button className="ghost-button" disabled>ربط رسمي</button></div></article> })}</div><section className="panel full-panel compliance-panel"><div className="panel-heading"><div><span>قواعد Dawai</span><h3>ضوابط النشر الإلزامية</h3></div></div><div className="rules-grid"><div><Check />لا ادعاءات طبية أو علاجية غير موثقة.</div><div><Check />لا اختلاق أرقام، شراكات أو شهادات.</div><div><Check />الحفاظ على خصوصية الوصفات والمرضى.</div><div><Check />موافقة المالك قبل أي نشر خارجي.</div><div><Check />الإيميل التسويقي للمشتركين الموافقين فقط.</div><div><Check />استخدام أصول وموسيقى مرخصة تجارياً.</div></div></section></>
}

function CampaignRow({ campaign }: { campaign: Campaign }) {
  return <div className="campaign-row"><div className="campaign-symbol"><Megaphone size={18} /></div><div className="campaign-row-main"><strong>{campaign.name}</strong><span>{campaign.objective}</span><div className="mini-progress"><i style={{ width: `${campaign.progress}%` }} /></div></div><span className={`status-pill ${campaign.status}`}>{campaign.status === 'active' ? 'فعّالة' : 'مسودة'}</span></div>
}

function ChannelBadge({ channel, compact = false }: { channel: Channel; compact?: boolean }) {
  const meta = channelMeta[channel]
  const Icon = meta.icon
  return <span className={`channel-badge ${meta.className} ${compact ? 'compact' : ''}`}><Icon size={compact ? 13 : 15} />{!compact && meta.label}</span>
}

function CampaignModal({ onClose, onCreate }: { onClose: () => void; onCreate: (payload: Omit<Campaign, 'id' | 'progress' | 'status'>) => void }) {
  const [name, setName] = useState('حملة إطلاق جديدة')
  const [objective, setObjective] = useState('زيادة الوعي والتسجيل في منصة Dawai')
  const [audience, setAudience] = useState('مستخدمو الأدوية والمنتجات الصحية داخل العراق')
  const [channels, setChannels] = useState<Channel[]>(['instagram', 'tiktok'])
  const [startDate, setStartDate] = useState('2026-07-14')
  const [endDate, setEndDate] = useState('2026-08-12')

  function toggle(channel: Channel) {
    setChannels((items) => items.includes(channel) ? items.filter((item) => item !== channel) : [...items, channel])
  }
  function submit(event: React.FormEvent) {
    event.preventDefault()
    if (!name.trim() || !channels.length) return
    onCreate({ name, objective, audience, channels, startDate, endDate })
  }
  return <div className="modal-backdrop"><form className="modal" onSubmit={submit}><div className="modal-header"><div><span>إنشاء تلقائي</span><h2>حملة تسويقية جديدة</h2></div><button type="button" className="icon-button" onClick={onClose}><X /></button></div><label>اسم الحملة<input value={name} onChange={(event) => setName(event.target.value)} /></label><label>الهدف<textarea value={objective} onChange={(event) => setObjective(event.target.value)} /></label><label>الجمهور<textarea value={audience} onChange={(event) => setAudience(event.target.value)} /></label><div className="form-label">القنوات<div className="channel-picker">{(['instagram', 'tiktok', 'email'] as Channel[]).map((channel) => <button type="button" key={channel} className={channels.includes(channel) ? 'selected' : ''} onClick={() => toggle(channel)}><ChannelBadge channel={channel} />{channels.includes(channel) && <Check size={16} />}</button>)}</div></div><div className="date-grid"><label>تاريخ البداية<input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} /></label><label>تاريخ النهاية<input type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} /></label></div><div className="modal-note"><Sparkles size={18} />سيتم إنشاء خطة أولية من 7 قطع محتوى كمسودات تحتاج موافقتك.</div><div className="modal-actions"><button type="button" className="ghost-button" onClick={onClose}>إلغاء</button><button className="primary-button" type="submit"><Sparkles size={18} />إنشاء الحملة والخطة</button></div></form></div>
}

function ContentDrawer({ item, onClose, updateStatus }: { item: ContentItem; onClose: () => void; updateStatus: (id: string, status: ContentStatus) => void }) {
  return <div className="drawer-backdrop" onClick={onClose}><aside className="drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-header"><div><ChannelBadge channel={item.channel} /><h2>{item.title}</h2></div><button className="icon-button" onClick={onClose}><X /></button></div><div className="content-preview"><span className="preview-label">معاينة النص</span><p>{item.body}</p><div className="preview-brand"><img src={LOGO_URL} alt="Dawai" /><div><strong>Dawai | دوائي</strong><span>دواؤك أقرب</span></div></div></div><div className="detail-list"><div><span>نوع المحتوى</span><strong>{item.type}</strong></div><div><span>موعد النشر</span><strong>{formatDate(item.scheduledAt)}</strong></div><div><span>الحالة</span><strong>{statusLabels[item.status]}</strong></div></div><div className="quality-check"><h3>فحص الجودة</h3><p><Check /> لا توجد أرقام أو شراكات مخترعة.</p><p><Check /> لا توجد نصيحة أو ادعاء طبي.</p><p><Check /> CTA واضح ومتوافق مع هوية Dawai.</p></div><div className="drawer-actions"><button className="ghost-button" onClick={() => updateStatus(item.id, 'draft')}>إرجاع للمسودة</button><button className="primary-button" onClick={() => updateStatus(item.id, 'approved')}><Check size={18} />موافقة المحتوى</button></div></aside></div>
}

