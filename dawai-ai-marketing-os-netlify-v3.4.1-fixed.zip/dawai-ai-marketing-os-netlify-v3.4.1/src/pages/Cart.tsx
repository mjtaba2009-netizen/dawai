import { useContext, useMemo, useState } from 'react';
import { formatIQD } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ShoppingCart, Trash2, Plus, Minus, ChevronRight, Pill, ShieldCheck, Store, Gift, Star, Crown, Tag, Loader2, Banknote, WalletCards, CreditCard } from 'lucide-react';
import { useCreateOrder, useLoyaltyWallet, useMySubscription, usePublicOffers, useQuoteOrder } from '@/services/hooks';
import { useCart } from '@/contexts/CartContext';
import { PrescriptionModal } from '@/components/PrescriptionModal';
import { useToast } from '@/hooks/use-toast';
import { AuthContext } from '@/contexts/AuthContext';
import type { PaymentMethod, PrescriptionSubmission } from '@/services/types';
import { getErrorMessage } from '@/lib/error';

export function Cart() {
  const { items, removeItem, updateQty, clearCart, totalCount, totalPrice, hasPrescriptionItem } = useCart();
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  const createOrder = useCreateOrder();
  const quoteOrder = useQuoteOrder();
  const { data: wallet } = useLoyaltyWallet(auth?.user?.id);
  const { data: subscription } = useMySubscription(auth?.user?.id);
  const { data: offers = [] } = usePublicOffers();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [showRxGate, setShowRxGate] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState('');
  const [usePoints, setUsePoints] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash_on_delivery');

  const rxItemName = items.find((item) => item.requiresPrescription)?.name ?? 'طلبك';
  const discountTarget = useMemo(() => [...items].sort((a, b) => b.price * b.quantity - a.price * a.quantity)[0], [items]);
  const maxRedeemPoints = Math.min(wallet?.points ?? 0, Math.floor(((discountTarget?.price ?? 0) * (discountTarget?.quantity ?? 0) * 0.2) / 10));
  const estimatedDelivery = subscription?.status === 'active' ? 1000 : 2500;
  const appliedQuote = quoteOrder.data;
  const estimatedTotal = appliedQuote?.total ?? Math.max(0, totalPrice + (items.length ? estimatedDelivery : 0));

  const applyCoupon = async (code = couponCode) => {
    if (!discountTarget) return;
    try {
      const result = await quoteOrder.mutateAsync({
        pharmacyId: discountTarget.pharmacyId,
        subtotal: discountTarget.price * discountTarget.quantity,
        couponCode: code || null,
        redeemPoints: usePoints ? maxRedeemPoints : 0,
      });
      if (code && !result.valid) {
        setCouponApplied('');
        toast({ title: 'الكوبون غير صالح', description: result.message, variant: 'destructive' });
        return;
      }
      setCouponApplied(result.code || '');
      setCouponCode(result.code || code.toUpperCase());
      toast({ title: code ? 'تم تطبيق الخصم' : 'تم تحديث الخصم', description: result.message });
    } catch (error) {
      toast({ title: 'تعذّر التحقق من الخصم', description: getErrorMessage(error, 'شغّل SQL الإصدار 2.7'), variant: 'destructive' });
    }
  };

  const togglePoints = async () => {
    const next = !usePoints;
    setUsePoints(next);
    if (!discountTarget) return;
    try {
      await quoteOrder.mutateAsync({
        pharmacyId: discountTarget.pharmacyId,
        subtotal: discountTarget.price * discountTarget.quantity,
        couponCode: couponApplied || null,
        redeemPoints: next ? maxRedeemPoints : 0,
      });
    } catch { /* message appears when checkout is attempted */ }
  };

  const submitOrders = async (prescription?: PrescriptionSubmission | null) => {
    if (!items.length) return;
    setSubmitting(true);
    const orderedItems = [...items].sort((a, b) => b.price * b.quantity - a.price * a.quantity);
    const succeeded: number[] = [];
    let failures = 0;
    let firstError = '';

    try {
      for (let index = 0; index < orderedItems.length; index++) {
        const item = orderedItems[index];
        try {
          await createOrder.mutateAsync({
            pharmacyId: item.pharmacyId,
            medicationId: item.medicationId,
            quantity: item.quantity,
            prescriptionId: item.requiresPrescription ? prescription?.id ?? null : null,
            couponCode: index === 0 ? couponApplied || null : null,
            redeemPoints: index === 0 && usePoints ? maxRedeemPoints : 0,
            paymentMethod,
          });
          succeeded.push(item.id);
        } catch (error) {
          failures++;
          if (!firstError) firstError = getErrorMessage(error);
        }
      }

      if (failures === 0) {
        clearCart();
        setShowRxGate(false);
        toast({ title: 'تم إرسال جميع الطلبات بنجاح', description: 'يمكنك متابعة الحالة من صفحة طلباتي', duration: 4000 });
        navigate('/orders');
      } else {
        succeeded.forEach(removeItem);
        toast({ title: 'تعذّر إرسال بعض الطلبات', description: firstError || 'حاول مرة أخرى للطلبات المتبقية', variant: 'destructive' });
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleCheckout = () => {
    if (!items.length || submitting) return;
    if (hasPrescriptionItem) setShowRxGate(true);
    else void submitOrders(null);
  };

  return (
    <>
      <div className="flex-1 flex flex-col bg-muted/20" dir="rtl">
        <div className="relative bg-gradient-to-br from-teal-500 via-teal-600 to-teal-700 px-5 pt-10 pb-6">
          <div className="flex items-center justify-between"><div><h2 className="text-white text-2xl font-bold">سلة المشتريات</h2><p className="text-teal-100 text-sm mt-1">{totalCount ? `${totalCount} عنصر` : 'سلتك فارغة حالياً'}</p></div><div className="w-12 h-12 bg-white/20 rounded-2xl border border-white/30 flex items-center justify-center"><ShoppingCart className="w-6 h-6 text-white" /></div></div>
        </div>

        <div className="flex-1 px-4 pt-5 pb-48 overflow-y-auto">
          {!items.length ? (
            <div className="flex flex-col items-center justify-center py-16 text-center"><div className="w-20 h-20 rounded-3xl bg-teal-50 flex items-center justify-center mb-4"><ShoppingCart className="w-9 h-9 text-teal-300" /></div><p className="text-slate-700 font-bold">سلتك فارغة</p><p className="text-slate-400 text-sm mt-2 mb-5">تصفّح الأدوية والمنتجات وأضفها للسلة</p><button onClick={() => navigate('/home')} className="h-11 px-6 rounded-xl bg-teal-500 text-white font-bold flex items-center gap-2">تصفّح المنتجات<ChevronRight className="w-4 h-4" /></button></div>
          ) : <div className="space-y-4">
            <div className="space-y-3">
              <AnimatePresence initial={false}>{items.map((item) => (
                <motion.div key={item.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.96 }} className="rounded-2xl p-3.5 bg-white border border-slate-100 shadow-sm">
                  <div className="flex items-start gap-3"><div className="w-14 h-14 rounded-xl bg-teal-50 flex items-center justify-center overflow-hidden">{item.imageUrl ? <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" /> : <Pill className="w-6 h-6 text-teal-500" />}</div><div className="flex-1 min-w-0"><p className="font-bold text-slate-800 text-sm truncate">{item.name}</p><p className="text-slate-400 text-xs flex items-center gap-1 mt-1"><Store className="w-3 h-3" />{item.pharmacyName}</p><div className="flex items-center gap-2 mt-2"><span className="text-teal-700 font-extrabold">{formatIQD(item.price)}</span>{item.requiresPrescription && <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 flex items-center gap-1"><ShieldCheck className="w-3 h-3" />وصفة</span>}</div></div><button onClick={() => removeItem(item.id)} className="w-8 h-8 rounded-xl bg-red-50 text-red-500 flex items-center justify-center"><Trash2 className="w-4 h-4" /></button></div>
                  <div className="mt-3 flex items-center justify-between"><span className="font-extrabold text-slate-800">{formatIQD(item.price * item.quantity)}</span><div className="flex items-center gap-2 rounded-xl bg-slate-50 p-1"><button onClick={() => updateQty(item.id, item.quantity - 1)} className="w-8 h-8 rounded-lg bg-white flex items-center justify-center"><Minus className="w-4 h-4" /></button><span className="w-7 text-center font-bold">{item.quantity}</span><button onClick={() => updateQty(item.id, item.quantity + 1)} className="w-8 h-8 rounded-lg bg-teal-500 text-white flex items-center justify-center"><Plus className="w-4 h-4" /></button></div></div>
                </motion.div>
              ))}</AnimatePresence>
            </div>

            <section className="rounded-3xl bg-white border border-slate-100 p-4 shadow-sm" aria-labelledby="payment-method-title">
              <div className="flex items-center gap-2 mb-3"><Banknote className="w-5 h-5 text-teal-600" /><h3 id="payment-method-title" className="font-extrabold text-slate-900">طريقة الدفع</h3></div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { value: 'cash_on_delivery', label: 'نقداً', icon: Banknote },
                  { value: 'wallet', label: 'محفظة', icon: WalletCards },
                  { value: 'card_on_delivery', label: 'بطاقة عند الاستلام', icon: CreditCard },
                ].map(({ value, label, icon: Icon }) => <button type="button" key={value} onClick={() => setPaymentMethod(value as PaymentMethod)} className={`min-h-20 rounded-2xl border px-2 py-3 text-xs font-bold flex flex-col items-center justify-center gap-2 transition ${paymentMethod === value ? 'border-teal-500 bg-teal-50 text-teal-700 ring-2 ring-teal-100' : 'border-slate-200 bg-white text-slate-500'}`} aria-pressed={paymentMethod === value}><Icon className="w-5 h-5" />{label}</button>)}
              </div>
              <p className="mt-3 text-[10px] leading-5 text-slate-400">المنصة لا تخزّن أرقام البطاقات. خيار البطاقة يعني الدفع بجهاز المتجر أو المندوب عند الاستلام.</p>
            </section>

            <section className="rounded-3xl bg-white border border-slate-100 p-4 shadow-sm">
              <div className="flex items-center gap-2 mb-3"><Tag className="w-5 h-5 text-pink-500" /><h3 className="font-extrabold text-slate-900">كوبون الخصم</h3></div>
              <div className="flex gap-2"><input value={couponCode} onChange={(e) => { setCouponCode(e.target.value.toUpperCase()); setCouponApplied(''); quoteOrder.reset(); }} placeholder="أدخل كود الكوبون" className="flex-1 h-11 rounded-xl border border-slate-200 bg-slate-50 px-3 uppercase outline-none focus:border-teal-400" dir="ltr" /><button onClick={() => void applyCoupon()} disabled={!couponCode.trim() || quoteOrder.isPending} className="h-11 px-4 rounded-xl bg-slate-900 text-white font-bold text-sm disabled:opacity-50">{quoteOrder.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تطبيق'}</button></div>
              {offers.length > 0 && <div className="flex gap-2 overflow-x-auto mt-3 no-scrollbar">{offers.slice(0, 4).map((offer) => <button key={offer.id} onClick={() => { setCouponCode(offer.code); void applyCoupon(offer.code); }} className="flex-shrink-0 px-3 py-2 rounded-xl bg-pink-50 text-pink-700 text-xs font-bold border border-pink-100">{offer.code}</button>)}</div>}
              {appliedQuote?.message && <p className={`text-xs mt-2 ${appliedQuote.valid || !couponApplied ? 'text-teal-600' : 'text-red-600'}`}>{appliedQuote.message}</p>}
            </section>

            <section className="rounded-3xl bg-gradient-to-l from-amber-50 to-yellow-50 border border-amber-100 p-4">
              <div className="flex items-center gap-3"><div className="w-11 h-11 rounded-2xl bg-amber-400 text-white flex items-center justify-center"><Star className="w-5 h-5" /></div><div className="flex-1"><p className="font-extrabold text-slate-900">نقاطك: {wallet?.points ?? 0}</p><p className="text-xs text-slate-500">يمكن استخدام {maxRedeemPoints} نقطة على أكبر طلب في السلة</p></div><button onClick={() => void togglePoints()} disabled={maxRedeemPoints <= 0} className={`w-12 h-7 rounded-full p-1 transition ${usePoints ? 'bg-teal-500' : 'bg-slate-200'} disabled:opacity-40`}><span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${usePoints ? '-translate-x-5' : ''}`} /></button></div>
            </section>

            {subscription?.status === 'active' && <section className="rounded-2xl bg-teal-50 border border-teal-100 p-3 flex items-center gap-2 text-teal-800 text-xs"><Crown className="w-4 h-4 text-amber-500" /><strong>دوائي بلس فعّال:</strong> تم احتساب خصم التوصيل تلقائياً.</section>}

            <section className="rounded-3xl bg-white border border-slate-100 p-4 shadow-sm space-y-2 text-sm">
              <div className="flex justify-between text-slate-500"><span>قيمة المنتجات</span><span>{formatIQD(totalPrice)}</span></div>
              <div className="flex justify-between text-slate-500"><span>التوصيل التقديري</span><span>{formatIQD(appliedQuote?.deliveryFee ?? estimatedDelivery)}</span></div>
              {(appliedQuote?.couponDiscount ?? 0) > 0 && <div className="flex justify-between text-teal-600"><span>خصم الكوبون</span><span>- {formatIQD(appliedQuote!.couponDiscount)}</span></div>}
              {(appliedQuote?.pointsDiscount ?? 0) > 0 && <div className="flex justify-between text-amber-600"><span>خصم النقاط</span><span>- {formatIQD(appliedQuote!.pointsDiscount)}</span></div>}
              {(appliedQuote?.subscriptionDiscount ?? 0) > 0 && <div className="flex justify-between text-teal-600"><span>خصم دوائي بلس</span><span>- {formatIQD(appliedQuote!.subscriptionDiscount)}</span></div>}
              <div className="border-t border-dashed pt-3 flex justify-between font-extrabold text-slate-900"><span>الإجمالي التقديري</span><span>{formatIQD(estimatedTotal + Math.max(0, totalPrice - (appliedQuote?.subtotal ?? totalPrice)))}</span></div>
              <p className="text-[10px] text-slate-400 leading-4">عند وجود منتجات من أكثر من متجر قد تُحسب أجرة توصيل لكل متجر. الكوبون والنقاط يطبقان على أكبر طلب.</p>
            </section>
          </div>}
        </div>

        {items.length > 0 && <div className="fixed bottom-[calc(64px+env(safe-area-inset-bottom))] left-0 right-0 z-40 flex justify-center pointer-events-none"><div className="w-full max-w-[430px] pointer-events-auto px-4 pb-3"><motion.button whileTap={{ scale: 0.98 }} onClick={handleCheckout} disabled={submitting} className="w-full h-14 rounded-2xl bg-gradient-to-r from-teal-500 to-teal-600 text-white font-extrabold shadow-xl shadow-teal-600/25 flex items-center justify-center gap-2 disabled:opacity-60">{submitting ? <><Loader2 className="w-5 h-5 animate-spin" />جاري إرسال الطلبات...</> : <><ShoppingCart className="w-5 h-5" />إتمام الطلب</>}</motion.button></div></div>}
      </div>

      <AnimatePresence>{showRxGate && <PrescriptionModal medicationName={rxItemName} onConfirm={(prescription) => submitOrders(prescription)} onClose={() => setShowRxGate(false)} />}</AnimatePresence>
    </>
  );
}
