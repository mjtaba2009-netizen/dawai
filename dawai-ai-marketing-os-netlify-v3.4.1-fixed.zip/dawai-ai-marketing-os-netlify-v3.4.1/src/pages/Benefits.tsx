import { useContext, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  ArrowRight, BellRing, CalendarClock, Check, Clock3, Copy, Crown, Gift,
  Loader2, Plus, Sparkles, Star, Trash2, X, Zap,
} from 'lucide-react';
import { AuthContext } from '@/contexts/AuthContext';
import {
  useCreateMedicineReminder,
  useDeleteMedicineReminder,
  useLoyaltyWallet,
  useMedicineReminders,
  useMySubscription,
  usePublicOffers,
  useRequestSubscription,
  useUpdateMedicineReminder,
} from '@/services/hooks';
import { useToast } from '@/hooks/use-toast';
import { formatIQD } from '@/lib/utils';
import { getErrorMessage } from '@/lib/error';

function formatDate(value: string | null) {
  if (!value) return '—';
  return new Date(value).toLocaleDateString('ar-IQ', { day: 'numeric', month: 'long', year: 'numeric' });
}

function ReminderModal({ onClose, initialName = '', initialMedicationId = null }: { onClose: () => void; initialName?: string; initialMedicationId?: number | null }) {
  const createReminder = useCreateMedicineReminder();
  const { toast } = useToast();
  const [name, setName] = useState(initialName);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('09:00');
  const [repeatDays, setRepeatDays] = useState('30');
  const [notes, setNotes] = useState('');

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!name.trim() || !date || !time) return;
    try {
      await createReminder.mutateAsync({
        medicationId: initialMedicationId,
        medicationName: name,
        nextReminderAt: new Date(`${date}T${time}`).toISOString(),
        repeatDays: Math.max(1, Number(repeatDays) || 30),
        notes,
      });
      toast({ title: 'تم إنشاء التنبيه', description: `سنذكّرك بإعادة طلب ${name}` });
      onClose();
    } catch (error) {
      toast({ title: 'تعذّر إنشاء التنبيه', description: getErrorMessage(error), variant: 'destructive' });
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-950/50 backdrop-blur-sm" dir="rtl">
      <motion.form initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 28, stiffness: 300 }} onSubmit={handleSubmit} className="w-full max-w-[430px] rounded-t-[30px] bg-white p-5 pb-[calc(env(safe-area-inset-bottom)+20px)]">
        <div className="flex items-center justify-between mb-5">
          <button type="button" onClick={onClose} className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center"><X className="w-4 h-4" /></button>
          <div className="text-right"><h2 className="font-extrabold text-slate-900">تنبيه قرب نفاد الدواء</h2><p className="text-xs text-slate-400">حدد موعد إعادة الطلب والتكرار</p></div>
        </div>
        <div className="space-y-3">
          <label className="block"><span className="text-xs font-bold text-slate-500">اسم الدواء</span><input value={name} onChange={(e) => setName(e.target.value)} required placeholder="مثال: دواء الضغط" className="mt-1 w-full h-12 rounded-xl border border-slate-200 bg-slate-50 px-4 outline-none focus:border-teal-400" /></label>
          <div className="grid grid-cols-2 gap-2">
            <label><span className="text-xs font-bold text-slate-500">التاريخ</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} required min={new Date().toISOString().split('T')[0]} className="mt-1 w-full h-12 rounded-xl border border-slate-200 bg-slate-50 px-3 outline-none focus:border-teal-400" /></label>
            <label><span className="text-xs font-bold text-slate-500">الوقت</span><input type="time" value={time} onChange={(e) => setTime(e.target.value)} required className="mt-1 w-full h-12 rounded-xl border border-slate-200 bg-slate-50 px-3 outline-none focus:border-teal-400" /></label>
          </div>
          <label className="block"><span className="text-xs font-bold text-slate-500">التكرار كل كم يوم؟</span><select value={repeatDays} onChange={(e) => setRepeatDays(e.target.value)} className="mt-1 w-full h-12 rounded-xl border border-slate-200 bg-slate-50 px-4 outline-none"><option value="7">7 أيام</option><option value="14">14 يوم</option><option value="30">30 يوم</option><option value="60">60 يوم</option><option value="90">90 يوم</option></select></label>
          <label className="block"><span className="text-xs font-bold text-slate-500">ملاحظة اختيارية</span><textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="الجرعة أو أي ملاحظة" className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none resize-none focus:border-teal-400" /></label>
          <button disabled={createReminder.isPending || !name.trim() || !date} className="w-full h-12 rounded-2xl bg-gradient-to-r from-teal-500 to-teal-600 text-white font-extrabold flex items-center justify-center gap-2 disabled:opacity-50">
            {createReminder.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <BellRing className="w-4 h-4" />} حفظ التنبيه
          </button>
        </div>
      </motion.form>
    </motion.div>
  );
}

export function Benefits() {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  const reminderState = (location.state ?? {}) as { reminderMedicationName?: string; reminderMedicationId?: number | null };
  const { toast } = useToast();
  const userId = auth?.user?.id;
  const { data: wallet, isLoading: walletLoading } = useLoyaltyWallet(userId);
  const { data: subscription, isLoading: subscriptionLoading } = useMySubscription(userId);
  const { data: offers = [] } = usePublicOffers();
  const { data: reminders = [], isLoading: remindersLoading } = useMedicineReminders(userId);
  const requestSubscription = useRequestSubscription();
  const updateReminder = useUpdateMedicineReminder();
  const deleteReminder = useDeleteMedicineReminder();
  const [showReminder, setShowReminder] = useState(Boolean(reminderState.reminderMedicationName));

  const activeReminderCount = useMemo(() => reminders.filter((r) => r.isActive).length, [reminders]);

  const copyCode = async (code: string) => {
    try { await navigator.clipboard.writeText(code); } catch { /* Safari may block clipboard outside HTTPS */ }
    toast({ title: 'تم نسخ الكود', description: code });
  };

  const handleSubscription = async () => {
    try {
      const result = await requestSubscription.mutateAsync('dawai_plus');
      toast({
        title: result.status === 'active' ? 'اشتراكك فعّال' : 'تم إرسال طلب الاشتراك',
        description: result.status === 'active' ? `ينتهي في ${formatDate(result.endsAt)}` : 'سيظهر طلبك لمالك المنصة للموافقة عليه',
      });
    } catch (error) {
      toast({ title: 'تعذّر طلب الاشتراك', description: getErrorMessage(error), variant: 'destructive' });
    }
  };

  return (
    <>
      <div className="flex-1 flex flex-col bg-slate-50" dir="rtl">
        <header className="relative overflow-hidden bg-gradient-to-br from-slate-950 via-teal-950 to-teal-800 px-5 pt-10 pb-7 text-white">
          <div className="absolute -left-16 -top-14 w-52 h-52 rounded-full bg-amber-300/15 blur-3xl" />
          <div className="relative flex items-center gap-3">
            <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center"><ArrowRight className="w-5 h-5" /></button>
            <div><p className="text-amber-300 text-xs font-bold">مزايا دوائي</p><h1 className="text-xl font-extrabold">التوفير والصحة في مكان واحد</h1></div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto px-4 py-5 pb-24 space-y-5">
          <section className="grid grid-cols-2 gap-3">
            <div className="rounded-3xl bg-gradient-to-br from-amber-400 to-orange-500 text-white p-4 shadow-lg shadow-orange-500/20">
              <Star className="w-7 h-7 mb-4" />
              <p className="text-3xl font-black tabular-nums">{walletLoading ? '…' : wallet?.points ?? 0}</p>
              <p className="text-xs font-bold mt-1">نقطة ولاء</p>
              <p className="text-[10px] text-orange-50 mt-2">كل نقطة = 10 د.ع عند الاستبدال</p>
            </div>
            <div className="rounded-3xl bg-white border border-slate-200 p-4 shadow-sm">
              <BellRing className="w-7 h-7 text-teal-500 mb-4" />
              <p className="text-3xl font-black text-slate-900 tabular-nums">{remindersLoading ? '…' : activeReminderCount}</p>
              <p className="text-xs font-bold text-slate-600 mt-1">تنبيه دواء فعّال</p>
              <button onClick={() => setShowReminder(true)} className="text-[11px] text-teal-600 font-bold mt-2 flex items-center gap-1"><Plus className="w-3 h-3" />أضف تنبيهاً</button>
            </div>
          </section>

          <section className="relative overflow-hidden rounded-[28px] bg-gradient-to-l from-teal-600 to-emerald-600 text-white p-5 shadow-lg shadow-teal-600/15">
            <div className="absolute -left-8 -bottom-10 w-36 h-36 rounded-full bg-white/10 blur-2xl" />
            <div className="relative flex items-start gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center"><Crown className="w-6 h-6 text-amber-300" /></div>
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2"><h2 className="font-extrabold">دوائي بلس</h2>{subscription?.status === 'active' && <span className="text-[10px] bg-white/20 px-2 py-1 rounded-full font-bold">فعّال</span>}{subscription?.status === 'pending' && <span className="text-[10px] bg-amber-300/20 text-amber-100 px-2 py-1 rounded-full font-bold">بانتظار الموافقة</span>}</div>
                <p className="text-xs text-teal-50 mt-1 leading-5">اشتراك شهري بتوصيل مخفّض حتى {formatIQD(1500)} لكل طلب.</p>
                {subscription?.status === 'active' ? <p className="text-[11px] mt-3 text-teal-100">ينتهي: {formatDate(subscription.endsAt)}</p> : (
                  <button onClick={handleSubscription} disabled={requestSubscription.isPending || subscriptionLoading || subscription?.status === 'pending'} className="mt-4 h-11 px-5 rounded-xl bg-white text-teal-700 font-extrabold text-sm flex items-center gap-2 disabled:opacity-60">
                    {requestSubscription.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}{subscription?.status === 'pending' ? 'تم إرسال الطلب' : `اطلب الاشتراك — ${formatIQD(7500)}`}
                  </button>
                )}
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><Gift className="w-5 h-5 text-pink-500" /><h2 className="font-extrabold text-slate-900">الكوبونات والعروض</h2></div><span className="text-xs text-slate-400">{offers.length} عرض</span></div>
            <div className="space-y-2">
              {offers.length ? offers.map((offer) => (
                <motion.button whileTap={{ scale: 0.98 }} key={offer.id} onClick={() => copyCode(offer.code)} className="w-full rounded-2xl bg-white border border-slate-200 p-4 text-right shadow-sm flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-pink-50 text-pink-500 flex items-center justify-center"><Sparkles className="w-6 h-6" /></div>
                  <div className="flex-1 min-w-0"><p className="font-extrabold text-slate-900">{offer.title}</p><p className="text-xs text-slate-500 mt-1 truncate">{offer.description || `خصم باستخدام الكود ${offer.code}`}</p><span className="inline-flex mt-2 px-2.5 py-1 rounded-lg bg-slate-900 text-white font-mono text-xs tracking-wider">{offer.code}</span></div>
                  <Copy className="w-4 h-4 text-slate-400" />
                </motion.button>
              )) : <div className="rounded-2xl bg-white border border-slate-200 p-6 text-center text-sm text-slate-400">لا توجد عروض فعّالة حالياً</div>}
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><CalendarClock className="w-5 h-5 text-teal-500" /><h2 className="font-extrabold text-slate-900">تنبيهات إعادة الطلب</h2></div><button onClick={() => setShowReminder(true)} className="w-9 h-9 rounded-xl bg-teal-500 text-white flex items-center justify-center"><Plus className="w-4 h-4" /></button></div>
            <div className="space-y-2">
              {reminders.map((reminder) => (
                <div key={reminder.id} className="rounded-2xl bg-white border border-slate-200 p-4 shadow-sm">
                  <div className="flex items-start gap-3"><div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${reminder.isActive ? 'bg-teal-50 text-teal-600' : 'bg-slate-100 text-slate-400'}`}><Clock3 className="w-5 h-5" /></div><div className="flex-1"><p className="font-extrabold text-slate-900">{reminder.medicationName}</p><p className="text-xs text-slate-500 mt-1">الموعد: {new Date(reminder.nextReminderAt).toLocaleString('ar-IQ')}</p><p className="text-[11px] text-slate-400 mt-1">يتكرر كل {reminder.repeatDays} يوم</p></div></div>
                  <div className="flex gap-2 mt-3"><button onClick={() => updateReminder.mutate({ id: reminder.id, updates: { isActive: !reminder.isActive } })} className={`flex-1 h-9 rounded-xl text-xs font-bold ${reminder.isActive ? 'bg-amber-50 text-amber-700' : 'bg-teal-50 text-teal-700'}`}>{reminder.isActive ? 'إيقاف مؤقت' : 'تفعيل'}</button><button onClick={() => deleteReminder.mutate(reminder.id)} className="w-10 h-9 rounded-xl bg-red-50 text-red-600 flex items-center justify-center"><Trash2 className="w-4 h-4" /></button></div>
                </div>
              ))}
              {!remindersLoading && reminders.length === 0 && <button onClick={() => setShowReminder(true)} className="w-full rounded-2xl border-2 border-dashed border-teal-200 bg-teal-50/50 p-6 text-teal-700 font-bold text-sm">أضف أول تنبيه لنفاد دوائك</button>}
            </div>
          </section>

          <section className="rounded-2xl bg-white border border-slate-200 p-4 text-xs text-slate-500 leading-6">
            <p className="font-bold text-slate-800 flex items-center gap-1.5"><Check className="w-4 h-4 text-teal-500" />طريقة نقاط الولاء</p>
            تحصل على نقطة لكل 1,000 د.ع من الطلبات المستلمة. يمكنك استخدام النقاط لتخفيض قيمة الطلب بنسبة تصل إلى 20%.
          </section>
        </main>
      </div>

      <AnimatePresence>{showReminder && <ReminderModal initialName={reminderState.reminderMedicationName ?? ''} initialMedicationId={reminderState.reminderMedicationId ?? null} onClose={() => { setShowReminder(false); if (location.state) navigate('/benefits', { replace: true, state: null }); }} />}</AnimatePresence>
    </>
  );
}
