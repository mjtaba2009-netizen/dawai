import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRight,
  Ban,
  Building2,
  Check,
  Clock3,
  Home,
  LogOut,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Store,
  Trash2,
  X,
  Crown,
  UserCheck,
  FileText,
  KeyRound,
  Megaphone,
  Bot,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useDeleteOwnerVendor, useOwnerSubscriptions, useOwnerVendors, useSetOwnerSubscriptionStatus, useSetVendorApproval, useSuspendOwnerVendor } from '@/services/hooks';
import { useToast } from '@/hooks/use-toast';
import type { OwnerVendorRecord, UserSubscription } from '@/services/types';
import { getErrorMessage } from '@/lib/error';
import { OwnerOperations } from '@/components/OwnerOperations';
import { generateLicenseExpiryAlerts, getVendorDocumentSignedUrl } from '@/services/api';
import { reauthenticateWithPassword } from '@/services/security';

const statusLabel: Record<string, string> = {
  pending: 'بانتظار المراجعة',
  approved: 'مقبول',
  rejected: 'مرفوض',
  suspended: 'موقوف',
};

const statusClass: Record<string, string> = {
  pending: 'bg-amber-50 text-amber-700 border-amber-200',
  approved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  rejected: 'bg-red-50 text-red-700 border-red-200',
  suspended: 'bg-orange-50 text-orange-700 border-orange-200',
};

function VendorCard({
  vendor,
  onApprove,
  onReject,
  onDelete,
  onSuspend,
  onOpenDocument,
  busy,
}: {
  vendor: OwnerVendorRecord;
  onApprove: () => void;
  onReject: () => void;
  onDelete: () => void;
  onSuspend: () => void;
  onOpenDocument: (path: string) => void;
  busy: boolean;
}) {
  const cosmetic = vendor.type === 'cosmetic';
  const status = vendor.verificationStatus === 'suspended' ? 'suspended' : (vendor.status ?? 'pending');
  const expiryDays = vendor.licenseExpiresAt
    ? Math.ceil((new Date(`${vendor.licenseExpiresAt}T23:59:59`).getTime() - Date.now()) / 86_400_000)
    : null;
  const expiryTone = expiryDays == null ? 'text-slate-500' : expiryDays < 0 ? 'text-red-600 font-bold' : expiryDays <= 30 ? 'text-amber-700 font-bold' : 'text-slate-500';

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-slate-200/80 bg-white p-4 shadow-sm"
    >
      <div className="flex items-start gap-3">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center overflow-hidden ${cosmetic ? 'bg-pink-50 text-pink-500' : 'bg-teal-50 text-teal-600'}`}>
          {vendor.imageUrl ? (
            <img src={vendor.imageUrl} alt={vendor.name} className="w-full h-full object-cover" />
          ) : cosmetic ? (
            <Sparkles className="w-7 h-7" />
          ) : (
            <Store className="w-7 h-7" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h3 className="font-extrabold text-slate-900 truncate">{vendor.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{cosmetic ? 'متجر كوزمتك' : 'صيدلية'} · {vendor.governorate}</p>
            </div>
            <span className={`shrink-0 text-[11px] font-bold px-2.5 py-1 rounded-full border ${statusClass[status] ?? statusClass.pending}`}>
              {statusLabel[status] ?? status}
            </span>
          </div>

          <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-slate-600">
            <p><span className="text-slate-400">صاحب الحساب:</span> {vendor.ownerProfile?.name || 'غير مذكور'}</p>
            <p dir="ltr" className="text-right sm:text-left"><span className="text-slate-400" dir="rtl">الهاتف:</span> {vendor.ownerProfile?.phone || vendor.phone || '—'}</p>
            <p className="sm:col-span-2"><span className="text-slate-400">العنوان:</span> {vendor.address || 'غير مذكور'}</p>
          </div>
        </div>
      </div>

      <div className="mt-3 rounded-2xl bg-slate-50 border border-slate-100 p-3 text-xs">
        <div className="flex items-center justify-between"><span className="font-bold text-slate-700">توثيق المتجر</span><span className={`px-2 py-0.5 rounded-full font-bold ${vendor.verificationStatus === 'verified' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{vendor.verificationStatus === 'verified' ? 'موثّق' : 'بانتظار الوثائق'}</span></div>
        <p className={`mt-1 ${expiryTone}`}>رقم الإجازة: {vendor.licenseNumber || 'غير مذكور'} · الانتهاء: {vendor.licenseExpiresAt || 'غير مذكور'}{expiryDays != null && expiryDays >= 0 && expiryDays <= 30 ? ` · متبقي ${expiryDays} يوم` : ''}{expiryDays != null && expiryDays < 0 ? ' · منتهية' : ''}</p>
        {expiryDays != null && expiryDays <= 30 && <div role="alert" className={`mt-2 rounded-xl px-3 py-2 flex items-center gap-2 ${expiryDays < 0 ? 'bg-red-50 text-red-700' : 'bg-amber-50 text-amber-800'}`}><AlertTriangle className="w-4 h-4 shrink-0" /><span className="text-[11px] font-bold">{expiryDays < 0 ? 'لا يمكن الموافقة قبل رفع ترخيص ساري.' : 'تنبيه: الترخيص يقترب من الانتهاء ويحتاج متابعة.'}</span></div>}
        {vendor.documents?.length ? <button type="button" onClick={() => onOpenDocument(vendor.documents![0].filePath)} className="mt-2 h-9 px-3 rounded-xl bg-white border border-slate-200 text-teal-700 font-bold flex items-center gap-1"><FileText className="w-4 h-4" />فتح وثيقة الترخيص (رابط مؤقت)</button> : <p className="mt-2 text-red-500 font-bold">لا توجد وثيقة مرفوعة</p>}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
        <button
          disabled={busy || status === 'approved'}
          onClick={onApprove}
          className="h-11 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-lg shadow-teal-500/15 disabled:opacity-35 disabled:shadow-none"
        >
          <Check className="w-4 h-4" /> موافقة
        </button>
        <button
          disabled={busy || status === 'rejected'}
          onClick={onReject}
          className="h-11 rounded-2xl bg-red-50 text-red-700 border border-red-100 font-bold text-xs flex items-center justify-center gap-1 disabled:opacity-35"
        >
          <X className="w-4 h-4" /> رفض
        </button>
        <button
          disabled={busy || status !== 'approved'}
          onClick={onSuspend}
          className="h-11 rounded-2xl bg-orange-50 text-orange-700 border border-orange-100 font-bold text-xs flex items-center justify-center gap-1 disabled:opacity-35"
        >
          <Ban className="w-4 h-4" /> إيقاف
        </button>
        <button
          disabled={busy}
          onClick={onDelete}
          className="h-11 rounded-2xl bg-slate-900 text-white border border-slate-800 font-bold text-xs flex items-center justify-center gap-1 disabled:opacity-40"
        >
          <Trash2 className="w-4 h-4" /> حذف
        </button>
      </div>
    </motion.article>
  );
}

function DeleteConfirmation({ vendor, busy, onCancel, onConfirm }: {
  vendor: OwnerVendorRecord;
  busy: boolean;
  onCancel: () => void;
  onConfirm: (password: string) => void;
}) {
  const [password, setPassword] = useState('');
  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <button className="absolute inset-0 bg-slate-950/55 backdrop-blur-sm" onClick={busy ? undefined : onCancel} aria-label="إغلاق" />
      <motion.div
        initial={{ y: 50, scale: 0.97 }}
        animate={{ y: 0, scale: 1 }}
        exit={{ y: 50, scale: 0.97 }}
        className="relative w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white p-5 shadow-2xl pb-[calc(env(safe-area-inset-bottom)+20px)]"
      >
        <div className="w-14 h-14 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto">
          <AlertTriangle className="w-7 h-7" />
        </div>
        <h2 className="text-center font-black text-slate-900 text-lg mt-4">حذف {vendor.name}؟</h2>
        <p className="text-center text-sm text-slate-500 leading-6 mt-2">
          سيتم حذف المتجر من المنصة وإيقاف ظهوره للمستخدمين. يبقى حساب صاحبه حساباً عادياً، وتُحفظ الطلبات السابقة للسجل.
        </p>
        <label className="block mt-4 text-xs font-bold text-slate-600"><span className="flex items-center gap-1 mb-1"><KeyRound className="w-4 h-4" />أدخل كلمة مرور المالك للتأكيد</span><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full h-11 rounded-xl border border-slate-200 px-3" autoComplete="current-password" /></label>
        <div className="grid grid-cols-2 gap-2 mt-5">
          <button disabled={busy} onClick={onCancel} className="h-12 rounded-2xl bg-slate-100 text-slate-700 font-bold disabled:opacity-50">إلغاء</button>
          <button disabled={busy || !password} onClick={() => onConfirm(password)} className="h-12 rounded-2xl bg-red-600 text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50">
            {busy ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
            حذف من المنصة
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function OwnerDashboard() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { data: vendors = [], isLoading, isFetching, refetch, error } = useOwnerVendors();
  const approvalAction = useSetVendorApproval();
  const deleteAction = useDeleteOwnerVendor();
  const suspendAction = useSuspendOwnerVendor();
  const { data: subscriptions = [], isLoading: subscriptionsLoading } = useOwnerSubscriptions();
  const subscriptionAction = useSetOwnerSubscriptionStatus();
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [query, setQuery] = useState('');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<OwnerVendorRecord | null>(null);
  const [busySubscriptionId, setBusySubscriptionId] = useState<number | null>(null);

  useEffect(() => {
    generateLicenseExpiryAlerts().catch(() => undefined);
  }, []);

  const counts = useMemo(() => ({
    all: vendors.length,
    pending: vendors.filter((v) => (v.status ?? 'pending') === 'pending').length,
    approved: vendors.filter((v) => v.status === 'approved').length,
    rejected: vendors.filter((v) => v.status === 'rejected').length,
  }), [vendors]);

  const filtered = useMemo(() => vendors.filter((vendor) => {
    const matchesStatus = filter === 'all' || (vendor.status ?? 'pending') === filter;
    const term = query.trim().toLowerCase();
    const matchesSearch = !term || [vendor.name, vendor.governorate, vendor.address, vendor.ownerProfile?.name, vendor.ownerProfile?.phone, vendor.phone]
      .filter(Boolean).some((value) => String(value).toLowerCase().includes(term));
    return matchesStatus && matchesSearch;
  }), [vendors, filter, query]);

  const handleApproval = async (vendor: OwnerVendorRecord, next: 'approved' | 'rejected') => {
    setBusyId(vendor.id);
    try {
      await approvalAction.mutateAsync({ vendorId: vendor.id, action: next });
      toast({ title: next === 'approved' ? 'تمت الموافقة' : 'تم الرفض', description: vendor.name });
    } catch (err) {
      toast({ title: 'تعذّر تنفيذ العملية', description: getErrorMessage(err, 'تعذّر تنفيذ العملية'), variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };


  const handleSuspend = async (vendor: OwnerVendorRecord) => {
    const reason = window.prompt('اكتب سبب إيقاف المتجر مؤقتاً');
    if (!reason?.trim()) return;
    setBusyId(vendor.id);
    try {
      await suspendAction.mutateAsync({ vendorId: vendor.id, reason: reason.trim() });
      toast({ title: 'تم إيقاف المتجر مؤقتاً', description: vendor.name });
    } catch (error) {
      toast({ title: 'تعذّر إيقاف المتجر', description: getErrorMessage(error), variant: 'destructive' });
    } finally { setBusyId(null); }
  };

  const handleSubscription = async (subscription: UserSubscription, action: 'active' | 'rejected') => {
    setBusySubscriptionId(subscription.id);
    try {
      await subscriptionAction.mutateAsync({ subscriptionId: subscription.id, action });
      toast({ title: action === 'active' ? 'تم تفعيل الاشتراك' : 'تم رفض الاشتراك', description: subscription.userName || subscription.userPhone || 'المستخدم' });
    } catch (error) {
      toast({ title: 'تعذّر تحديث الاشتراك', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setBusySubscriptionId(null);
    }
  };

  const openVendorDocument = async (path: string) => {
    try {
      const url = await getVendorDocumentSignedUrl(path);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (error) { toast({ title: 'تعذّر فتح الوثيقة', description: getErrorMessage(error), variant: 'destructive' }); }
  };

  const handleDelete = async (password: string) => {
    if (!deleteTarget) return;
    setBusyId(deleteTarget.id);
    try {
      await reauthenticateWithPassword(password);
      await deleteAction.mutateAsync(deleteTarget.id);
      toast({ title: 'تم حذف المتجر من المنصة', description: deleteTarget.name });
      setDeleteTarget(null);
    } catch (err) {
      toast({
        title: 'تعذّر حذف المتجر',
        description: getErrorMessage(err, 'شغّل ملف صلاحيات الإصدار 2.5 في Supabase.'),
        variant: 'destructive',
      });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="min-h-[100dvh] bg-slate-50" dir="rtl">
      <header className="sticky top-0 z-30 bg-slate-950 text-white border-b border-white/10 shadow-xl">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-[calc(env(safe-area-inset-top)+14px)] pb-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative w-12 h-12 rounded-2xl overflow-hidden bg-white/10 border border-amber-300/20">
                <img src="./logo.png" alt="دوائي" className="w-full h-full object-contain" />
                <span className="owner-logo-shine" />
              </div>
              <div className="min-w-0">
                <p className="text-amber-300 text-xs font-bold">الإدارة المركزية</p>
                <h1 className="font-extrabold text-lg truncate">لوحة مالك منصة دوائي</h1>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button onClick={() => navigate('/owner/marketing')} className="h-10 px-3 rounded-xl bg-amber-400/15 text-amber-100 border border-amber-300/25 flex items-center justify-center gap-1.5 text-xs font-bold" aria-label="فتح نظام التسويق">
                <Megaphone className="w-4 h-4" />
                <span className="hidden sm:inline">Marketing OS</span>
              </button>
              <button onClick={() => navigate('/home')} className="h-10 px-3 rounded-xl bg-teal-500/20 text-teal-100 border border-teal-300/20 flex items-center justify-center gap-1.5 text-xs font-bold" aria-label="العودة للمنصة">
                <Home className="w-4 h-4" />
                <span className="hidden sm:inline">استخدام المنصة</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => refetch()} className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center" aria-label="تحديث">
                <RefreshCw className={`w-4 h-4 ${isFetching ? 'animate-spin' : ''}`} />
              </button>
              <button onClick={logout} className="w-10 h-10 rounded-xl bg-red-500/15 text-red-200 flex items-center justify-center" aria-label="تسجيل الخروج">
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 sm:p-6 pb-[calc(env(safe-area-inset-bottom)+30px)]">
        <div className="rounded-3xl bg-gradient-to-l from-teal-600 to-emerald-600 text-white p-4 mb-5 shadow-lg shadow-teal-700/15 flex items-center gap-3">
          <ShieldCheck className="w-7 h-7 shrink-0" />
          <div>
            <p className="font-extrabold text-sm">حساب المالك يعمل بطريقتين</p>
            <p className="text-xs text-teal-50/90 mt-0.5">استخدم المنصة بشكل عادي، وارجع لهذه اللوحة وقت ما تحتاج إدارة المتاجر.</p>
          </div>
        </div>

        <button onClick={() => navigate('/owner/marketing')} className="w-full rounded-3xl mb-5 overflow-hidden text-right bg-slate-950 text-white border border-teal-300/10 shadow-xl shadow-slate-900/10 group">
          <div className="relative p-5 sm:p-6 bg-[radial-gradient(circle_at_15%_0%,rgba(20,184,166,0.28),transparent_42%)]">
            <div className="absolute left-5 top-5 w-16 h-16 rounded-3xl bg-teal-400/10 border border-teal-300/15 flex items-center justify-center group-hover:scale-105 transition-transform"><Bot className="w-8 h-8 text-teal-300" /></div>
            <div className="max-w-[75%]">
              <p className="text-amber-300 text-xs font-bold">Dawai AI Marketing OS</p>
              <h2 className="font-black text-xl mt-1">مركز التسويق الذكي للمنصة</h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-6">أنشئ الحملات، راجع المحتوى، وافق عليه وجدوله لـInstagram وTikTok والإيميل من لوحة واحدة.</p>
              <span className="inline-flex items-center gap-2 mt-4 text-xs font-bold text-teal-200">فتح نظام التسويق <ArrowRight className="w-4 h-4" /></span>
            </div>
          </div>
        </button>

        <section className="rounded-3xl bg-white border border-slate-200 p-4 mb-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2"><div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center"><Crown className="w-5 h-5" /></div><div><h2 className="font-extrabold text-slate-900">طلبات دوائي بلس</h2><p className="text-xs text-slate-400">تفعيل الاشتراك الشهري أو رفضه</p></div></div>
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-amber-50 text-amber-700">{subscriptions.filter((item) => item.status === 'pending').length} معلّق</span>
          </div>
          {subscriptionsLoading ? <div className="h-24 rounded-2xl bg-slate-100 animate-pulse" /> : subscriptions.filter((item) => item.status === 'pending').length ? (
            <div className="grid md:grid-cols-2 gap-3">
              {subscriptions.filter((item) => item.status === 'pending').map((subscription) => (
                <div key={subscription.id} className="rounded-2xl border border-slate-200 p-3">
                  <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center"><UserCheck className="w-5 h-5" /></div><div className="flex-1 min-w-0"><p className="font-bold text-slate-800 truncate">{subscription.userName || 'مستخدم دوائي'}</p><p className="text-xs text-slate-400" dir="ltr">{subscription.userPhone || '—'}</p><p className="text-xs text-teal-700 mt-1">{subscription.planName} · {subscription.monthlyPrice.toLocaleString('ar-IQ')} د.ع</p></div></div>
                  <div className="grid grid-cols-2 gap-2 mt-3"><button disabled={busySubscriptionId === subscription.id} onClick={() => void handleSubscription(subscription, 'active')} className="h-10 rounded-xl bg-teal-500 text-white font-bold text-xs disabled:opacity-50">تفعيل 30 يوماً</button><button disabled={busySubscriptionId === subscription.id} onClick={() => void handleSubscription(subscription, 'rejected')} className="h-10 rounded-xl bg-red-50 text-red-700 font-bold text-xs disabled:opacity-50">رفض</button></div>
                </div>
              ))}
            </div>
          ) : <p className="text-sm text-slate-400 text-center py-5">لا توجد طلبات اشتراك معلّقة</p>}
        </section>

        <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
          {[
            { key: 'pending', label: 'بانتظار الموافقة', value: counts.pending, icon: Clock3, tone: 'text-amber-700 bg-amber-50' },
            { key: 'approved', label: 'متاجر مقبولة', value: counts.approved, icon: ShieldCheck, tone: 'text-emerald-700 bg-emerald-50' },
            { key: 'rejected', label: 'طلبات مرفوضة', value: counts.rejected, icon: X, tone: 'text-red-700 bg-red-50' },
            { key: 'all', label: 'إجمالي المتاجر', value: counts.all, icon: Building2, tone: 'text-slate-700 bg-slate-100' },
          ].map(({ key, label, value, icon: Icon, tone }) => (
            <button key={key} onClick={() => setFilter(key as typeof filter)} className={`rounded-3xl p-4 text-right border shadow-sm transition ${filter === key ? 'border-teal-400 ring-2 ring-teal-100 bg-white' : 'border-slate-200 bg-white'}`}>
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${tone}`}><Icon className="w-4 h-4" /></div>
              <p className="text-2xl font-black text-slate-900 tabular-nums">{value}</p>
              <p className="text-[11px] text-slate-500 mt-1">{label}</p>
            </button>
          ))}
        </section>

        <div className="relative mb-4">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث باسم الصيدلية، الكوزمتك أو رقم الهاتف" className="w-full h-12 pr-11 pl-4 rounded-2xl bg-white border border-slate-200 outline-none focus:border-teal-400 focus:ring-2 focus:ring-teal-100 text-sm" />
        </div>

        {error && (
          <div className="rounded-2xl bg-red-50 text-red-800 border border-red-200 p-4 mb-4 text-sm leading-relaxed">
            تعذّر تحميل طلبات المتاجر. تأكد من تشغيل صلاحيات حساب المالك في Supabase: {getErrorMessage(error)}
          </div>
        )}

        {isLoading ? (
          <div className="grid md:grid-cols-2 gap-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-48 rounded-3xl bg-white border border-slate-200 animate-pulse" />)}</div>
        ) : filtered.length ? (
          <div className="grid md:grid-cols-2 gap-3">
            {filtered.map((vendor) => (
              <VendorCard
                key={vendor.id}
                vendor={vendor}
                busy={busyId === vendor.id}
                onApprove={() => handleApproval(vendor, 'approved')}
                onReject={() => handleApproval(vendor, 'rejected')}
                onDelete={() => setDeleteTarget(vendor)}
                onSuspend={() => void handleSuspend(vendor)}
                onOpenDocument={openVendorDocument}
              />
            ))}
          </div>
        ) : (
          <div className="rounded-3xl bg-white border border-slate-200 p-10 text-center">
            <ShieldCheck className="w-12 h-12 text-teal-300 mx-auto mb-3" />
            <h2 className="font-extrabold text-slate-800">لا توجد نتائج</h2>
            <p className="text-sm text-slate-400 mt-1">لا توجد متاجر مطابقة لهذا القسم حالياً.</p>
          </div>
        )}
        <OwnerOperations />
      </main>

      <AnimatePresence>
        {deleteTarget && (
          <DeleteConfirmation
            vendor={deleteTarget}
            busy={busyId === deleteTarget.id}
            onCancel={() => setDeleteTarget(null)}
            onConfirm={handleDelete}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
