import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Copy, KeyRound, Loader2, LockKeyhole, ShieldCheck, Smartphone, Trash2, WifiOff } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { getErrorMessage } from '@/lib/error';
import { getSecurityState, removeMfaFactor, startTotpEnrollment, verifyTotpEnrollment } from '@/services/security';
import type { SecurityState } from '@/services/types';

export function SecurityCenter() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [state, setState] = useState<SecurityState | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState('');
  const [enrollment, setEnrollment] = useState<{ factorId: string; qrCode: string; secret: string; uri: string } | null>(null);
  const [totpCode, setTotpCode] = useState('');

  const refresh = async () => {
    setLoading(true);
    try {
      setState(await getSecurityState());
    } catch (error) {
      toast({ title: 'تعذّر تحميل إعدادات الأمان', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void refresh(); }, []);

  const verifiedFactors = useMemo(
    () => state?.factors.filter((factor) => factor.status === 'verified' && factor.factorType === 'totp') ?? [],
    [state],
  );

  const beginTotp = async () => {
    setBusy('totp-start');
    try {
      setEnrollment(await startTotpEnrollment());
    } catch (error) {
      toast({ title: 'تعذّر بدء المصادقة', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setBusy('');
    }
  };

  const confirmTotp = async () => {
    if (!enrollment) return;
    setBusy('totp-code');
    try {
      await verifyTotpEnrollment(enrollment.factorId, totpCode);
      setEnrollment(null);
      setTotpCode('');
      await refresh();
      toast({ title: 'تم تفعيل المصادقة بخطوتين', description: 'أصبح حسابك محميًا برمز تطبيق المصادقة.' });
    } catch (error) {
      toast({ title: 'رمز التحقق غير صحيح', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setBusy('');
    }
  };

  const removeFactor = async (id: string) => {
    setBusy(id);
    try {
      await removeMfaFactor(id);
      await refresh();
      toast({ title: 'تم إلغاء تطبيق المصادقة' });
    } catch (error) {
      toast({ title: 'تعذّر الإلغاء', description: getErrorMessage(error, 'أعد تسجيل الدخول وتحقق بالرمز ثم حاول مجددًا'), variant: 'destructive' });
    } finally {
      setBusy('');
    }
  };

  return (
    <div className="flex-1 bg-slate-50" dir="rtl">
      <header className="bg-gradient-to-br from-slate-950 via-teal-950 to-teal-800 text-white px-5 pt-[calc(env(safe-area-inset-top)+18px)] pb-7">
        <button onClick={() => navigate('/account')} className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center" aria-label="رجوع"><ArrowRight className="w-5 h-5" /></button>
        <div className="mt-5 flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-amber-300/15 border border-amber-300/25 flex items-center justify-center"><ShieldCheck className="w-7 h-7 text-amber-300" /></div>
          <div><h1 className="text-xl font-black">مركز الأمان</h1><p className="text-teal-100 text-sm mt-1">كلمة مرور + تطبيق مصادقة بدون رسائل SMS</p></div>
        </div>
      </header>

      <main className="p-4 pb-28 space-y-4">
        {loading ? <div className="h-44 rounded-3xl bg-white animate-pulse" /> : (
          <section className="rounded-3xl bg-white border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${state?.currentLevel === 'aal2' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}><LockKeyhole className="w-5 h-5" /></div>
              <div><h2 className="font-extrabold text-slate-900">حالة الحماية الحالية</h2><p className="text-xs text-slate-500 mt-1">{state?.currentLevel === 'aal2' ? 'AAL2 — كلمة مرور ورمز تحقق' : 'AAL1 — كلمة مرور فقط'}</p></div>
            </div>
            {user?.role === 'owner' && verifiedFactors.length === 0 && <div className="mt-4 rounded-2xl bg-red-50 border border-red-100 p-3 text-xs text-red-700 leading-5">حساب مالك المنصة يجب أن يفعّل تطبيق المصادقة قبل الموافقة أو الرفض أو حذف المتاجر.</div>}
          </section>
        )}

        <section className="rounded-3xl bg-white border border-slate-200 p-4 shadow-sm">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-2xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0"><WifiOff className="w-5 h-5" /></div>
            <div>
              <h2 className="font-extrabold text-slate-900">لا تحتاج مزوّد SMS</h2>
              <p className="text-xs text-slate-500 mt-1 leading-5">تسجيل الدخول يبقى برقم الهاتف وكلمة المرور. الحماية الإضافية تتم من تطبيق المصادقة، والرمز يعمل حتى بدون إنترنت أو رصيد هاتف.</p>
            </div>
          </div>
        </section>

        <section className="rounded-3xl bg-white border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-11 h-11 rounded-2xl bg-violet-50 text-violet-600 flex items-center justify-center"><KeyRound className="w-5 h-5" /></div>
            <div><h2 className="font-extrabold text-slate-900">المصادقة بخطوتين</h2><p className="text-xs text-slate-500 mt-1">Google Authenticator أو Microsoft Authenticator أو 2FAS</p></div>
          </div>

          {verifiedFactors.length > 0 && (
            <div className="space-y-2 mb-4">
              {verifiedFactors.map((factor) => (
                <div key={factor.id} className="rounded-2xl bg-emerald-50 border border-emerald-100 p-3 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <div className="flex-1"><p className="text-sm font-bold text-emerald-900">تطبيق المصادقة مفعّل</p><p className="text-[11px] text-emerald-700">سيُطلب رمز متغيّر بعد كلمة المرور</p></div>
                  <button onClick={() => void removeFactor(factor.id)} disabled={busy === factor.id} className="w-9 h-9 rounded-xl bg-white text-red-500 flex items-center justify-center" aria-label="إلغاء العامل"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
            </div>
          )}

          {!enrollment ? (
            <button onClick={beginTotp} disabled={busy === 'totp-start'} className="w-full h-12 rounded-2xl bg-violet-600 text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50">
              {busy === 'totp-start' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Smartphone className="w-4 h-4" />}
              {verifiedFactors.length ? 'إضافة تطبيق مصادقة آخر' : 'تفعيل المصادقة بخطوتين'}
            </button>
          ) : (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
              <div className="rounded-3xl bg-white border border-slate-200 p-3 flex justify-center"><img src={enrollment.qrCode} alt="رمز QR لإضافة منصة دوائي إلى تطبيق المصادقة" className="w-52 h-52" /></div>
              <ol className="rounded-2xl bg-slate-50 p-3 text-xs text-slate-600 leading-6 list-decimal list-inside">
                <li>افتح تطبيق المصادقة واضغط إضافة حساب.</li>
                <li>امسح رمز QR الظاهر أعلاه.</li>
                <li>أدخل الرمز المكوّن من 6 أرقام.</li>
              </ol>
              <button onClick={async () => { await navigator.clipboard.writeText(enrollment.secret); toast({ title: 'تم نسخ المفتاح' }); }} className="w-full h-11 rounded-xl bg-slate-100 text-slate-700 font-bold flex items-center justify-center gap-2"><Copy className="w-4 h-4" />نسخ المفتاح بدل QR</button>
              <input value={totpCode} onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))} inputMode="numeric" autoComplete="one-time-code" dir="ltr" className="w-full h-14 rounded-2xl border border-slate-200 text-center tracking-[0.5em] text-xl font-black outline-none focus:border-violet-400" placeholder="000000" />
              <button onClick={confirmTotp} disabled={busy === 'totp-code' || totpCode.length !== 6} className="w-full h-12 rounded-2xl bg-teal-600 text-white font-bold disabled:opacity-50">{busy === 'totp-code' ? 'جاري التحقق...' : 'تأكيد وتفعيل الحماية'}</button>
              <button onClick={() => { setEnrollment(null); setTotpCode(''); }} className="w-full h-10 text-sm font-bold text-slate-500">إلغاء</button>
            </motion.div>
          )}
        </section>
      </main>
    </div>
  );
}
