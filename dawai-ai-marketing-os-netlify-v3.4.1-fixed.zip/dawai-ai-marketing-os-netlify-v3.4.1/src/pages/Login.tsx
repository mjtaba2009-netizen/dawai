import { useContext, useEffect, useState, type ElementType, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  BadgeCheck,
  ChevronDown,
  Eye,
  EyeOff,
  KeyRound,
  LockKeyhole,
  MapPin,
  Phone,
  Plus,
  ShieldCheck,
  Sparkles,
  Store,
  Truck,
  UserRound,
} from 'lucide-react';
import { AuthContext, type UserRole } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { PharmacyRegistrationForm } from '@/components/PharmacyRegistrationForm';
import { CosmeticRegistrationForm, type CosmeticRegisterData } from '@/components/CosmeticRegistrationForm';
import { getErrorMessage } from '@/lib/error';

const GOVERNORATES = [
  'بغداد', 'البصرة', 'نينوى', 'أربيل', 'السليمانية', 'دهوك', 'كركوك',
  'النجف', 'كربلاء', 'بابل', 'ذي قار', 'ميسان', 'الأنبار', 'ديالى',
  'صلاح الدين', 'المثنى', 'القادسية', 'واسط',
];

const IRAQ_GOV_BOUNDS = [
  { name: 'بغداد', latMin: 33.05, latMax: 33.65, lngMin: 44.10, lngMax: 44.65 },
  { name: 'البصرة', latMin: 29.50, latMax: 31.50, lngMin: 46.50, lngMax: 48.50 },
  { name: 'نينوى', latMin: 35.50, latMax: 37.40, lngMin: 41.50, lngMax: 43.80 },
  { name: 'أربيل', latMin: 35.70, latMax: 37.20, lngMin: 43.50, lngMax: 45.30 },
  { name: 'السليمانية', latMin: 34.50, latMax: 36.50, lngMin: 44.50, lngMax: 46.30 },
  { name: 'دهوك', latMin: 36.50, latMax: 37.40, lngMin: 42.50, lngMax: 44.00 },
  { name: 'كركوك', latMin: 34.50, latMax: 35.80, lngMin: 43.50, lngMax: 45.10 },
  { name: 'النجف', latMin: 29.50, latMax: 32.20, lngMin: 43.00, lngMax: 44.30 },
  { name: 'كربلاء', latMin: 32.20, latMax: 33.10, lngMin: 43.00, lngMax: 44.50 },
  { name: 'بابل', latMin: 32.00, latMax: 33.20, lngMin: 44.00, lngMax: 45.20 },
  { name: 'ذي قار', latMin: 30.50, latMax: 32.00, lngMin: 45.50, lngMax: 47.00 },
  { name: 'ميسان', latMin: 31.00, latMax: 32.50, lngMin: 46.50, lngMax: 48.00 },
  { name: 'الأنبار', latMin: 32.00, latMax: 34.50, lngMin: 38.00, lngMax: 44.00 },
  { name: 'ديالى', latMin: 33.50, latMax: 34.50, lngMin: 44.50, lngMax: 46.50 },
  { name: 'صلاح الدين', latMin: 33.50, latMax: 35.50, lngMin: 43.00, lngMax: 45.00 },
  { name: 'المثنى', latMin: 28.50, latMax: 31.50, lngMin: 43.50, lngMax: 47.00 },
  { name: 'القادسية', latMin: 31.50, latMax: 32.50, lngMin: 44.00, lngMax: 46.00 },
  { name: 'واسط', latMin: 32.00, latMax: 33.50, lngMin: 45.50, lngMax: 47.00 },
];

function detectGovernorate(lat: number, lng: number): string {
  return IRAQ_GOV_BOUNDS.find(
    (g) => lat >= g.latMin && lat <= g.latMax && lng >= g.lngMin && lng <= g.lngMax,
  )?.name ?? '';
}

const ROLE_LABELS: Record<'patient' | 'pharmacy' | 'cosmetic', string> = {
  patient: 'مستخدم',
  pharmacy: 'صيدلية',
  cosmetic: 'كوزماتك',
};

function FloatingGlow({ className, delay = 0 }: { className: string; delay?: number }) {
  return (
    <motion.span
      className={`absolute rounded-full blur-3xl pointer-events-none ${className}`}
      animate={{ x: [0, 18, 0], y: [0, -24, 0], scale: [1, 1.08, 1] }}
      transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut', delay }}
    />
  );
}

function IconField({
  label,
  icon: Icon,
  children,
}: {
  label: string;
  icon: ElementType;
  children: ReactNode;
}) {
  return (
    <label className="dawai-auth-field" dir="rtl">
      <span className="dawai-auth-field-icon"><Icon /></span>
      <span className="dawai-auth-field-label">{label}</span>
      <span className="dawai-auth-field-control">{children}</span>
    </label>
  );
}

function SelectControl({
  value,
  onChange,
  placeholder,
  children,
  disabled,
  testId,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  children: ReactNode;
  disabled?: boolean;
  testId?: string;
}) {
  return (
    <span className="relative block w-full">
      <select
        className={`dawai-auth-input dawai-auth-select ${!value ? 'text-slate-400' : 'text-slate-700'}`}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        disabled={disabled}
        data-testid={testId}
        aria-label={placeholder}
      >
        <option value="">{placeholder}</option>
        {children}
      </select>
      <ChevronDown className="dawai-auth-chevron" aria-hidden="true" />
    </span>
  );
}

function Benefit({ icon: Icon, title, subtitle }: { icon: ElementType; title: string; subtitle: string }) {
  return (
    <div className="dawai-auth-benefit" dir="rtl">
      <span className="dawai-auth-benefit-icon"><Icon /></span>
      <span>
        <strong>{title}</strong>
        <small>{subtitle}</small>
      </span>
    </div>
  );
}

export function Login() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { apiLogin, apiRegister, mfaRequired, completeMfa, cancelMfa } = useContext(AuthContext)!;

  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [role, setRole] = useState<UserRole>('patient');
  const [isLoading, setIsLoading] = useState(false);
  const [govLoading, setGovLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [mfaCode, setMfaCode] = useState('');

  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientGov, setPatientGov] = useState('');
  const [patientAddress, setPatientAddress] = useState('');

  const isPharmacyRegister = mode === 'register' && role === 'pharmacy';
  const isCosmeticRegister = mode === 'register' && role === 'cosmetic';
  const isVendorRegister = isPharmacyRegister || isCosmeticRegister;

  useEffect(() => {
    if (mode !== 'register' || role !== 'patient' || !navigator.geolocation) return;
    setGovLoading(true);
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        const detected = detectGovernorate(coords.latitude, coords.longitude);
        if (detected) setPatientGov(detected);
        setGovLoading(false);
      },
      () => setGovLoading(false),
      { timeout: 8000, maximumAge: 60000 },
    );
  }, [mode, role]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);
    try {
      if (mode === 'login') {
        const result = await apiLogin(phone, password);
        if (result.mfaRequired) return;
        navigate(result.user.role === 'owner' || result.user.role === 'patient' ? '/home' : '/dashboard', { replace: true });
        return;
      }

      const authUser = await apiRegister(patientName, phone, password, 'patient', {
        governorate: patientGov,
        address: patientAddress,
      });
      navigate(authUser.role === 'owner' || authUser.role === 'patient' ? '/home' : '/dashboard', { replace: true });
    } catch (error) {
      toast({
        title: mode === 'login' ? 'خطأ في تسجيل الدخول' : 'خطأ في التسجيل',
        description: getErrorMessage(error),
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };


  const handleMfaSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);
    try {
      const authUser = await completeMfa(mfaCode);
      navigate(authUser.role === 'owner' || authUser.role === 'patient' ? '/home' : '/dashboard', { replace: true });
    } catch (error) {
      toast({ title: 'رمز التحقق غير صحيح', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePharmacyRegister = async ({
    fullName,
    pharmacyName,
    governorate,
    address,
    workingHours,
    licenseNumber,
    licenseExpiresAt,
    licenseFile,
  }: {
    fullName: string;
    pharmacyName: string;
    governorate: string;
    address: string;
    workingHours: string;
    licenseNumber: string;
    licenseExpiresAt: string;
    licenseFile: File;
  }) => {
    setIsLoading(true);
    try {
      const authUser = await apiRegister(fullName || pharmacyName || 'صيدلية', phone, password, 'pharmacy', {
        vendorName: pharmacyName,
        governorate,
        address,
        workingHours,
        licenseNumber,
        licenseExpiresAt,
        licenseFile,
      });
      navigate(authUser.role === 'pharmacy' ? '/dashboard' : '/home', { replace: true });
    } catch (error) {
      toast({ title: 'خطأ في التسجيل', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCosmeticRegister = async (data: CosmeticRegisterData) => {
    setIsLoading(true);
    try {
      const authUser = await apiRegister(data.fullName || data.vendorName || 'متجر', phone, password, 'cosmetic', {
        vendorName: data.vendorName,
        governorate: data.governorate,
        address: data.address,
        workingHours: data.workingHours,
        instagram: data.instagram,
        tiktok: data.tiktok,
        licenseNumber: data.licenseNumber,
        licenseExpiresAt: data.licenseExpiresAt,
        licenseFile: data.licenseFile,
      });
      navigate(authUser.role === 'patient' ? '/home' : '/dashboard', { replace: true });
    } catch (error) {
      toast({ title: 'خطأ في التسجيل', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="dawai-auth-page" dir="rtl">
      <FloatingGlow className="w-72 h-72 bg-teal-400/20 -top-20 -right-28" />
      <FloatingGlow className="w-56 h-56 bg-emerald-300/10 top-[28%] -left-24" delay={1.7} />
      <FloatingGlow className="w-80 h-80 bg-cyan-300/10 bottom-0 right-1/4" delay={3.2} />

      <div className="dawai-auth-grid" aria-hidden="true" />
      <div className="dawai-auth-bottle" aria-hidden="true"><span /></div>
      <div className="dawai-auth-tube" aria-hidden="true"><span /></div>

      <motion.section
        initial={{ opacity: 0, y: 22 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.65, ease: 'easeOut' }}
        className={`dawai-auth-shell ${isVendorRegister ? 'dawai-auth-shell-wide' : ''}`}
      >
        <header className="dawai-auth-hero">
          <motion.div
            initial={{ scale: 0.82, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 240, damping: 18, delay: 0.08 }}
            className="dawai-auth-logo-wrap"
          >
            <span className="dawai-auth-logo-halo" />
            <img src={`${import.meta.env.BASE_URL}logo.png`} alt="شعار منصة دوائي" className="dawai-auth-logo" />
            <svg className="dawai-auth-heartbeat" viewBox="0 0 512 512" aria-hidden="true">
              <defs>
                <filter id="goldGlow" x="-60%" y="-60%" width="220%" height="220%">
                  <feGaussianBlur stdDeviation="7" result="blur" />
                  <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                </filter>
              </defs>
              <path d="M143 256 H209 L224 219 L249 301 L269 256 H375" className="dawai-auth-heartbeat-track" />
              <path d="M143 256 H209 L224 219 L249 301 L269 256 H375" className="dawai-auth-heartbeat-light" filter="url(#goldGlow)" />
            </svg>
          </motion.div>

          <h1>منصة دوائي</h1>
          <p>دواؤك ومنتجاتك من أقرب متجر موثوق</p>
        </header>

        <section className="dawai-auth-card">
          <div className="dawai-auth-tabs" role="tablist" aria-label="الدخول أو إنشاء حساب">
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'login'}
              onClick={() => setMode('login')}
              className={mode === 'login' ? 'is-active' : ''}
              data-testid="tab-login"
            >
              تسجيل الدخول
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'register'}
              onClick={() => setMode('register')}
              className={mode === 'register' ? 'is-active' : ''}
              data-testid="tab-register"
            >
              إنشاء حساب
            </button>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={`${mode}-${isVendorRegister ? role : 'standard'}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22 }}
            >
              <div className="dawai-auth-card-heading">
                <span><ShieldCheck /></span>
                <div>
                  <h2>{mode === 'login' ? 'مرحباً بعودتك' : 'أنشئ حسابك للبدء'}</h2>
                  <p>{mode === 'login' ? 'ادخل إلى حسابك بأمان وسرعة' : 'سريع، آمن، ومصمم لخدمتك'}</p>
                </div>
              </div>

              {mfaRequired ? (
                <form onSubmit={handleMfaSubmit} className="dawai-auth-form" aria-label="التحقق بخطوتين">
                  <div className="rounded-2xl border border-teal-100 bg-teal-50/80 p-4 text-sm text-teal-900">
                    <strong className="block mb-1">التحقق بخطوتين مطلوب</strong>
                    <span>أدخل الرمز المكوّن من 6 أرقام من تطبيق Google Authenticator أو Microsoft Authenticator لإكمال الدخول.</span>
                  </div>
                  <IconField label="رمز التحقق" icon={KeyRound}>
                    <input className="dawai-auth-input" inputMode="numeric" autoComplete="one-time-code" dir="ltr" value={mfaCode} onChange={(event) => setMfaCode(event.target.value.replace(/\D/g, '').slice(0, 8))} placeholder="000000" required minLength={6} />
                  </IconField>
                  <button type="submit" className="dawai-auth-submit" disabled={isLoading || mfaCode.length < 6}><strong>{isLoading ? 'جاري التحقق...' : 'تأكيد الدخول الآمن'}</strong></button>
                  <button type="button" onClick={() => { cancelMfa(); setMfaCode(''); }} className="w-full text-sm font-bold text-slate-500 py-2">إلغاء والعودة</button>
                </form>
              ) : mode === 'register' && (
                <IconField label="نوع الحساب" icon={UserRound}>
                  <SelectControl
                    value={role === 'owner' ? '' : role}
                    onChange={(value) => setRole(value as UserRole)}
                    placeholder="اختر نوع الحساب"
                    testId="select-account-role"
                  >
                    <option value="patient">مستخدم — أبحث عن دواء</option>
                    <option value="pharmacy">صيدلية — أدير صيدلية</option>
                    <option value="cosmetic">كوزماتك — متجر تجميل</option>
                  </SelectControl>
                </IconField>
              )}

              {!mfaRequired && (isPharmacyRegister ? (
                <div className="dawai-auth-vendor-form">
                  <div className="dawai-auth-role-chip"><Store /> تسجيل صيدلية جديدة</div>
                  <PharmacyRegistrationForm
                    embedded
                    phone={phone}
                    password={password}
                    onPhoneChange={setPhone}
                    onPasswordChange={setPassword}
                    isLoading={isLoading}
                    onRegister={handlePharmacyRegister}
                  />
                </div>
              ) : isCosmeticRegister ? (
                <div className="dawai-auth-vendor-form">
                  <div className="dawai-auth-role-chip"><Sparkles /> تسجيل متجر كوزماتك</div>
                  <CosmeticRegistrationForm
                    phone={phone}
                    password={password}
                    onPhoneChange={setPhone}
                    onPasswordChange={setPassword}
                    isLoading={isLoading}
                    onRegister={handleCosmeticRegister}
                  />
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="dawai-auth-form">
                  {mode === 'login' && (
                    <div className="rounded-2xl border border-teal-100 bg-teal-50/80 p-3 text-xs leading-5 text-teal-900">
                      الدخول يتم برقم الهاتف وكلمة المرور. إذا فعّلت المصادقة بخطوتين، سيُطلب بعد ذلك رمز تطبيق المصادقة.
                    </div>
                  )}
                  {mode === 'register' && (
                    <>
                      <IconField label="المحافظة" icon={MapPin}>
                        <SelectControl
                          value={patientGov}
                          onChange={setPatientGov}
                          placeholder={govLoading ? 'جاري تحديد المحافظة...' : 'اختر المحافظة'}
                          disabled={govLoading}
                          testId="select-governorate"
                        >
                          {GOVERNORATES.map((governorate) => (
                            <option key={governorate} value={governorate}>{governorate}</option>
                          ))}
                        </SelectControl>
                      </IconField>

                      <IconField label="الاسم الكامل" icon={UserRound}>
                        <input
                          className="dawai-auth-input"
                          value={patientName}
                          onChange={(event) => setPatientName(event.target.value)}
                          placeholder="أدخل اسمك الكامل"
                          required
                          autoComplete="name"
                          data-testid="input-name"
                        />
                      </IconField>

                      <IconField label="العنوان التفصيلي" icon={MapPin}>
                        <input
                          className="dawai-auth-input"
                          value={patientAddress}
                          onChange={(event) => setPatientAddress(event.target.value)}
                          placeholder="الشارع، الحي، المنطقة..."
                          autoComplete="street-address"
                        />
                      </IconField>
                    </>
                  )}

                  <IconField label="رقم الجوال" icon={Phone}>
                    <span className="dawai-auth-phone-row" dir="ltr">
                      <span className="dawai-auth-country">+964</span>
                      <input
                        className="dawai-auth-input"
                        type="tel"
                        inputMode="tel"
                        dir="ltr"
                        value={phone}
                        onChange={(event) => setPhone(event.target.value)}
                        placeholder="07XXXXXXXXX"
                        required
                        autoComplete="tel"
                        data-testid="input-phone"
                      />
                    </span>
                  </IconField>

                  <IconField label="كلمة المرور" icon={LockKeyhole}>
                    <span className="relative block w-full">
                      <input
                        className="dawai-auth-input dawai-auth-password-input"
                        type={showPassword ? 'text' : 'password'}
                        dir="ltr"
                        value={password}
                        onChange={(event) => setPassword(event.target.value)}
                        placeholder="أدخل كلمة المرور"
                        required
                        autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                        data-testid="input-password"
                      />
                      <button
                        type="button"
                        className="dawai-auth-eye"
                        onClick={() => setShowPassword((current) => !current)}
                        aria-label={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                      >
                        {showPassword ? <EyeOff /> : <Eye />}
                      </button>
                    </span>
                  </IconField>

                  {mode === 'register' && (
                    <p className="dawai-auth-password-note">يجب أن تكون 8 أحرف على الأقل وتحتوي على أرقام وحروف</p>
                  )}

                  <motion.button
                    whileTap={{ scale: 0.985 }}
                    whileHover={{ scale: 1.006 }}
                    type="submit"
                    className="dawai-auth-submit"
                    disabled={isLoading}
                    data-testid="button-submit"
                  >
                    <span className="dawai-auth-submit-light" aria-hidden="true" />
                    <span className="dawai-auth-submit-plus"><Plus /></span>
                    <strong>{isLoading ? 'جاري التحميل...' : mode === 'login' ? 'تسجيل الدخول' : 'إنشاء الحساب'}</strong>
                    {isLoading && <span className="dawai-auth-spinner" />}
                  </motion.button>
                </form>
              ))}

              {!mfaRequired && !isVendorRegister && (
                <div className="dawai-auth-switch">
                  <span />
                  <p>
                    {mode === 'login' ? 'ليس لديك حساب؟' : 'لديك حساب بالفعل؟'}{' '}
                    <button type="button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
                      {mode === 'login' ? 'إنشاء حساب' : 'تسجيل الدخول'}
                    </button>
                  </p>
                  <span />
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </section>

        {!isVendorRegister && (
          <footer className="dawai-auth-benefits">
            <Benefit icon={ShieldCheck} title="تسوق آمن" subtitle="تجربة موثوقة" />
            <Benefit icon={BadgeCheck} title="منتجات أصلية" subtitle="من علامات موثوقة" />
            <Benefit icon={Truck} title="توصيل سريع" subtitle="إلى باب منزلك" />
          </footer>
        )}
      </motion.section>
    </main>
  );
}
