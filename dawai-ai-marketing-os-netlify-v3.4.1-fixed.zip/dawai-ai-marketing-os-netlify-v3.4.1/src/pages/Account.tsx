import { useState, useContext, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  User, Bell, Lock, HelpCircle, Star, LogOut,
  ChevronLeft, Shield, Phone, MapPin, X,
  Eye, EyeOff, ChevronDown, MessageCircle,
  Smartphone, Wifi, WifiOff, Check, LayoutDashboard, Building2, Gift, Crown,
} from 'lucide-react';
import { AuthContext } from '@/contexts/AuthContext';
import { PushNotificationsCard } from '@/components/PushNotificationsCard';
import { usePushNotifications } from '@/contexts/PushNotificationsContext';
import { changeMyPassword, changeMyPhone, logoutOtherSessions, submitPlatformFeedback, updateMyProfile } from '@/services/api';
import { getErrorMessage } from '@/lib/error';
import type { AppUser } from '@/services/types';

// ══════════════════════════════════════════════════════════════
// Shared helpers
// ══════════════════════════════════════════════════════════════
function Sheet({ onClose, children }: { onClose: () => void; children: React.ReactNode }) {
  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-end justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
    >
      <motion.div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div
        className="relative w-full max-w-[430px] rounded-t-3xl bg-white/92 backdrop-blur-2xl border-t border-white/60 shadow-2xl max-h-[85vh] overflow-y-auto pb-8"
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300, mass: 0.8 }}
      >
        {children}
      </motion.div>
    </motion.div>
  );
}

function SheetHeader({ title, icon, onClose }: { title: string; icon: React.ReactNode; onClose: () => void }) {
  return (
    <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-slate-100">
      <button onClick={onClose} className="w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center">
        <X className="w-4 h-4 text-slate-500" />
      </button>
      <div className="flex items-center gap-2">
        <span className="font-bold text-slate-800">{title}</span>
        {icon}
      </div>
    </div>
  );
}

function InputField({
  label, value, onChange, placeholder = '', type = 'text', disabled = false,
}: {
  label: string; value: string; onChange?: (v: string) => void;
  placeholder?: string; type?: string; disabled?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-semibold text-slate-500">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        className={`w-full h-11 px-4 rounded-xl bg-slate-50 border border-slate-200 text-sm outline-none text-right
          focus:border-teal-400 focus:ring-1 focus:ring-teal-100 transition-all
          ${disabled ? 'opacity-60 cursor-not-allowed bg-slate-100' : ''}`}
        dir="rtl"
      />
    </div>
  );
}

function Toggle({ value, onChange, label, sub }: {
  value: boolean; onChange: (v: boolean) => void; label: string; sub?: string;
}) {
  return (
    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
      <button
        type="button"
        role="switch"
        aria-checked={value}
        aria-label={label}
        onClick={() => onChange(!value)}
        className={`relative w-12 h-6 rounded-full flex-shrink-0 transition-colors duration-200 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 focus-visible:ring-offset-2 ${value ? 'bg-teal-500' : 'bg-slate-200'}`}
      >
        <span
          className="absolute left-1 top-1 w-4 h-4 rounded-full bg-white shadow-sm transition-transform duration-200 ease-out will-change-transform"
          style={{ transform: `translateX(${value ? 24 : 0}px)` }}
        />
      </button>
      <div className="text-right">
        <p className="text-sm font-semibold text-slate-800">{label}</p>
        {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

function SaveButton({ onClick, saved, disabled = false, label = 'حفظ التغييرات' }: {
  onClick: () => void; saved: boolean; disabled?: boolean; label?: string;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      disabled={disabled || saved}
      className={`w-full h-12 rounded-2xl font-bold text-sm transition-all
        ${saved
          ? 'bg-teal-500 text-white shadow-[0_4px_14px_rgba(15,162,148,0.45)]'
          : 'bg-gradient-to-r from-teal-500 to-teal-600 text-white shadow-md disabled:opacity-40'}`}
    >
      {saved ? '✓ تم الحفظ' : label}
    </motion.button>
  );
}

// ══════════════════════════════════════════════════════════════
// 1. Profile Info Modal
// ══════════════════════════════════════════════════════════════
function ProfileInfoModal({ user, onUpdated, onClose }: { user: AppUser | null; onUpdated: (user: AppUser) => void; onClose: () => void }) {
  const [name, setName] = useState(user?.name ?? '');
  const [vendorName, setVendorName] = useState(user?.role === 'pharmacy' || user?.role === 'cosmetic' ? user.name : '');
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      const updated = await updateMyProfile({ name, vendorName: vendorName || null });
      onUpdated(updated);
      setSaved(true);
      window.setTimeout(onClose, 900);
    } catch (cause) {
      setError(getErrorMessage(cause));
    } finally { setSaving(false); }
  };

  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="معلومات الملف الشخصي" icon={<User className="w-5 h-5 text-teal-500" />} onClose={onClose} />
      <div className="px-5 py-5 space-y-4">
        <InputField label="الاسم الكامل" value={name} onChange={setName} placeholder="أدخل اسمك الكامل" />
        {(user?.role === 'pharmacy' || user?.role === 'cosmetic') && (
          <InputField label={user.role === 'pharmacy' ? 'اسم الصيدلية' : 'اسم متجر الكوزمتك'} value={vendorName} onChange={setVendorName} placeholder="اسم المتجر" />
        )}
        {error && <p className="rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600 text-right">{error}</p>}
        <SaveButton onClick={() => void handleSave()} saved={saved} disabled={!name.trim() || saving} label={saving ? 'جاري الحفظ...' : 'حفظ التغييرات'} />
      </div>
      <div className="pb-safe" />
    </Sheet>
  );
}

// ══════════════════════════════════════════════════════════════
// 2. Phone Modal — OTP simulation
// ══════════════════════════════════════════════════════════════
function PhoneModal({ currentPhone, onUpdated, onClose }: { currentPhone?: string; onUpdated: (user: AppUser) => void; onClose: () => void }) {
  const [newPhone, setNewPhone] = useState(currentPhone ?? '');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      const updated = await changeMyPhone(newPhone, password);
      onUpdated(updated);
      setSaved(true);
      window.setTimeout(onClose, 900);
    } catch (cause) {
      setError(getErrorMessage(cause));
    } finally { setSaving(false); }
  };

  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="رقم الجوال" icon={<Phone className="w-5 h-5 text-blue-500" />} onClose={onClose} />
      <div className="px-5 py-5 space-y-4">
        <InputField label="رقم الجوال الحالي" value={currentPhone ?? ''} disabled />
        <InputField label="رقم الجوال الجديد" value={newPhone} onChange={setNewPhone} placeholder="07XXXXXXXXX" type="tel" />
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500">كلمة المرور الحالية للتأكيد</label>
          <div className="relative">
            <input type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className="w-full h-11 px-4 pr-10 rounded-xl bg-slate-50 border border-slate-200 text-sm outline-none focus:border-teal-400 text-right" dir="ltr" />
            <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-label={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}>{showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
          </div>
        </div>
        <p className="text-[11px] leading-5 text-slate-400 text-right">تغيير الرقم يتم بكلمة المرور الحالية لأن خدمة SMS غير مفعلة في المشروع.</p>
        {error && <p className="rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600 text-right">{error}</p>}
        <SaveButton onClick={() => void handleSave()} saved={saved} disabled={!newPhone.trim() || !password || saving} label={saving ? 'جاري الحفظ...' : 'تغيير رقم الجوال'} />
      </div>
      <div className="pb-safe" />
    </Sheet>
  );
}

// ══════════════════════════════════════════════════════════════
// 3. Address Modal — Governorate + detail
// ══════════════════════════════════════════════════════════════
const IRAQ_GOV_BOUNDS = [
  { name: 'بغداد',      latMin: 33.05, latMax: 33.65, lngMin: 44.10, lngMax: 44.65 },
  { name: 'البصرة',     latMin: 29.50, latMax: 31.50, lngMin: 46.50, lngMax: 48.50 },
  { name: 'نينوى',      latMin: 35.50, latMax: 37.40, lngMin: 41.50, lngMax: 43.80 },
  { name: 'أربيل',      latMin: 35.70, latMax: 37.20, lngMin: 43.50, lngMax: 45.30 },
  { name: 'السليمانية', latMin: 34.50, latMax: 36.50, lngMin: 44.50, lngMax: 46.30 },
  { name: 'دهوك',       latMin: 36.50, latMax: 37.40, lngMin: 42.50, lngMax: 44.00 },
  { name: 'كركوك',      latMin: 34.50, latMax: 35.80, lngMin: 43.50, lngMax: 45.10 },
  { name: 'النجف',      latMin: 29.50, latMax: 32.20, lngMin: 43.00, lngMax: 44.30 },
  { name: 'كربلاء',     latMin: 32.20, latMax: 33.10, lngMin: 43.00, lngMax: 44.50 },
  { name: 'بابل',       latMin: 32.00, latMax: 33.20, lngMin: 44.00, lngMax: 45.20 },
  { name: 'ذي قار',     latMin: 30.50, latMax: 32.00, lngMin: 45.50, lngMax: 47.00 },
  { name: 'ميسان',      latMin: 31.00, latMax: 32.50, lngMin: 46.50, lngMax: 48.00 },
  { name: 'الأنبار',    latMin: 32.00, latMax: 34.50, lngMin: 38.00, lngMax: 44.00 },
  { name: 'ديالى',      latMin: 33.50, latMax: 34.50, lngMin: 44.50, lngMax: 46.50 },
  { name: 'صلاح الدين', latMin: 33.50, latMax: 35.50, lngMin: 43.00, lngMax: 45.00 },
  { name: 'المثنى',     latMin: 28.50, latMax: 31.50, lngMin: 43.50, lngMax: 47.00 },
  { name: 'القادسية',   latMin: 31.50, latMax: 32.50, lngMin: 44.00, lngMax: 46.00 },
  { name: 'واسط',       latMin: 32.00, latMax: 33.50, lngMin: 45.50, lngMax: 47.00 },
];
function detectGov(lat: number, lng: number): string {
  for (const g of IRAQ_GOV_BOUNDS)
    if (lat >= g.latMin && lat <= g.latMax && lng >= g.lngMin && lng <= g.lngMax) return g.name;
  return '';
}

function AddressModal({ user, onUpdated, onClose }: { user: AppUser | null; onUpdated: (user: AppUser) => void; onClose: () => void }) {
  const [gov, setGov] = useState(user?.governorate ?? '');
  const [govLoad, setGovLoad] = useState(false);
  const [address, setAddress] = useState(user?.address ?? '');
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const detectLocation = () => {
    if (!navigator.geolocation) { setError('خدمة الموقع غير مدعومة في هذا الجهاز'); return; }
    setGovLoad(true); setError(null);
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => { const detected = detectGov(coords.latitude, coords.longitude); if (detected) setGov(detected); else setError('تعذر تحديد المحافظة تلقائيًا'); setGovLoad(false); },
      () => { setError('لم يتم السماح بالوصول إلى الموقع'); setGovLoad(false); },
      { timeout: 8000, maximumAge: 300000 },
    );
  };

  const save = async () => {
    setSaving(true); setError(null);
    try {
      const updated = await updateMyProfile({ governorate: gov, address });
      onUpdated(updated);
      setSaved(true);
      window.setTimeout(onClose, 900);
    } catch (cause) { setError(getErrorMessage(cause)); }
    finally { setSaving(false); }
  };

  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="العنوان والمحافظة" icon={<MapPin className="w-5 h-5 text-teal-500" />} onClose={onClose} />
      <div className="px-5 py-5 space-y-4">
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between gap-2">
            <button type="button" onClick={detectLocation} disabled={govLoad} className="text-[11px] font-bold text-teal-600 disabled:opacity-50">{govLoad ? 'جاري التحديد...' : 'تحديد تلقائي'}</button>
            <label className="text-xs font-semibold text-slate-500">المحافظة</label>
          </div>
          <select value={gov} onChange={(event) => setGov(event.target.value)} className="w-full h-11 px-4 rounded-xl bg-slate-50 border border-slate-200 text-sm outline-none focus:border-teal-400 text-right appearance-none">
            <option value="">اختر المحافظة</option>
            {IRAQ_GOV_BOUNDS.map((item) => <option key={item.name} value={item.name}>{item.name}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500">العنوان التفصيلي والحي السكني</label>
          <textarea value={address} onChange={(event) => setAddress(event.target.value)} placeholder="مثال: حي الكرادة، شارع فلسطين، بناية رقم 15" rows={3} className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 text-sm outline-none resize-none focus:border-teal-400 text-right" dir="rtl" />
        </div>
        {error && <p className="rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600 text-right">{error}</p>}
        <SaveButton onClick={() => void save()} saved={saved} disabled={!gov || saving} label={saving ? 'جاري الحفظ...' : 'حفظ العنوان'} />
      </div>
      <div className="pb-safe" />
    </Sheet>
  );
}

// ══════════════════════════════════════════════════════════════
// 4. Password Modal — standalone
// ══════════════════════════════════════════════════════════════
function PasswordModal({ onClose }: { onClose: () => void }) {
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showCur, setShowCur] = useState(false);
  const [showNext, setShowNext] = useState(false);
  const [showConf, setShowConf] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mismatch = Boolean(next && confirm && next !== confirm);
  const valid = Boolean(cur && next.length >= 8 && /[A-Za-z]/.test(next) && /\d/.test(next) && next === confirm);

  const pwField = (label: string, value: string, set: (value: string) => void, show: boolean, toggle: () => void) => (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-semibold text-slate-500">{label}</label>
      <div className="relative">
        <input type={show ? 'text' : 'password'} value={value} onChange={(event) => set(event.target.value)} className="w-full h-11 px-4 pr-10 rounded-xl bg-slate-50 border border-slate-200 text-sm outline-none focus:border-teal-400 text-right" placeholder="••••••••" dir="ltr" />
        <button type="button" onClick={toggle} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-label={show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}>{show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
      </div>
    </div>
  );

  const save = async () => {
    setSaving(true); setError(null);
    try {
      await changeMyPassword(cur, next);
      setSaved(true);
      window.setTimeout(onClose, 900);
    } catch (cause) { setError(getErrorMessage(cause)); }
    finally { setSaving(false); }
  };

  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="كلمة المرور" icon={<Lock className="w-5 h-5 text-purple-500" />} onClose={onClose} />
      <div className="px-5 py-5 space-y-3">
        {pwField('كلمة المرور الحالية', cur, setCur, showCur, () => setShowCur((value) => !value))}
        {pwField('كلمة المرور الجديدة', next, setNext, showNext, () => setShowNext((value) => !value))}
        {pwField('تأكيد كلمة المرور الجديدة', confirm, setConfirm, showConf, () => setShowConf((value) => !value))}
        <p className="text-[11px] text-slate-400 text-right">8 أحرف على الأقل وتحتوي على حرف ورقم.</p>
        {mismatch && <p className="text-xs text-red-500 text-right">⚠ كلمتا المرور غير متطابقتين</p>}
        {error && <p className="rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600 text-right">{error}</p>}
        <SaveButton onClick={() => void save()} saved={saved} disabled={!valid || saving} label={saving ? 'جاري التغيير...' : 'تغيير كلمة المرور'} />
      </div>
      <div className="pb-safe" />
    </Sheet>
  );
}

// ══════════════════════════════════════════════════════════════
// 5. Notifications Modal
// ══════════════════════════════════════════════════════════════
function NotificationsModal({ onClose }: { onClose: () => void }) {
  const push = usePushNotifications();
  const [orderUpdates, setOrderUpdates] = useState(push.preferences.orderUpdates);
  const [vendorUpdates, setVendorUpdates] = useState(push.preferences.vendorUpdates);
  const [reminders, setReminders] = useState(push.preferences.reminders);
  const [promos, setPromos] = useState(push.preferences.promotions);
  const [securityAlerts, setSecurityAlerts] = useState(push.preferences.securityAlerts);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setOrderUpdates(push.preferences.orderUpdates);
    setVendorUpdates(push.preferences.vendorUpdates);
    setReminders(push.preferences.reminders);
    setPromos(push.preferences.promotions);
    setSecurityAlerts(push.preferences.securityAlerts);
  }, [push.preferences]);

  const save = async () => {
    await push.updatePreferences({ orderUpdates, vendorUpdates, reminders, promotions: promos, securityAlerts });
    setSaved(true);
    window.setTimeout(onClose, 900);
  };

  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="إعدادات الإشعارات" icon={<Bell className="w-5 h-5 text-amber-500" />} onClose={onClose} />
      <div className="px-5 py-4 space-y-3">
        <PushNotificationsCard compact />
        <Toggle value={orderUpdates} onChange={setOrderUpdates} label="تحديثات الطلبات" sub="الطلب الجديد والقبول والتجهيز والتوصيل" />
        <Toggle value={vendorUpdates} onChange={setVendorUpdates} label="إشعارات المتجر والإدارة" sub="طلبات الانضمام والموافقة والرفض والشكاوى" />
        <Toggle value={reminders} onChange={setReminders} label="تذكيرات الدواء" sub="تنبيه إعادة الطلب وقرب نفاد الدواء" />
        <Toggle value={promos} onChange={setPromos} label="العروض والكوبونات" sub="العروض العامة والخصومات الجديدة" />
        <Toggle value={securityAlerts} onChange={setSecurityAlerts} label="تنبيهات الأمان" sub="تسجيل الدخول والتغييرات الحساسة" />
        <SaveButton onClick={() => void save()} saved={saved} disabled={push.busy} />
      </div>
      <div className="pb-safe" />
    </Sheet>
  );
}

// ══════════════════════════════════════════════════════════════
// 6. Privacy & Security Modal — re-architected (no password)
// ══════════════════════════════════════════════════════════════
function currentDeviceLabel() {
  const ua = navigator.userAgent;
  if (/iPhone/i.test(ua)) return 'iPhone · دوائي PWA';
  if (/iPad/i.test(ua)) return 'iPad · دوائي PWA';
  if (/Android/i.test(ua)) return 'Android · Chrome';
  if (/Windows/i.test(ua)) return 'Windows · المتصفح';
  if (/Macintosh|Mac OS X/i.test(ua)) return 'Mac · المتصفح';
  return 'هذا الجهاز';
}

function PrivacyModal({ onClose }: { onClose: () => void }) {
  const navigate = useNavigate();
  const [loggingOutOthers, setLoggingOutOthers] = useState(false);
  const [loggedOutOthers, setLoggedOutOthers] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogoutOthers = async () => {
    setLoggingOutOthers(true); setError(null);
    try {
      await logoutOtherSessions();
      setLoggedOutOthers(true);
    } catch (cause) {
      setError(getErrorMessage(cause));
    } finally { setLoggingOutOthers(false); }
  };

  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="الخصوصية والأمان" icon={<Shield className="w-5 h-5 text-teal-500" />} onClose={onClose} />
      <div className="px-5 py-4 space-y-5 max-h-[78vh] overflow-y-auto">
        <div>
          <p className="text-xs font-bold text-slate-400 mb-2 uppercase tracking-wider">الأمان المتقدم</p>
          <button
            type="button"
            onClick={() => { onClose(); navigate('/security'); }}
            className="w-full flex items-center justify-between gap-3 p-4 bg-teal-50 border border-teal-100 rounded-2xl text-right"
          >
            <ChevronLeft className="w-4 h-4 text-teal-600" />
            <div className="flex-1">
              <p className="text-sm font-bold text-slate-800">المصادقة بخطوتين (2FA)</p>
              <p className="text-xs text-slate-500 mt-1">إدارة Google Authenticator والرموز الاحتياطية من مركز الأمان</p>
            </div>
            <Shield className="w-5 h-5 text-teal-600" />
          </button>
        </div>

        <div>
          <p className="text-xs font-bold text-slate-400 mb-2 uppercase tracking-wider">الجلسات</p>
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-teal-50 border border-teal-100">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-teal-100 flex-shrink-0"><Smartphone className="w-4 h-4 text-teal-600" /></div>
            <div className="flex-1 min-w-0 text-right">
              <p className="text-sm font-semibold text-slate-800 truncate">{currentDeviceLabel()}</p>
              <p className="text-xs text-slate-400">نشط الآن</p>
            </div>
            <span className="flex items-center gap-1 text-[10px] text-teal-600 font-bold bg-teal-100 px-2 py-0.5 rounded-full"><Check className="w-3 h-3" />هذا الجهاز</span>
          </div>
          <button
            type="button"
            onClick={() => void handleLogoutOthers()}
            disabled={loggingOutOthers || loggedOutOthers}
            className="mt-3 w-full h-11 rounded-2xl bg-slate-100 text-slate-700 font-bold text-sm disabled:opacity-60"
          >
            {loggingOutOthers ? 'جاري إنهاء الجلسات...' : loggedOutOthers ? '✓ تم إنهاء الجلسات الأخرى' : 'تسجيل الخروج من الأجهزة الأخرى'}
          </button>
          {error && <p className="mt-2 rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600 text-right">{error}</p>}
        </div>

        <div className="rounded-2xl border border-amber-100 bg-amber-50 p-4 text-right">
          <p className="text-sm font-bold text-amber-900">حذف الحساب</p>
          <p className="mt-1 text-xs leading-5 text-amber-700">حذف الحساب يحتاج مراجعة لحماية الطلبات والسجلات الطبية. أرسل طلبًا إلى الدعم وسيتم التحقق من هويتك قبل الحذف.</p>
          <a href="mailto:support@dawai.iq?subject=طلب حذف حساب دوائي" className="mt-3 inline-flex h-9 items-center rounded-xl bg-white px-4 text-xs font-bold text-amber-800 border border-amber-200">إرسال طلب حذف</a>
        </div>
      </div>
      <div className="pb-safe" />
    </Sheet>
  );
}

// ══════════════════════════════════════════════════════════════
// 7. Rating Modal
// ══════════════════════════════════════════════════════════════
function RatingModal({ onClose }: { onClose: () => void }) {
  const [rating,    setRating]    = useState(0);
  const [hovered,   setHovered]   = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [comment, setComment] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center p-6"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
    >
      <motion.div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div
        className="relative w-full max-w-sm bg-white/95 backdrop-blur-2xl rounded-3xl p-6 shadow-2xl border border-white/60"
        initial={{ scale: 0.85, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.85, opacity: 0, y: 20 }}
        transition={{ type: 'spring', damping: 25, stiffness: 320 }}
      >
        <button onClick={onClose} className="absolute top-4 left-4 w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center">
          <X className="w-4 h-4 text-slate-500" />
        </button>
        <AnimatePresence mode="wait">
          {!submitted ? (
            <motion.div key="rating" className="text-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="text-4xl mb-2">⭐</div>
              <h3 className="font-bold text-slate-800 text-lg mb-1">قيّم تجربتك</h3>
              <p className="text-slate-400 text-sm mb-5">رأيك يساعدنا على التحسين</p>
              <div className="flex justify-center gap-2 mb-6">
                {[1, 2, 3, 4, 5].map((star) => (
                  <motion.button
                    key={star}
                    type="button"
                    whileTap={{ scale: 1.35 }}
                    whileHover={{ scale: 1.2 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                    onMouseEnter={() => setHovered(star)}
                    onMouseLeave={() => setHovered(0)}
                    onClick={() => setRating(star)}
                    className="text-3xl leading-none"
                  >
                    <motion.span animate={{ color: star <= (hovered || rating) ? '#f59e0b' : '#d1d5db' }} transition={{ duration: 0.15 }} style={{ display: 'inline-block' }}>★</motion.span>
                  </motion.button>
                ))}
              </div>
              <textarea value={comment} onChange={(event) => setComment(event.target.value)} rows={3} placeholder="اكتب ملاحظتك (اختياري)" className="mb-3 w-full resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-right outline-none focus:border-amber-400" />
              {error && <p className="mb-3 rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600 text-right">{error}</p>}
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={() => void (async () => {
                  setSending(true); setError(null);
                  try { await submitPlatformFeedback(rating, comment); setSubmitted(true); }
                  catch (cause) { setError(getErrorMessage(cause)); }
                  finally { setSending(false); }
                })()}
                disabled={!rating || sending}
                className="w-full h-12 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 text-white font-bold text-sm shadow-md disabled:opacity-40">
                {sending ? 'جاري الإرسال...' : 'إرسال التقييم'}
              </motion.button>
            </motion.div>
          ) : (
            <motion.div key="thanks" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center py-4">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 400, damping: 18, delay: 0.1 }} className="text-5xl mb-3">🎉</motion.div>
              <h3 className="font-bold text-slate-800 text-lg mb-1">شكراً جزيلاً!</h3>
              <p className="text-slate-400 text-sm mb-4">تقييمك يعني لنا الكثير ويساعدنا على تحسين خدماتنا</p>
              <button onClick={onClose} className="px-8 h-10 rounded-2xl bg-teal-50 text-teal-700 font-semibold text-sm">إغلاق</button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}

// ══════════════════════════════════════════════════════════════
// 8. Help & Support Modal
// ══════════════════════════════════════════════════════════════
const FAQ_ITEMS = [
  { q: 'كيف أبحث عن دواء معين؟',            a: 'اكتب اسم الدواء في شريط البحث الرئيسي، وسيظهر لك قائمة بالصيدليات المتوفر لديها هذا الدواء مع الأسعار.' },
  { q: 'كيف أتتبع طلبي؟',                    a: 'اذهب إلى قسم "طلباتي" من الشريط السفلي، وستجد تحديثات حية لحالة طلبك.' },
  { q: 'هل يمكنني إلغاء الطلب بعد الإرسال؟', a: 'يمكنك إلغاء الطلب خلال 5 دقائق من الإرسال. بعد ذلك، تواصل مع الصيدلية مباشرةً.' },
  { q: 'ما هي طرق الدفع المتاحة؟',           a: 'ندعم الدفع عند الاستلام (كاش)، وسنضيف الدفع الإلكتروني قريباً.' },
  { q: 'لماذا يتطلب بعض الأدوية وصفة طبية؟', a: 'وفقاً للقانون العراقي، بعض الأدوية لا يمكن صرفها إلا بوصفة طبية سارية المفعول، حفاظاً على سلامتك.' },
];

function HelpModal({ onClose }: { onClose: () => void }) {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="المساعدة والدعم" icon={<HelpCircle className="w-5 h-5 text-indigo-500" />} onClose={onClose} />
      <div className="px-5 py-4 space-y-5 max-h-[75vh] overflow-y-auto">
        <div>
          <p className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">الأسئلة الشائعة</p>
          <div className="space-y-2">
            {FAQ_ITEMS.map((item, i) => (
              <div key={i} className="bg-slate-50 rounded-2xl overflow-hidden">
                <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center justify-between px-4 py-3.5 text-right">
                  <motion.div animate={{ rotate: open === i ? 180 : 0 }} transition={{ duration: 0.22 }}><ChevronDown className="w-4 h-4 text-slate-400" /></motion.div>
                  <span className="text-sm font-semibold text-slate-700 flex-1 text-right pr-2">{item.q}</span>
                </button>
                <AnimatePresence initial={false}>
                  {open === i && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                      transition={{ type: 'spring', damping: 28, stiffness: 300 }} className="overflow-hidden">
                      <p className="text-xs text-slate-500 leading-relaxed px-4 pb-4 text-right">{item.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
        <div>
          <p className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">تواصل معنا</p>
          <div className="flex justify-center gap-5">
            {[
              { href: 'https://wa.me/9647700000000', label: 'واتساب', bg: 'rgba(37,211,102,0.12)', border: 'rgba(37,211,102,0.3)',
                icon: <svg viewBox="0 0 24 24" className="w-7 h-7 fill-[#25D366]"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg> },
              { href: 'https://www.instagram.com', label: 'إنستغرام', bg: 'rgba(214,41,118,0.08)', border: 'rgba(214,41,118,0.2)',
                icon: <svg viewBox="0 0 24 24" className="w-7 h-7" fill="url(#ig-g2)"><defs><linearGradient id="ig-g2" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" stopColor="#f09433"/><stop offset="50%" stopColor="#dc2743"/><stop offset="100%" stopColor="#bc1888"/></linearGradient></defs><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg> },
              { href: 'https://www.tiktok.com', label: 'تيك توك', bg: 'rgba(0,0,0,0.05)', border: 'rgba(0,0,0,0.1)',
                icon: <svg viewBox="0 0 24 24" className="w-7 h-7 fill-slate-900"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.87a8.18 8.18 0 004.78 1.53V7.01a4.85 4.85 0 01-1.01-.32z"/></svg> },
              { href: 'mailto:support@dawai.iq', label: 'راسلنا', bg: 'rgba(79,70,229,0.08)', border: 'rgba(79,70,229,0.2)',
                icon: <MessageCircle className="w-7 h-7 text-indigo-500" /> },
            ].map((item) => (
              <a key={item.label} href={item.href} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-1.5">
                <motion.div whileTap={{ scale: 0.9 }} className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-md"
                  style={{ background: item.bg, backdropFilter: 'blur(12px)', border: `1px solid ${item.border}` }}>
                  {item.icon}
                </motion.div>
                <span className="text-[10px] font-semibold text-slate-500">{item.label}</span>
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="pb-safe" />
    </Sheet>
  );
}

// ══════════════════════════════════════════════════════════════
// Setting Item Row
// ══════════════════════════════════════════════════════════════
function SettingItem({
  icon: Icon, label, iconBg = 'bg-slate-100', iconColor = 'text-slate-600',
  onClick, index, danger = false,
}: {
  icon: React.ElementType; label: string; iconBg?: string;
  iconColor?: string; onClick?: () => void; index: number; danger?: boolean;
}) {
  return (
    <motion.button
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`w-full flex items-center gap-3 p-4 bg-white rounded-2xl border shadow-sm ${danger ? 'border-red-100' : 'border-slate-100'}`}
    >
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${iconBg}`}>
        <Icon className={`w-5 h-5 ${iconColor}`} />
      </div>
      <span className={`flex-1 font-medium text-sm text-right ${danger ? 'text-red-600' : 'text-slate-700'}`}>{label}</span>
      {!danger && <ChevronLeft className="w-4 h-4 text-slate-300 flex-shrink-0" />}
    </motion.button>
  );
}

// ══════════════════════════════════════════════════════════════
// Main Page
// ══════════════════════════════════════════════════════════════
type ModalKey = 'profile' | 'phone' | 'address' | 'password' | 'notifications' | 'privacy' | 'rating' | 'help' | null;

export function Account() {
  const { user, logout, login } = useContext(AuthContext)!;
  const navigate         = useNavigate();
  const [modal, setModal] = useState<ModalKey>(null);

  const open  = (k: ModalKey) => () => setModal(k);
  const close = () => setModal(null);

  const handleLogout = () => { logout(); navigate('/'); };

  let idx = 0;
  const i = () => idx++;

  return (
    <>
      <div className="flex-1 flex flex-col bg-muted/20">
        {/* Header */}
        <div className="relative bg-gradient-to-br from-teal-500 to-teal-600 px-5 pt-10 pb-8">
          <span className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-l from-transparent via-amber-300/60 to-transparent pointer-events-none" />
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center flex-shrink-0 border-2 border-white/40">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-white text-xl font-bold">{user?.name ?? 'المستخدم'}</h2>
              {user?.phone && <p className="text-teal-100 text-sm mt-0.5" dir="ltr">{user.phone}</p>}
              {user?.role && (
                <span className="inline-flex items-center mt-1.5 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-white">
                  {user.role === 'owner' ? 'مالك المنصة' : user.role === 'pharmacy' ? 'صيدلية' : user.role === 'cosmetic' ? 'متجر كوزماتك' : 'مستخدم'}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex-1 px-4 pt-5 pb-4 space-y-5 overflow-y-auto">

          {user?.role === 'owner' && (
            <div>
              <h3 className="text-amber-600 text-xs font-bold mb-2 px-1 uppercase tracking-wider">إدارة المنصة</h3>
              <motion.button
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate('/owner')}
                className="relative overflow-hidden w-full text-right rounded-3xl border border-amber-200 bg-gradient-to-br from-slate-950 via-slate-900 to-teal-950 p-5 shadow-xl shadow-slate-900/15"
              >
                <span className="absolute -left-8 -top-10 w-28 h-28 rounded-full bg-amber-300/10 blur-2xl" />
                <div className="relative flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-amber-300/15 border border-amber-200/20 flex items-center justify-center shrink-0">
                    <LayoutDashboard className="w-7 h-7 text-amber-300" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-black text-white text-base">لوحة مالك المنصة</p>
                    <p className="text-xs text-slate-300 mt-1 leading-5">موافقة ورفض وحذف الصيدليات والكوزمتك ومتابعة طلبات الانضمام.</p>
                  </div>
                  <Building2 className="w-5 h-5 text-teal-300 shrink-0" />
                </div>
              </motion.button>
            </div>
          )}

          {/* الحساب */}
          <div>
            <h3 className="text-slate-400 text-xs font-semibold mb-2 px-1 uppercase tracking-wider">الحساب</h3>
            <div className="space-y-2">
              <SettingItem icon={User}   label="معلومات الملف الشخصي" iconBg="bg-teal-50" iconColor="text-teal-600" onClick={open('profile')}  index={i()} />
              <SettingItem icon={Phone}  label="رقم الجوال"            iconBg="bg-blue-50"    iconColor="text-blue-600"    onClick={open('phone')}    index={i()} />
              <SettingItem icon={Lock}   label="كلمة المرور"           iconBg="bg-purple-50"  iconColor="text-purple-600"  onClick={open('password')} index={i()} />
              <SettingItem icon={Shield} label="OTP والمصادقة بخطوتين" iconBg="bg-emerald-50" iconColor="text-emerald-600" onClick={() => navigate('/security')} index={i()} />
              <SettingItem icon={MapPin} label="العنوان والمحافظة"     iconBg="bg-teal-50"    iconColor="text-teal-600"    onClick={open('address')}  index={i()} />
            </div>
          </div>

          {/* المزايا */}
          <div>
            <h3 className="text-slate-400 text-xs font-semibold mb-2 px-1 uppercase tracking-wider">مزايا دوائي</h3>
            <div className="space-y-2">
              <SettingItem icon={Gift} label="العروض والنقاط وتنبيهات الدواء" iconBg="bg-pink-50" iconColor="text-pink-600" onClick={() => navigate('/benefits')} index={i()} />
              <SettingItem icon={Crown} label="اشتراك دوائي بلس" iconBg="bg-amber-50" iconColor="text-amber-600" onClick={() => navigate('/benefits')} index={i()} />
            </div>
          </div>

          {/* التفضيلات */}
          <div>
            <h3 className="text-slate-400 text-xs font-semibold mb-2 px-1 uppercase tracking-wider">التفضيلات</h3>
            <div className="space-y-2">
              <SettingItem icon={Bell}   label="إعدادات الإشعارات" iconBg="bg-amber-50" iconColor="text-amber-600" onClick={open('notifications')} index={i()} />
              <SettingItem icon={Shield} label="الخصوصية والأمان"  iconBg="bg-teal-50"  iconColor="text-teal-600"  onClick={open('privacy')}       index={i()} />
            </div>
          </div>

          {/* الدعم */}
          <div>
            <h3 className="text-slate-400 text-xs font-semibold mb-2 px-1 uppercase tracking-wider">الدعم</h3>
            <div className="space-y-2">
              <SettingItem icon={Star}       label="قيّم التطبيق"   iconBg="bg-yellow-50" iconColor="text-yellow-600" onClick={open('rating')} index={i()} />
              <SettingItem icon={HelpCircle} label="المساعدة والدعم" iconBg="bg-indigo-50" iconColor="text-indigo-600" onClick={open('help')}   index={i()} />
            </div>
          </div>

          {/* تابعنا */}
          <div>
            <h3 className="text-slate-400 text-xs font-semibold mb-2 px-1 uppercase tracking-wider">تابعنا</h3>
            <motion.a
              initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}
              whileTap={{ scale: 0.98 }}
              href="https://www.tiktok.com" target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center gap-3 p-4 bg-white rounded-2xl border border-slate-100 shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 bg-slate-900">
                <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white">
                  <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.87a8.18 8.18 0 004.78 1.53V7.01a4.85 4.85 0 01-1.01-.32z" />
                </svg>
              </div>
              <span className="flex-1 font-medium text-sm text-right text-slate-700">تابعنا على TikTok</span>
              <ChevronLeft className="w-4 h-4 text-slate-300 flex-shrink-0" />
            </motion.a>
          </div>

          {/* تسجيل الخروج */}
          <SettingItem icon={LogOut} label="تسجيل الخروج" iconBg="bg-red-50" iconColor="text-red-500" onClick={handleLogout} index={i()} danger />
        </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {modal === 'profile'       && <ProfileInfoModal  key="prof"  user={user} onUpdated={login} onClose={close} />}
        {modal === 'phone'         && <PhoneModal        key="phone" currentPhone={user?.phone} onUpdated={login} onClose={close} />}
        {modal === 'address'       && <AddressModal      key="addr" user={user} onUpdated={login} onClose={close} />}
        {modal === 'password'      && <PasswordModal     key="pass"                                   onClose={close} />}
        {modal === 'notifications' && <NotificationsModal key="notif"                                 onClose={close} />}
        {modal === 'privacy'       && <PrivacyModal      key="priv"                                   onClose={close} />}
        {modal === 'rating'        && <RatingModal       key="rate"                                   onClose={close} />}
        {modal === 'help'          && <HelpModal         key="help"                                   onClose={close} />}
      </AnimatePresence>
    </>
  );
}
