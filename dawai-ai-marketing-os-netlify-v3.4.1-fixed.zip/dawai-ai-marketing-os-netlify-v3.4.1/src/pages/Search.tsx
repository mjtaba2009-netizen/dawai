import { useMemo, useState } from 'react';
import { formatIQD } from '@/lib/utils';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Clock3, MapPin, MessageCircle, ShoppingBag, Star, Trophy, WalletCards } from 'lucide-react';
import { useSearchMedications, useCreateOrder } from '@/services/hooks';
import { useToast } from '@/hooks/use-toast';
import { PrescriptionModal } from '@/components/PrescriptionModal';
import type { PrescriptionSubmission } from '@/services/types';
import { getErrorMessage } from '@/lib/error';

type SortMode = 'best' | 'price' | 'distance' | 'time';

function PharmacyResultSkeleton() {
  return <div className="animate-pulse bg-white rounded-2xl h-44 shadow-sm border border-slate-100" />;
}

function PharmacyResultCard({
  pharmacyId, medicationId, medicationName, requiresPrescription,
  pharmacyName, address, distance, deliveryMinutes, isOpen, rating, whatsapp, price, quantity, index, badge,
}: {
  pharmacyId: number; medicationId: number; medicationName: string;
  requiresPrescription: boolean; pharmacyName: string; address: string;
  distance: number; deliveryMinutes: number; isOpen: boolean; rating: number | null;
  whatsapp: string | null; price: number; quantity: number; index: number; badge?: string;
}) {
  const { toast } = useToast();
  const createOrder = useCreateOrder();
  const [showPrescription, setShowPrescription] = useState(false);

  const doReserve = async (prescription?: PrescriptionSubmission | null) => {
    try {
      await createOrder.mutateAsync({
        pharmacyId,
        medicationId,
        quantity: 1,
        prescriptionId: prescription?.id ?? null,
      });
      setShowPrescription(false);
      toast({ title: 'تم إرسال الطلب', description: `تم إرسال الطلب إلى ${pharmacyName}` });
    } catch (error) {
      toast({ title: 'فشل إرسال الطلب', description: getErrorMessage(error), variant: 'destructive' });
      throw error;
    }
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.06, duration: 0.35 }}
        className="relative overflow-hidden bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
      >
        {badge && <span className="absolute top-0 left-0 px-3 py-1 rounded-br-2xl bg-amber-400 text-slate-900 text-[10px] font-extrabold flex items-center gap-1"><Trophy className="w-3 h-3" />{badge}</span>}
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 flex-shrink-0 bg-gradient-to-br from-teal-100 to-teal-200 rounded-xl flex items-center justify-center text-xl">🏪</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <p className="font-bold text-slate-800 truncate">{pharmacyName}</p>
              <span className={`flex-shrink-0 text-[10px] px-2 py-0.5 rounded-full font-medium ${isOpen ? 'bg-teal-50 text-teal-700' : 'bg-red-50 text-red-500'}`}>{isOpen ? 'مفتوح' : 'مغلق'}</span>
            </div>
            <p className="text-slate-400 text-xs truncate">{address || 'العنوان غير مذكور'}</p>
            <div className="grid grid-cols-3 gap-2 mt-3">
              <div className="rounded-xl bg-teal-50 p-2 text-center"><WalletCards className="w-3.5 h-3.5 text-teal-600 mx-auto" /><p className="text-[10px] text-slate-400 mt-1">السعر</p><p className="text-xs text-teal-700 font-extrabold tabular-nums">{formatIQD(price)}</p></div>
              <div className="rounded-xl bg-blue-50 p-2 text-center"><MapPin className="w-3.5 h-3.5 text-blue-600 mx-auto" /><p className="text-[10px] text-slate-400 mt-1">المسافة</p><p className="text-xs text-blue-700 font-extrabold">{distance < 1 ? `${Math.round(distance * 1000)} م` : `${distance.toFixed(1)} كم`}</p></div>
              <div className="rounded-xl bg-amber-50 p-2 text-center"><Clock3 className="w-3.5 h-3.5 text-amber-600 mx-auto" /><p className="text-[10px] text-slate-400 mt-1">التوصيل</p><p className="text-xs text-amber-700 font-extrabold">{deliveryMinutes} د</p></div>
            </div>
            <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-500">
              <span>المتوفر: {quantity}</span>
              {rating !== null && <span className="flex items-center gap-0.5"><Star className="w-3 h-3 text-amber-400 fill-amber-400" />{rating.toFixed(1)}</span>}
              {requiresPrescription && <span className="px-2 py-0.5 bg-amber-50 text-amber-600 rounded-full font-bold">وصفة</span>}
            </div>
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          {whatsapp && <button onClick={() => window.open(`https://wa.me/${whatsapp.replace(/\D/g, '')}`, '_blank')} className="flex-1 h-10 flex items-center justify-center gap-2 rounded-xl bg-green-500 text-white font-semibold text-sm"><MessageCircle className="w-4 h-4" />واتساب</button>}
          <motion.button whileTap={{ scale: 0.95 }} onClick={() => requiresPrescription ? setShowPrescription(true) : void doReserve(null)} disabled={!isOpen || quantity === 0 || createOrder.isPending} className="flex-1 h-10 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-500 to-teal-600 text-white font-semibold text-sm disabled:opacity-50">
            <ShoppingBag className="w-4 h-4" />{createOrder.isPending ? 'جاري الإرسال...' : 'اطلب الآن'}
          </motion.button>
        </div>
      </motion.div>

      <AnimatePresence>{showPrescription && <PrescriptionModal medicationName={medicationName} onConfirm={doReserve} onClose={() => setShowPrescription(false)} />}</AnimatePresence>
    </>
  );
}

export function Search() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const q = searchParams.get('q') || '';
  const [sortMode, setSortMode] = useState<SortMode>('best');
  const { data, isLoading } = useSearchMedications(q);
  const result = data?.[0];

  const pharmacies = useMemo(() => {
    const items = [...(result?.pharmacies ?? [])];
    return items.sort((a: any, b: any) => {
      if (sortMode === 'price') return a.price - b.price;
      if (sortMode === 'distance') return a.distance - b.distance;
      if (sortMode === 'time') return a.deliveryMinutes - b.deliveryMinutes;
      const score = (x: any) => x.price / 1000 + x.distance * 2 + x.deliveryMinutes / 20 - (x.rating || 0);
      return score(a) - score(b);
    });
  }, [result, sortMode]);

  const bestIds = useMemo(() => {
    if (!result?.pharmacies?.length) return {} as Record<string, number>;
    const all = result.pharmacies as any[];
    return {
      cheapest: [...all].sort((a, b) => a.price - b.price)[0]?.pharmacyId,
      nearest: [...all].sort((a, b) => a.distance - b.distance)[0]?.pharmacyId,
      fastest: [...all].sort((a, b) => a.deliveryMinutes - b.deliveryMinutes)[0]?.pharmacyId,
    };
  }, [result]);

  const badgeFor = (id: number) => {
    if (id === bestIds.cheapest) return 'أفضل سعر';
    if (id === bestIds.fastest) return 'أسرع توصيل';
    if (id === bestIds.nearest) return 'الأقرب';
    return undefined;
  };

  return (
    <div className="flex-1 flex flex-col bg-muted/20" dir="rtl">
      <div className="relative bg-gradient-to-br from-teal-500 to-teal-700 px-4 pt-10 pb-6">
        <div className="flex items-center gap-3"><button onClick={() => navigate(-1)} className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center"><ArrowRight className="w-5 h-5 text-white" /></button><div><p className="text-teal-100 text-xs">مقارنة نتائج البحث</p><h1 className="text-white font-bold text-lg truncate">“{q}”</h1></div></div>
      </div>

      <div className="flex-1 px-4 pt-5 pb-4 space-y-4 overflow-y-auto">
        {isLoading ? <>{Array.from({ length: 4 }).map((_, i) => <PharmacyResultSkeleton key={i} />)}</> : !result ? (
          <div className="py-20 text-center"><div className="text-5xl mb-4">🔍</div><h3 className="text-slate-700 font-bold text-lg">لم نجد نتائج</h3><p className="text-slate-400 text-sm mt-2">جرّب كتابة الاسم التجاري أو العلمي</p></div>
        ) : <>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex items-center gap-3"><div className="w-14 h-14 bg-teal-50 rounded-xl flex items-center justify-center text-2xl">💊</div><div><p className="font-bold text-slate-800">{result.name}</p><p className="text-slate-400 text-xs">{result.genericName}</p><p className="text-[10px] text-teal-600 mt-1">متوفر في {pharmacies.length} متجر</p></div></div>

          <div className="grid grid-cols-4 gap-1 rounded-2xl bg-white border border-slate-200 p-1">
            {([['best', 'الأفضل'], ['price', 'السعر'], ['distance', 'المسافة'], ['time', 'الوقت']] as const).map(([key, label]) => <button key={key} onClick={() => setSortMode(key)} className={`h-9 rounded-xl text-xs font-bold ${sortMode === key ? 'bg-teal-500 text-white shadow-sm' : 'text-slate-500'}`}>{label}</button>)}
          </div>

          {pharmacies.length ? pharmacies.map((hit: any, i: number) => <PharmacyResultCard key={hit.pharmacyId} pharmacyId={hit.pharmacyId} medicationId={result.id} medicationName={result.name} requiresPrescription={result.requiresPrescription ?? false} pharmacyName={hit.pharmacyName} address={hit.address ?? ''} distance={hit.distance} deliveryMinutes={hit.deliveryMinutes} isOpen={hit.isOpen} rating={hit.rating || null} whatsapp={hit.whatsapp ?? null} price={hit.price} quantity={hit.quantity} index={i} badge={badgeFor(hit.pharmacyId)} />) : <div className="rounded-2xl bg-white border p-8 text-center text-slate-400">الدواء غير متوفر حالياً</div>}
        </>}
      </div>
    </div>
  );
}
