import { useContext, useState } from 'react';
import { formatIQD } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Package, CheckCircle2, RefreshCw, BellRing, Loader2, Gift, Star, AlertTriangle, Banknote, WalletCards, CreditCard } from 'lucide-react';
import { usePatientOrders, useMarkOrderReceived, useCreateOrder } from '@/services/hooks';
import { OrderTracker } from '@/components/OrderTracker';
import { AuthContext } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { PrescriptionModal } from '@/components/PrescriptionModal';
import type { PatientOrder, PrescriptionSubmission } from '@/services/types';
import { getErrorMessage } from '@/lib/error';
import { DisputeModal, RatingModal } from '@/components/OrderFeedbackModals';

const ACTIVE_STATUSES = new Set(['pending', 'confirmed', 'ready']);
const STATUS_MAP: Record<string, { label: string; classes: string }> = {
  pending: { label: 'قيد المراجعة', classes: 'bg-amber-50 text-amber-700' },
  confirmed: { label: 'تم التأكيد', classes: 'bg-blue-50 text-blue-700' },
  ready: { label: 'جاهز للاستلام', classes: 'bg-teal-50 text-teal-700' },
  received: { label: 'تم الاستلام', classes: 'bg-teal-50 text-teal-700' },
  completed: { label: 'مكتمل', classes: 'bg-slate-100 text-slate-600' },
  cancelled: { label: 'ملغي', classes: 'bg-red-50 text-red-600' },
  rejected: { label: 'مرفوض', classes: 'bg-red-50 text-red-600' },
  timeout: { label: 'انتهى الوقت', classes: 'bg-orange-50 text-orange-600' },
};

function formatDate(value: string) {
  return new Date(value).toLocaleDateString('ar-IQ', { year: 'numeric', month: 'long', day: 'numeric' });
}

export function Orders() {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();
  const { data: orders = [], isLoading } = usePatientOrders(auth?.user?.id);
  const markReceived = useMarkOrderReceived();
  const createOrder = useCreateOrder();
  const { toast } = useToast();
  const [confirmingId, setConfirmingId] = useState<number | null>(null);
  const [reorderingId, setReorderingId] = useState<number | null>(null);
  const [rxOrder, setRxOrder] = useState<PatientOrder | null>(null);
  const [disputeOrderId, setDisputeOrderId] = useState<number | null>(null);
  const [ratingOrderId, setRatingOrderId] = useState<number | null>(null);

  const handleReceived = async (orderId: number) => {
    setConfirmingId(orderId);
    try {
      await markReceived.mutateAsync(orderId);
      toast({ title: 'تم تأكيد الاستلام', description: 'أُضيفت نقاط الولاء إلى حسابك تلقائياً' });
    } catch (error) {
      toast({ title: 'تعذّر تأكيد الاستلام', description: getErrorMessage(error), variant: 'destructive' });
    } finally { setConfirmingId(null); }
  };

  const reorder = async (order: PatientOrder, prescription?: PrescriptionSubmission | null) => {
    if (!order.medication?.id || !order.pharmacy?.id) {
      toast({ title: 'تعذّر إعادة الطلب', description: 'بيانات المنتج أو المتجر غير مكتملة', variant: 'destructive' });
      return;
    }
    setReorderingId(order.id);
    try {
      await createOrder.mutateAsync({
        pharmacyId: order.pharmacy.id,
        medicationId: order.medication.id,
        quantity: order.quantity,
        prescriptionId: prescription?.id ?? null,
      });
      setRxOrder(null);
      toast({ title: 'تمت إعادة الطلب بنقرة واحدة', description: `أُرسل الطلب إلى ${order.pharmacy.name}` });
    } catch (error) {
      toast({ title: 'تعذّر إعادة الطلب', description: getErrorMessage(error), variant: 'destructive' });
      throw error;
    } finally { setReorderingId(null); }
  };

  const handleReorder = (order: PatientOrder) => {
    if (order.medication?.requiresPrescription) setRxOrder(order);
    else void reorder(order, null);
  };

  const active = orders.filter((order) => ACTIVE_STATUSES.has(order.status));
  const completed = orders.filter((order) => !ACTIVE_STATUSES.has(order.status));

  const renderOrder = (order: PatientOrder, activeCard: boolean) => {
    const status = STATUS_MAP[order.status] ?? { label: order.status, classes: 'bg-slate-100 text-slate-600' };
    return (
      <motion.article key={order.id} layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className={`rounded-2xl p-4 border shadow-sm ${activeCard ? 'bg-white border-slate-100' : 'bg-white/80 border-slate-100'}`}>
        <div className="flex items-start gap-3"><div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center text-xl">💊</div><div className="flex-1 min-w-0"><div className="flex items-start justify-between gap-2"><p className="font-bold text-slate-800 text-sm truncate">{order.medication?.name || 'منتج'}</p><span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${status.classes}`}>{status.label}</span></div><p className="text-slate-400 text-xs mt-1 truncate">{order.pharmacy?.name || 'المتجر'}</p><div className="flex items-center gap-2 mt-1"><span className="text-teal-700 font-extrabold text-sm">{formatIQD(order.totalPrice)}</span><span className="text-slate-300">•</span><span className="text-slate-400 text-xs">{formatDate(order.createdAt)}</span></div>{order.trackingCode && <span className="inline-block mt-2 text-[11px] font-bold px-2 py-0.5 rounded-lg bg-teal-50 text-teal-700 font-mono">{order.trackingCode}</span>}<p className="mt-2 text-[10px] text-slate-400 flex items-center gap-1">{order.paymentMethod === 'wallet' ? <WalletCards className="w-3 h-3" /> : order.paymentMethod === 'card_on_delivery' ? <CreditCard className="w-3 h-3" /> : <Banknote className="w-3 h-3" />}{order.paymentMethod === 'wallet' ? 'محفظة إلكترونية' : order.paymentMethod === 'card_on_delivery' ? 'بطاقة عند الاستلام' : 'نقداً عند الاستلام'}</p></div></div>

        {activeCard && <OrderTracker status={order.status} orderId={order.id} />}

        {(order.discountAmount > 0 || order.loyaltyPointsEarned > 0) && <div className="mt-3 flex flex-wrap gap-2">{order.discountAmount > 0 && <span className="text-[10px] rounded-full bg-pink-50 text-pink-700 px-2 py-1 flex items-center gap-1"><Gift className="w-3 h-3" />وفّرت {formatIQD(order.discountAmount)}</span>}{order.loyaltyPointsEarned > 0 && <span className="text-[10px] rounded-full bg-amber-50 text-amber-700 px-2 py-1">+{order.loyaltyPointsEarned} نقطة</span>}</div>}

        {order.status === 'ready' && <button onClick={() => void handleReceived(order.id)} disabled={confirmingId === order.id} className="mt-3 w-full h-10 rounded-xl bg-teal-500 text-white font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-60">{confirmingId === order.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}تم استلام الطلب</button>}

        {!activeCard && <div className="grid grid-cols-2 gap-2 mt-3"><button onClick={() => handleReorder(order)} disabled={reorderingId === order.id} className="h-10 rounded-xl bg-teal-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 disabled:opacity-60">{reorderingId === order.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}اطلب مرة أخرى</button><button onClick={() => navigate('/benefits', { state: { reminderMedicationName: order.medication?.name ?? '', reminderMedicationId: order.medication?.id ?? null } })} className="h-10 rounded-xl bg-amber-50 text-amber-700 font-bold text-xs flex items-center justify-center gap-1.5"><BellRing className="w-4 h-4" />ذكّرني لاحقاً</button>{['received','completed'].includes(order.status) && <><button onClick={() => setRatingOrderId(order.id)} className="h-10 rounded-xl bg-amber-50 text-amber-700 font-bold text-xs flex items-center justify-center gap-1.5"><Star className="w-4 h-4" />تقييم الطلب</button><button onClick={() => setDisputeOrderId(order.id)} className="h-10 rounded-xl bg-red-50 text-red-700 font-bold text-xs flex items-center justify-center gap-1.5"><AlertTriangle className="w-4 h-4" />مشكلة بالطلب</button></>}</div>}
      </motion.article>
    );
  };

  return (
    <>
      <div className="flex-1 flex flex-col bg-muted/20" dir="rtl">
        <div className="relative bg-gradient-to-br from-teal-500 to-teal-700 px-5 pt-10 pb-6"><h1 className="text-white text-xl font-bold">طلباتي</h1><p className="text-teal-100 text-sm mt-1">{isLoading ? 'جاري التحميل...' : `${orders.length} طلب`}</p></div>
        <div className="flex-1 px-4 pt-5 pb-4 space-y-5 overflow-y-auto">
          {isLoading ? Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-40 rounded-2xl bg-white animate-pulse" />) : !orders.length ? <div className="py-20 text-center"><Package className="w-14 h-14 text-teal-200 mx-auto" /><h3 className="text-slate-700 font-bold mt-4">لا توجد طلبات</h3><p className="text-slate-400 text-sm mt-2">ابدأ بالبحث عن دوائك</p></div> : <>{active.length > 0 && <section className="space-y-3"><p className="text-slate-500 text-xs font-bold px-1">الطلبات الجارية</p>{active.map((order) => renderOrder(order, true))}</section>}{completed.length > 0 && <section className="space-y-3"><p className="text-slate-500 text-xs font-bold px-1">السجل السابق</p>{completed.map((order) => renderOrder(order, false))}</section>}</>}
        </div>
      </div>
      <AnimatePresence>{disputeOrderId && <DisputeModal orderId={disputeOrderId} onClose={() => setDisputeOrderId(null)} />}{ratingOrderId && <RatingModal orderId={ratingOrderId} onClose={() => setRatingOrderId(null)} />}{rxOrder && <PrescriptionModal medicationName={rxOrder.medication?.name || 'الدواء'} submitLabel="رفع الوصفة وإعادة الطلب" onConfirm={(prescription) => reorder(rxOrder, prescription)} onClose={() => setRxOrder(null)} />}</AnimatePresence>
    </>
  );
}
