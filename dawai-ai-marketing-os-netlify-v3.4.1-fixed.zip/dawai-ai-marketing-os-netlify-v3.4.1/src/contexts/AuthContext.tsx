import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { AppUser, MfaFactorSummary, UserRole } from '@/services/types';
import { activateVendor, loadProfile, registerAccount, signIn, signOut } from '@/services/api';
import { supabase } from '@/services/supabase';
import {
  getSecurityState,
  loadAuthenticatedProfile,
  recordSecurityEvent,
  requestPhoneOtp,
  verifyMfaCode,
  verifyPhoneOtp,
} from '@/services/security';

export type { UserRole } from '@/services/types';

interface RegisterOptions {
  vendorName?: string | null;
  governorate?: string;
  address?: string | null;
  workingHours?: string | null;
  whatsapp?: string | null;
  instagram?: string | null;
  tiktok?: string | null;
  licenseNumber?: string | null;
  licenseExpiresAt?: string | null;
  licenseFile?: File | null;
}

interface LoginResult {
  user: AppUser;
  mfaRequired: boolean;
}

interface AuthValue {
  user: AppUser | null;
  loading: boolean;
  justActivated: boolean;
  mfaRequired: boolean;
  mfaFactor: MfaFactorSummary | null;
  login: (user: AppUser | null) => void;
  logout: () => void;
  apiLogin: (phone: string, password: string) => Promise<LoginResult>;
  requestOtpLogin: (phone: string) => Promise<string>;
  verifyOtpLogin: (phone: string, code: string) => Promise<LoginResult>;
  completeMfa: (code: string) => Promise<AppUser>;
  cancelMfa: () => Promise<void>;
  apiRegister: (name: string, phone: string, password: string, role: UserRole, options?: RegisterOptions) => Promise<AppUser>;
  activateAccount: () => Promise<void>;
  clearJustActivated: () => void;
}

export const AuthContext = createContext<AuthValue | null>(null);

export const isVendor = (user?: AppUser | null) => user?.role === 'pharmacy' || user?.role === 'cosmetic';
export const isOwner = (user?: AppUser | null) => user?.role === 'owner';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [justActivated, setJustActivated] = useState(false);
  const [mfaRequired, setMfaRequired] = useState(false);
  const [mfaFactor, setMfaFactor] = useState<MfaFactorSummary | null>(null);
  const [pendingMfaUser, setPendingMfaUser] = useState<AppUser | null>(null);
  const idleTimer = useRef<number | null>(null);

  const clearPendingMfa = () => {
    setMfaRequired(false);
    setMfaFactor(null);
    setPendingMfaUser(null);
  };

  const finalizeAuthenticatedUser = async (profile: AppUser): Promise<LoginResult> => {
    const security = await getSecurityState();
    const verifiedFactors = security.factors.filter((factor) => factor.status === 'verified');
    if (security.currentLevel !== 'aal2' && security.nextLevel === 'aal2' && verifiedFactors.length > 0) {
      setPendingMfaUser(profile);
      setMfaFactor(verifiedFactors[0]);
      setMfaRequired(true);
      setUser(null);
      return { user: profile, mfaRequired: true };
    }
    clearPendingMfa();
    setUser(profile);
    await recordSecurityEvent('login_success', { role: profile.role });
    return { user: profile, mfaRequired: false };
  };

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (data.session?.user) {
          const profile = await loadProfile(data.session.user.id, data.session.access_token);
          if (mounted && profile) await finalizeAuthenticatedUser(profile);
        }
      } catch (error) {
        console.warn('Unable to restore session', error);
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    const { data: listener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mounted) return;
      if (event === 'SIGNED_OUT' || !session) {
        setUser(null);
        clearPendingMfa();
        return;
      }
      if (event === 'TOKEN_REFRESHED') {
        setUser((current) => current ? { ...current, token: session.access_token } : current);
      }
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    let stopped = false;
    const refreshProfile = async () => {
      try {
        const profile = await loadProfile(user.id, user.token ?? '');
        if (!stopped && profile) {
          setUser((current) => {
            if (!current) return profile;
            const changed = current.role !== profile.role || current.status !== profile.status || current.pharmacyId !== profile.pharmacyId || current.name !== profile.name;
            return changed ? { ...profile, token: current.token || profile.token } : current;
          });
        }
      } catch {
        // نحافظ على الجلسة الحالية عند ضعف الاتصال.
      }
    };
    const timer = window.setInterval(refreshProfile, 6000);
    refreshProfile();
    return () => { stopped = true; window.clearInterval(timer); };
  }, [user?.id]);

  // إنهاء الجلسة بعد الخمول: 15 دقيقة للمالك و30 دقيقة لبقية الحسابات.
  useEffect(() => {
    if (!user) return;
    const timeoutMs = (user.role === 'owner' ? 15 : 30) * 60 * 1000;
    const reset = () => {
      localStorage.setItem('dawai_last_activity', String(Date.now()));
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
      idleTimer.current = window.setTimeout(async () => {
        localStorage.setItem('dawai_session_expired', '1');
        setUser(null);
        clearPendingMfa();
        await signOut().catch(() => undefined);
      }, timeoutMs);
    };
    const events: Array<keyof WindowEventMap> = ['pointerdown', 'keydown', 'touchstart', 'scroll'];
    events.forEach((event) => window.addEventListener(event, reset, { passive: true }));
    reset();
    return () => {
      events.forEach((event) => window.removeEventListener(event, reset));
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
    };
  }, [user?.id, user?.role]);

  const logout = () => {
    recordSecurityEvent('logout').catch(() => undefined);
    setUser(null);
    setJustActivated(false);
    clearPendingMfa();
    signOut().catch(() => undefined);
    localStorage.removeItem('dawai_user');
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };

  const value = useMemo<AuthValue>(() => ({
    user,
    loading,
    justActivated,
    mfaRequired,
    mfaFactor,
    login: setUser,
    logout,
    apiLogin: async (phone, password) => {
      const authenticated = await signIn(phone, password);
      return finalizeAuthenticatedUser(authenticated);
    },
    requestOtpLogin: async (phone) => requestPhoneOtp(phone),
    verifyOtpLogin: async (phone, code) => {
      await verifyPhoneOtp(phone, code);
      const profile = await loadAuthenticatedProfile(loadProfile);
      return finalizeAuthenticatedUser(profile);
    },
    completeMfa: async (code) => {
      if (!mfaFactor) throw new Error('لا يوجد تحقق بخطوتين بانتظار الإدخال');
      await verifyMfaCode(mfaFactor, code);
      const profile = pendingMfaUser ?? await loadAuthenticatedProfile(loadProfile);
      clearPendingMfa();
      setUser(profile);
      await recordSecurityEvent('mfa_verified', { factor_type: mfaFactor.factorType });
      return profile;
    },
    cancelMfa: async () => {
      clearPendingMfa();
      setUser(null);
      await signOut().catch(() => undefined);
    },
    apiRegister: async (name, phone, password, role, options) => {
      const registered = await registerAccount({
        name,
        phone,
        password,
        role,
        vendorName: options?.vendorName,
        governorate: options?.governorate,
        address: options?.address,
        whatsapp: options?.whatsapp,
        instagram: options?.instagram,
        tiktok: options?.tiktok,
        licenseNumber: options?.licenseNumber,
        licenseExpiresAt: options?.licenseExpiresAt,
        licenseFile: options?.licenseFile,
      });
      setUser(registered);
      return registered;
    },
    activateAccount: async () => {
      if (!user) throw new Error('لا يوجد مستخدم مسجّل');
      await activateVendor(user.id);
      setUser({ ...user, status: 'active' });
      setJustActivated(true);
    },
    clearJustActivated: () => setJustActivated(false),
  }), [user, loading, justActivated, mfaRequired, mfaFactor, pendingMfaUser]);

  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside AuthProvider');
  return context;
}
