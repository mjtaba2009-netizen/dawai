import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { AuthContext } from './AuthContext';
import {
  DEFAULT_PUSH_PREFERENCES,
  disablePush,
  enablePush,
  forgetPushUser,
  getPushSnapshot,
  friendlyPushError,
  identifyPushUser,
  loadPushPreferences,
  needsIosInstallForPush,
  savePushPreferences,
  subscribeToPushChanges,
  syncPushSubscription,
  type PushPreferences,
  type PushSnapshot,
} from '@/services/push';

interface PushContextValue extends PushSnapshot {
  loading: boolean;
  busy: boolean;
  error: string | null;
  iosInstallRequired: boolean;
  preferences: PushPreferences;
  enable: () => Promise<void>;
  disable: () => Promise<void>;
  refresh: () => Promise<void>;
  updatePreferences: (updates: Partial<PushPreferences>) => Promise<void>;
}

const EMPTY: PushSnapshot = {
  supported: false,
  initialized: false,
  permission: typeof Notification === 'undefined' ? 'unsupported' : Notification.permission,
  optedIn: false,
  subscriptionId: null,
  oneSignalId: null,
};

export const PushNotificationsContext = createContext<PushContextValue | null>(null);

export function PushNotificationsProvider({ children }: { children: ReactNode }) {
  const auth = useContext(AuthContext);
  const user = auth?.user ?? null;
  const [snapshot, setSnapshot] = useState<PushSnapshot>(EMPTY);
  const [preferences, setPreferences] = useState<PushPreferences>(DEFAULT_PUSH_PREFERENCES);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setError(null);
    try {
      const next = await getPushSnapshot({ initialize: typeof Notification !== 'undefined' && Notification.permission === 'granted' });
      setSnapshot(next);
      if (user && next.initialized) await syncPushSubscription(user, next).catch(() => undefined);
    } catch (cause) {
      setError(friendlyPushError(cause));
    }
  }, [user]);

  useEffect(() => {
    let cancelled = false;
    let unsubscribe: (() => void) | undefined;
    (async () => {
      try {
        const prefsPromise = user
          ? loadPushPreferences().catch(() => DEFAULT_PUSH_PREFERENCES)
          : Promise.resolve(DEFAULT_PUSH_PREFERENCES);

        // لا نهيّئ OneSignal تلقائيًا قبل ضغطة المستخدم عندما تكون الصلاحية default.
        // هذا يحافظ على user activation المطلوبة في iOS لفتح نافذة السماح.
        const canInitializeSilently = typeof Notification !== 'undefined' && Notification.permission === 'granted';
        const next = user
          ? await identifyPushUser(user)
          : await getPushSnapshot({ initialize: canInitializeSilently });
        const prefs = await prefsPromise;

        if (!cancelled) {
          setSnapshot(next);
          setPreferences(prefs);
        }

        if (next.initialized) unsubscribe = subscribeToPushChanges(() => { void refresh(); });
        if (!user) await forgetPushUser();
      } catch (cause) {
        if (!cancelled) setError(friendlyPushError(cause));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; unsubscribe?.(); };
  }, [user?.id, user?.role, user?.pharmacyId, refresh]);

  const enable = useCallback(async () => {
    if (!user) throw new Error('يجب تسجيل الدخول');
    setBusy(true); setError(null);
    try {
      const next = await enablePush(user);
      setSnapshot(next);
      setPreferences((current) => ({ ...current, pushEnabled: true }));
    } catch (cause) {
      const message = friendlyPushError(cause);
      setError(message); throw cause;
    } finally { setBusy(false); }
  }, [user]);

  const disable = useCallback(async () => {
    if (!user) throw new Error('يجب تسجيل الدخول');
    setBusy(true); setError(null);
    try {
      const next = await disablePush(user);
      setSnapshot(next);
      setPreferences((current) => ({ ...current, pushEnabled: false }));
    } finally { setBusy(false); }
  }, [user]);

  const updatePreferences = useCallback(async (updates: Partial<PushPreferences>) => {
    setBusy(true); setError(null);
    try {
      const next = await savePushPreferences(updates);
      setPreferences(next);
    } catch (cause) {
      const message = friendlyPushError(cause);
      setError(message); throw cause;
    } finally { setBusy(false); }
  }, []);

  const value = useMemo<PushContextValue>(() => ({
    ...snapshot,
    loading,
    busy,
    error,
    iosInstallRequired: needsIosInstallForPush(),
    preferences,
    enable,
    disable,
    refresh,
    updatePreferences,
  }), [snapshot, loading, busy, error, preferences, enable, disable, refresh, updatePreferences]);

  return <PushNotificationsContext.Provider value={value}>{children}</PushNotificationsContext.Provider>;
}

export function usePushNotifications() {
  const value = useContext(PushNotificationsContext);
  if (!value) throw new Error('usePushNotifications must be used inside PushNotificationsProvider');
  return value;
}
