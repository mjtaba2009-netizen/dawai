import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export interface CartItem {
  id: number;
  medicationId: number;
  name: string;
  genericName?: string | null;
  category?: string | null;
  requiresPrescription: boolean;
  imageUrl?: string | null;
  price: number;
  quantity: number;
  pharmacyId: number;
  pharmacyName: string;
  pharmacyType?: 'pharmacy' | 'cosmetic';
}

interface CartValue {
  items: CartItem[];
  addItem: (item: Omit<CartItem, 'quantity'> | CartItem, quantity?: number) => void;
  removeItem: (id: number) => void;
  updateQty: (id: number, quantity: number) => void;
  clearCart: () => void;
  totalCount: number;
  totalPrice: number;
  hasPrescriptionItem: boolean;
}

const CartContext = createContext<CartValue | null>(null);
const STORAGE_KEY = 'dawai_cart';

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); } catch { /* no-op */ }
  }, [items]);

  const addItem = useCallback((item: Omit<CartItem, 'quantity'> | CartItem, quantity = 1) => {
    setItems((current) => {
      const existing = current.find((entry) => entry.id === item.id);
      return existing
        ? current.map((entry) => entry.id === item.id ? { ...entry, quantity: entry.quantity + quantity } : entry)
        : [...current, { ...item, quantity } as CartItem];
    });
  }, []);

  const removeItem = useCallback((id: number) => setItems((current) => current.filter((item) => item.id !== id)), []);
  const updateQty = useCallback((id: number, quantity: number) => setItems((current) => current.map((item) => item.id === id ? { ...item, quantity: Math.max(1, quantity) } : item)), []);
  const clearCart = useCallback(() => setItems([]), []);

  const value = useMemo<CartValue>(() => ({
    items,
    addItem,
    removeItem,
    updateQty,
    clearCart,
    totalCount: items.reduce((sum, item) => sum + item.quantity, 0),
    totalPrice: items.reduce((sum, item) => sum + item.price * item.quantity, 0),
    hasPrescriptionItem: items.some((item) => item.requiresPrescription),
  }), [items, addItem, removeItem, updateQty, clearCart]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used inside CartProvider');
  return context;
}
