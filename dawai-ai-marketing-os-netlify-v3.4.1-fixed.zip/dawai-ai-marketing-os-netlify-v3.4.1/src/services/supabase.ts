import { createClient } from '@supabase/supabase-js';

export const SUPABASE_URL = 'https://xjlexnlrbevwlhwzxyqf.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhqbGV4bmxyYmV2d2xod3p4eXFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIwMjg0NzMsImV4cCI6MjA5NzYwNDQ3M30.N53DsLZKGeFSFRgfyMPeZ4WdNjpWdhbSje3ZFmGPAgg';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});
