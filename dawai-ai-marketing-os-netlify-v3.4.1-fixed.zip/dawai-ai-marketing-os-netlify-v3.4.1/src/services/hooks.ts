import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  addInventoryItem,
  createMedicineReminder,
  createOrder,
  createOrderDispute,
  deleteInventoryItem,
  deleteMedicineReminder,
  deleteOwnerVendor,
  deletePrescription,
  fetchAvailableMedications,
  fetchLoyaltyWallet,
  fetchMedicineReminders,
  fetchMyDisputes,
  fetchMySubscription,
  fetchNearbyPharmacies,
  fetchNotifications,
  fetchOrderHistory,
  fetchOrderRating,
  fetchOwnerAuditLogs,
  fetchOwnerDisputes,
  fetchOwnerProductReports,
  fetchOwnerRatings,
  fetchOwnerSubscriptions,
  fetchOwnerVendors,
  fetchPublicOffers,
  fetchPatientOrders,
  fetchPharmacy,
  fetchPharmacyInventory,
  fetchPharmacyOrders,
  markAllNotificationsRead,
  markNotificationRead,
  moderateProductReport,
  moderateRating,
  quoteOrder,
  requestSubscription,
  resolveDispute,
  reviewPrescription,
  searchMedications,
  setOwnerSubscriptionStatus,
  setVendorApproval,
  submitProductReport,
  submitRating,
  suspendOwnerVendor,
  updateInventoryItem,
  updateMedicineReminder,
  updateOrderStatus,
} from './api';

export const queryKeys = {
  pharmacies: ['pharmacies'] as const,
  availableMeds: ['medications', 'available'] as const,
  search: (q: string) => ['medications', 'search', q] as const,
  pharmacy: (id: number) => ['pharmacy', id] as const,
  inventory: (id: number) => ['pharmacy', id, 'inventory'] as const,
  patientOrders: (id: string) => ['orders', id] as const,
  pharmacyOrders: (id: number) => ['pharmacyOrders', id] as const,
  notifications: (id: string) => ['notifications', id] as const,
  ownerVendors: ['owner', 'vendors'] as const,
  offers: ['offers'] as const,
  loyalty: (id: string) => ['loyalty', id] as const,
  subscription: (id: string) => ['subscription', id] as const,
  reminders: (id: string) => ['reminders', id] as const,
  ownerSubscriptions: ['owner', 'subscriptions'] as const,
  orderHistory: (id: number) => ['orderHistory', id] as const,
  myDisputes: ['disputes', 'mine'] as const,
  ownerDisputes: ['owner', 'disputes'] as const,
  ownerReports: ['owner', 'productReports'] as const,
  ownerRatings: ['owner', 'ratings'] as const,
  ownerAudit: ['owner', 'audit'] as const,
  orderRating: (id: number) => ['orderRating', id] as const,
};

export function useNearbyPharmacies() {
  return useQuery({ queryKey: queryKeys.pharmacies, queryFn: fetchNearbyPharmacies, refetchInterval: 10000 });
}

export function useAvailableMedications() {
  return useQuery({ queryKey: queryKeys.availableMeds, queryFn: fetchAvailableMedications, refetchInterval: 10000 });
}

export function useSearchMedications(query: string) {
  const q = query.trim();
  return useQuery({ queryKey: queryKeys.search(q), queryFn: () => searchMedications(q), enabled: q.length > 0 });
}

export function usePharmacy(id: number) {
  return useQuery({ queryKey: queryKeys.pharmacy(id), queryFn: () => fetchPharmacy(id), enabled: Number.isFinite(id) && id > 0 });
}

export function usePharmacyInventory(id: number) {
  return useQuery({ queryKey: queryKeys.inventory(id), queryFn: () => fetchPharmacyInventory(id), enabled: Number.isFinite(id) && id > 0, refetchInterval: 6000 });
}

export function usePatientOrders(userId?: string | null) {
  return useQuery({
    queryKey: queryKeys.patientOrders(userId ?? ''),
    queryFn: () => fetchPatientOrders(userId!),
    enabled: Boolean(userId),
    refetchInterval: 3000,
    refetchOnWindowFocus: true,
  });
}

export function usePharmacyOrders(pharmacyId?: number | null, options?: { refetchInterval?: number }) {
  return useQuery({
    queryKey: queryKeys.pharmacyOrders(pharmacyId ?? -1),
    queryFn: () => fetchPharmacyOrders(pharmacyId!),
    enabled: Boolean(pharmacyId),
    refetchInterval: options?.refetchInterval ?? 3000,
    refetchOnWindowFocus: true,
  });
}

export function useNotifications(userId?: string | null) {
  return useQuery({
    queryKey: queryKeys.notifications(userId ?? ''),
    queryFn: () => fetchNotifications(userId!),
    enabled: Boolean(userId),
    refetchInterval: 4000,
    refetchOnWindowFocus: true,
  });
}

export function useCreateOrder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createOrder,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['pharmacyOrders'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}

export function useUpdateOrderStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => updateOrderStatus(id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['pharmacyOrders'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}

export function useMarkOrderReceived() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => updateOrderStatus(id, 'received'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['pharmacyOrders'] });
    },
  });
}

export function useMarkNotificationRead() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: markNotificationRead,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
  });
}

export function useAddCustomInventory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: addInventoryItem,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pharmacy'] });
      queryClient.invalidateQueries({ queryKey: queryKeys.availableMeds });
    },
  });
}

export function useUpdateInventoryItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: { price?: number; quantity?: number } }) => updateInventoryItem(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pharmacy'] });
      queryClient.invalidateQueries({ queryKey: queryKeys.availableMeds });
    },
  });
}

export function useDeleteInventoryItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deleteInventoryItem,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pharmacy'] });
      queryClient.invalidateQueries({ queryKey: queryKeys.availableMeds });
    },
  });
}

export function useOwnerVendors() {
  return useQuery({
    queryKey: queryKeys.ownerVendors,
    queryFn: fetchOwnerVendors,
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}

export function useSetVendorApproval() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ vendorId, action }: { vendorId: number; action: 'approved' | 'rejected' }) => setVendorApproval(vendorId, action),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerVendors });
      queryClient.invalidateQueries({ queryKey: queryKeys.pharmacies });
    },
  });
}
export function useDeleteOwnerVendor() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (vendorId: number) => deleteOwnerVendor(vendorId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerVendors });
      queryClient.invalidateQueries({ queryKey: queryKeys.pharmacies });
      queryClient.invalidateQueries({ queryKey: queryKeys.availableMeds });
    },
  });
}



export function usePublicOffers() {
  return useQuery({ queryKey: queryKeys.offers, queryFn: fetchPublicOffers, staleTime: 60_000 });
}

export function useLoyaltyWallet(userId?: string | null) {
  return useQuery({
    queryKey: queryKeys.loyalty(userId ?? ''),
    queryFn: () => fetchLoyaltyWallet(userId!),
    enabled: Boolean(userId),
    refetchInterval: 15_000,
  });
}

export function useMySubscription(userId?: string | null) {
  return useQuery({
    queryKey: queryKeys.subscription(userId ?? ''),
    queryFn: () => fetchMySubscription(userId!),
    enabled: Boolean(userId),
    refetchInterval: 15_000,
  });
}

export function useRequestSubscription() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (planCode?: string) => requestSubscription(planCode),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerSubscriptions });
    },
  });
}

export function useMedicineReminders(userId?: string | null) {
  return useQuery({
    queryKey: queryKeys.reminders(userId ?? ''),
    queryFn: () => fetchMedicineReminders(userId!),
    enabled: Boolean(userId),
    refetchInterval: 30_000,
  });
}

export function useCreateMedicineReminder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createMedicineReminder,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['reminders'] }),
  });
}

export function useUpdateMedicineReminder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: Parameters<typeof updateMedicineReminder>[1] }) => updateMedicineReminder(id, updates),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['reminders'] }),
  });
}

export function useDeleteMedicineReminder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deleteMedicineReminder,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['reminders'] }),
  });
}

export function useQuoteOrder() {
  return useMutation({ mutationFn: quoteOrder });
}

export function useOwnerSubscriptions() {
  return useQuery({
    queryKey: queryKeys.ownerSubscriptions,
    queryFn: fetchOwnerSubscriptions,
    refetchInterval: 10_000,
  });
}

export function useSetOwnerSubscriptionStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ subscriptionId, action }: { subscriptionId: number; action: 'active' | 'rejected' }) => setOwnerSubscriptionStatus(subscriptionId, action),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerSubscriptions });
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}


export function useOrderHistory(orderId?: number | null) {
  return useQuery({
    queryKey: queryKeys.orderHistory(orderId ?? -1),
    queryFn: () => fetchOrderHistory(orderId!),
    enabled: Boolean(orderId),
    refetchInterval: 5000,
  });
}

export function useReviewPrescription() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ prescriptionId, status, notes }: { prescriptionId: number; status: 'approved' | 'rejected' | 'needs_clarification'; notes?: string | null }) => reviewPrescription(prescriptionId, status, notes),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pharmacyOrders'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}

export function useDeletePrescription() {
  const queryClient = useQueryClient();
  return useMutation({ mutationFn: deletePrescription, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['orders'] }) });
}

export function useMyDisputes() {
  return useQuery({ queryKey: queryKeys.myDisputes, queryFn: fetchMyDisputes, refetchInterval: 10_000 });
}

export function useCreateDispute() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createOrderDispute,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.myDisputes });
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerDisputes });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}

export function useOwnerDisputes() {
  return useQuery({ queryKey: queryKeys.ownerDisputes, queryFn: fetchOwnerDisputes, refetchInterval: 10_000 });
}

export function useResolveDispute() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status, response }: { id: number; status: 'under_review' | 'resolved' | 'rejected'; response?: string | null }) => resolveDispute(id, status, response),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerDisputes });
      queryClient.invalidateQueries({ queryKey: queryKeys.myDisputes });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}

export function useSubmitProductReport() {
  const queryClient = useQueryClient();
  return useMutation({ mutationFn: submitProductReport, onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.ownerReports }) });
}

export function useOwnerProductReports() {
  return useQuery({ queryKey: queryKeys.ownerReports, queryFn: fetchOwnerProductReports, refetchInterval: 12_000 });
}

export function useModerateProductReport() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status, notes }: { id: number; status: 'under_review' | 'resolved' | 'dismissed'; notes?: string | null }) => moderateProductReport(id, status, notes),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.ownerReports }),
  });
}

export function useOrderRating(orderId?: number | null) {
  return useQuery({ queryKey: queryKeys.orderRating(orderId ?? -1), queryFn: () => fetchOrderRating(orderId!), enabled: Boolean(orderId) });
}

export function useSubmitRating() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: submitRating,
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.orderRating(variables.orderId) });
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerRatings });
      queryClient.invalidateQueries({ queryKey: ['pharmacies'] });
    },
  });
}

export function useOwnerRatings() {
  return useQuery({ queryKey: queryKeys.ownerRatings, queryFn: fetchOwnerRatings, refetchInterval: 15_000 });
}

export function useModerateRating() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: number; status: 'published' | 'hidden' }) => moderateRating(id, status),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.ownerRatings }),
  });
}

export function useOwnerAuditLogs() {
  return useQuery({ queryKey: queryKeys.ownerAudit, queryFn: fetchOwnerAuditLogs, refetchInterval: 15_000 });
}

export function useSuspendOwnerVendor() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ vendorId, reason }: { vendorId: number; reason: string }) => suspendOwnerVendor(vendorId, reason),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.ownerVendors });
      queryClient.invalidateQueries({ queryKey: queryKeys.pharmacies });
    },
  });
}

export function useMarkAllNotificationsRead() {
  const queryClient = useQueryClient();
  return useMutation({ mutationFn: markAllNotificationsRead, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['notifications'] }) });
}
