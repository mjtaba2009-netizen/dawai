import type { AppUser } from './types';
import { supabase } from './supabase';

const DEFAULT_APP_ID = 'b0041836-34a1-4212-98e2-f65bf01aa6ab';
export const ONESIGNAL_APP_ID = (import.meta.env.VITE_ONESIGNAL_APP_ID || DEFAULT_APP_ID).trim();
const PUSH_SCOPE = '/onesignal/';
const PRIMARY_WORKER_PATH = 'onesignal/OneSignalSDKWorker.js';
const SDK_SCRIPT_URL = 'https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js';

export interface SubscriptionChangeEvent {
  current?: unknown;
  previous?: unknown;
  [key: string]: unknown;
}

interface OneSignalPushSubscription {
  optedIn?: boolean;
  id?: string | null;
  optIn: () => Promise<void>;
  optOut: () => Promise<void>;
  addEventListener: (event: 'change', listener: (event: SubscriptionChangeEvent) => void) => void;
  removeEventListener: (event: 'change', listener: (event: SubscriptionChangeEvent) => void) => void;
}

interface OneSignalSdk {
  init: (options: Record<string, unknown>) => Promise<void>;
  login: (externalId: string) => Promise<void>;
  logout: () => Promise<void>;
  Notifications: {
    isPushSupported: () => boolean;
    requestPermission: () => Promise<void>;
  };
  User: {
    onesignalId?: string | null;
    PushSubscription: OneSignalPushSubscription;
    addTags: (tags: Record<string, string>) => Promise<void> | void;
    setLanguage?: (language: string) => Promise<void> | void;
  };
}

declare global {
  interface Window {
    OneSignalDeferred?: Array<(OneSignal: OneSignalSdk) => void | Promise<void>>;
    __DAWAI_ONESIGNAL_READY__?: Promise<OneSignalSdk>;
    __DAWAI_ONESIGNAL__?: OneSignalSdk;
    __DAWAI_ONESIGNAL_ERROR__?: unknown;
    __DAWAI_ONESIGNAL_REJECT__?: (error: unknown) => void;
  }
}

let initPromise: Promise<void> | null = null;
let sdkInitialized = false;
let sdk: OneSignalSdk | null = null;
let currentExternalId: string | null = null;
let identityWarning: string | null = null;
let lastInitError: unknown = null;

export interface PushSnapshot {
  supported: boolean;
  initialized: boolean;
  permission: NotificationPermission | 'unsupported';
  optedIn: boolean;
  subscriptionId: string | null;
  oneSignalId: string | null;
}

class PushSetupError extends Error {
  constructor(public readonly code: string, message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'PushSetupError';
  }
}

function isSecurePushContext() {
  return window.isSecureContext || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
}

export function isIosDevice() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent)
    || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

export function isStandalonePwa() {
  const iosStandalone = Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
  return iosStandalone || window.matchMedia('(display-mode: standalone)').matches;
}

export function needsIosInstallForPush() {
  return isIosDevice() && !isStandalonePwa();
}

function browserSupportsWebPush() {
  return typeof window !== 'undefined'
    && 'Notification' in window
    && 'serviceWorker' in navigator
    && 'PushManager' in window;
}

function errorText(cause: unknown): string {
  if (cause instanceof Error) {
    const nested = 'cause' in cause && cause.cause ? ` | ${errorText(cause.cause)}` : '';
    return `${cause.name}: ${cause.message}${nested}`;
  }
  if (typeof cause === 'string') return cause;
  try { return JSON.stringify(cause); } catch { return 'خطأ غير معروف'; }
}

export function friendlyPushError(cause: unknown) {
  if (cause instanceof PushSetupError) return `${cause.message} (${cause.code})`;
  const raw = errorText(cause);
  if (/PUSH-SDK-NOT-READY/i.test(raw)) return 'خدمة الإشعارات ما زالت تتهيأ. انتظر ثوانٍ واضغط إعادة المحاولة. (PUSH-SDK-NOT-READY)';
  if (/permission.*timeout|permission prompt timeout/i.test(raw)) return 'لم يفتح الجهاز نافذة السماح بالإشعارات. أغلق دوائي وافتحه من أيقونة الشاشة الرئيسية ثم حاول مجددًا. (PUSH-PERMISSION-TIMEOUT)';
  if (/sdk script failed|script.*load|blocked/i.test(raw)) return 'تعذر تحميل مكتبة OneSignal. جرّب شبكة أخرى وأوقف مانع الإعلانات أو Private Relay مؤقتًا. (PUSH-SDK-LOAD)';
  if (/initialization timeout|bootstrap timeout|sdk init/i.test(raw)) return 'خدمة OneSignal لم تكمل التهيئة. استخدم زر إصلاح الإشعارات ثم افتح التطبيق من جديد. (PUSH-SDK-INIT)';
  if (/push subscription timeout/i.test(raw)) return 'تم السماح بالإشعارات لكن تعذر إنشاء الاشتراك. أعد تشغيل التطبيق وحاول مجددًا. (PUSH-SUBSCRIBE)';
  if (/timeout/i.test(raw)) return 'انتهت مهلة الاتصال بخدمة الإشعارات. تحقق من الإنترنت ثم اضغط إعادة المحاولة. (PUSH-TIMEOUT)';
  if (/origin|only be used on/i.test(raw)) return 'رابط المنصة في OneSignal لا يطابق الرابط المفتوح حاليًا. (PUSH-ORIGIN)';
  if (/service.?worker|mime|404|403/i.test(raw)) return 'تعذر تشغيل ملف الإشعارات أو أن مساره غير صحيح. (PUSH-WORKER)';
  if (/already initialized/i.test(raw)) return 'خدمة الإشعارات مهيأة مسبقًا؛ أغلق التطبيق وافتحه من جديد. (PUSH-ALREADY-INIT)';
  return raw || 'تعذر تشغيل الإشعارات';
}

async function withTimeout<T>(promise: Promise<T>, ms: number, label = 'Timeout'): Promise<T> {
  let timer: number | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = window.setTimeout(() => reject(new Error(label)), ms);
  });
  try { return await Promise.race([promise, timeout]); }
  finally { if (timer) window.clearTimeout(timer); }
}

async function verifyWorkerAsset() {
  let response: Response;
  try {
    response = await withTimeout(
      fetch(`/${PRIMARY_WORKER_PATH}?v=3.3.0`, { cache: 'no-store', credentials: 'same-origin' }),
      12000,
      'Worker fetch timeout',
    );
  } catch (cause) {
    throw new PushSetupError('PUSH-WORKER-FETCH', 'تعذر الوصول إلى ملف الإشعارات.', { cause });
  }

  if (!response.ok) {
    throw new PushSetupError('PUSH-WORKER-HTTP', `ملف الإشعارات أعاد الحالة ${response.status}.`);
  }

  const source = await response.text();
  if (!source.includes('OneSignalSDK.sw.js')) {
    throw new PushSetupError('PUSH-WORKER-CONTENT', 'ملف الإشعارات لا يحتوي كود OneSignal الصحيح.');
  }
}

async function getBootstrappedSdk(): Promise<OneSignalSdk> {
  const script = document.getElementById('onesignal-web-sdk') as HTMLScriptElement | null;
  if (!script) {
    throw new PushSetupError('PUSH-SDK-TAG', 'وسم تحميل OneSignal غير موجود داخل الصفحة.');
  }

  const ready = window.__DAWAI_ONESIGNAL_READY__;
  if (!ready) {
    throw new PushSetupError('PUSH-SDK-BOOTSTRAP', 'تهيئة OneSignal المبكرة غير موجودة.');
  }

  try {
    return await withTimeout(ready, 60000, 'OneSignal bootstrap timeout');
  } catch (cause) {
    const actual = window.__DAWAI_ONESIGNAL_ERROR__ ?? cause;
    const code = /script failed|load/i.test(errorText(actual)) ? 'PUSH-SDK-LOAD' : 'PUSH-SDK-INIT';
    throw new PushSetupError(code, code === 'PUSH-SDK-LOAD'
      ? 'تعذر تحميل مكتبة OneSignal من الشبكة.'
      : 'خدمة OneSignal لم تكمل التهيئة.', { cause: actual });
  }
}

export async function initializePush(): Promise<void> {
  if (sdkInitialized && sdk) return;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    if (typeof window === 'undefined') return;
    if (!isSecurePushContext()) throw new PushSetupError('PUSH-HTTPS', 'الإشعارات تحتاج رابط HTTPS آمن.');
    if (!ONESIGNAL_APP_ID) throw new PushSetupError('PUSH-APP-ID', 'OneSignal App ID غير موجود.');
    if (!browserSupportsWebPush()) throw new PushSetupError('PUSH-UNSUPPORTED', 'هذا المتصفح لا يدعم إشعارات الويب.');

    const [, initializedSdk] = await Promise.all([
      verifyWorkerAsset(),
      getBootstrappedSdk(),
    ]);

    sdk = initializedSdk;
    sdkInitialized = true;
    lastInitError = null;
    try { await sdk.User.setLanguage?.('ar'); } catch { /* Language is optional. */ }
  })().catch((error) => {
    initPromise = null;
    sdkInitialized = false;
    sdk = null;
    lastInitError = error;
    throw error;
  });

  return initPromise;
}

function currentSdk() {
  if (!sdkInitialized || !sdk) {
    throw new PushSetupError('PUSH-SDK-NOT-READY', 'خدمة الإشعارات ما زالت تتهيأ.');
  }
  return sdk;
}

export async function getPushSnapshot(options: { initialize?: boolean } = {}): Promise<PushSnapshot> {
  if (!browserSupportsWebPush()) {
    return { supported: false, initialized: false, permission: 'unsupported', optedIn: false, subscriptionId: null, oneSignalId: null };
  }

  const shouldInitialize = options.initialize ?? Notification.permission === 'granted';
  if (shouldInitialize && !sdkInitialized) await initializePush();

  if (!sdkInitialized || !sdk) {
    return {
      supported: true,
      initialized: false,
      permission: Notification.permission,
      optedIn: false,
      subscriptionId: null,
      oneSignalId: null,
    };
  }

  return {
    supported: sdk.Notifications.isPushSupported(),
    initialized: true,
    permission: Notification.permission,
    optedIn: Boolean(sdk.User.PushSubscription.optedIn),
    subscriptionId: sdk.User.PushSubscription.id ?? null,
    oneSignalId: sdk.User.onesignalId ?? null,
  };
}

function platformName() {
  if (isIosDevice()) return isStandalonePwa() ? 'ios_pwa' : 'ios_safari';
  if (/Android/i.test(navigator.userAgent)) return 'android_web';
  return 'web';
}

export async function syncPushSubscription(user: AppUser, snapshot?: PushSnapshot) {
  const state = snapshot ?? await getPushSnapshot();
  if (!state.subscriptionId) return;
  const { error } = await supabase.from('push_subscriptions').upsert({
    user_id: user.id,
    subscription_id: state.subscriptionId,
    onesignal_id: state.oneSignalId,
    platform: platformName(),
    permission: state.permission,
    opted_in: state.optedIn,
    user_agent: navigator.userAgent.slice(0, 500),
    last_seen_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }, { onConflict: 'subscription_id' });
  if (error && error.code !== '42P01') throw error;
}

async function identifyInBackground(user: AppUser) {
  if (!sdkInitialized || !sdk) return;
  try {
    if (currentExternalId !== user.id) {
      await withTimeout(sdk.login(user.id), 15000, 'OneSignal login timeout');
      currentExternalId = user.id;
    }
    await sdk.User.addTags({
      role: user.role,
      pharmacy_id: user.pharmacyId ? String(user.pharmacyId) : 'none',
      status: user.status,
      locale: 'ar-IQ',
    });
    identityWarning = null;
  } catch (cause) {
    identityWarning = friendlyPushError(cause);
  }
}

export function getPushIdentityWarning() { return identityWarning; }

export async function identifyPushUser(user: AppUser): Promise<PushSnapshot> {
  const snapshot = await getPushSnapshot({ initialize: true });
  if (!snapshot.initialized) return snapshot;
  await identifyInBackground(user);
  const updated = await getPushSnapshot();
  await syncPushSubscription(user, updated).catch(() => undefined);
  return updated;
}

export async function forgetPushUser() {
  if (!sdkInitialized || !sdk || !currentExternalId) return;
  try { await sdk.logout(); } finally { currentExternalId = null; }
}

async function requestOneSignalPermissionFromUserGesture() {
  if (Notification.permission === 'granted') return 'granted' as NotificationPermission;
  if (Notification.permission === 'denied') return 'denied' as NotificationPermission;
  const activeSdk = currentSdk();
  try {
    await withTimeout(activeSdk.Notifications.requestPermission(), 30000, 'Permission prompt timeout');
    return Notification.permission;
  } catch (cause) {
    throw new PushSetupError('PUSH-PERMISSION-TIMEOUT', 'لم يفتح الجهاز نافذة السماح بالإشعارات.', { cause });
  }
}

export async function enablePush(user: AppUser): Promise<PushSnapshot> {
  if (needsIosInstallForPush()) {
    throw new PushSetupError('PUSH-IOS-INSTALL', 'على الآيفون أضف المنصة إلى الشاشة الرئيسية ثم افتحها من الأيقونة لتفعيل الإشعارات.');
  }
  if (!browserSupportsWebPush()) throw new PushSetupError('PUSH-UNSUPPORTED', 'هذا المتصفح لا يدعم إشعارات الويب.');

  // Initialization begins from index.html before React starts, preserving the user gesture for the native prompt.
  if (!sdkInitialized || !sdk) {
    throw new PushSetupError('PUSH-SDK-NOT-READY', 'خدمة الإشعارات ما زالت تتهيأ. انتظر ثوانٍ واضغط إعادة المحاولة.');
  }

  const permission = await requestOneSignalPermissionFromUserGesture();
  if (permission === 'denied') throw new PushSetupError('PUSH-PERMISSION-DENIED', 'الإشعارات محظورة من إعدادات الجهاز. فعّلها من الإعدادات ← الإشعارات ← دوائي.');
  if (permission !== 'granted') throw new PushSetupError('PUSH-PERMISSION-NOT-GRANTED', 'لم يتم السماح بالإشعارات على هذا الجهاز.');
  if (!sdk.Notifications.isPushSupported()) throw new PushSetupError('PUSH-UNSUPPORTED-SDK', 'OneSignal لا يعتبر هذا الجهاز داعمًا للإشعارات.');

  if (!sdk.User.PushSubscription.optedIn) {
    try {
      await withTimeout(sdk.User.PushSubscription.optIn(), 30000, 'Push subscription timeout');
    } catch (cause) {
      throw new PushSetupError('PUSH-SUBSCRIBE', 'تعذر إنشاء اشتراك الإشعارات على هذا الجهاز.', { cause });
    }
  }

  await identifyInBackground(user);
  const snapshot = await getPushSnapshot();
  await syncPushSubscription(user, snapshot);
  await savePushPreferences({ pushEnabled: true });
  return snapshot;
}

export async function disablePush(user: AppUser): Promise<PushSnapshot> {
  await initializePush();
  const activeSdk = currentSdk();
  await activeSdk.User.PushSubscription.optOut();
  const snapshot = await getPushSnapshot();
  await syncPushSubscription(user, snapshot).catch(() => undefined);
  await savePushPreferences({ pushEnabled: false });
  return snapshot;
}

export interface PushPreferences {
  pushEnabled: boolean;
  orderUpdates: boolean;
  vendorUpdates: boolean;
  reminders: boolean;
  promotions: boolean;
  securityAlerts: boolean;
}

export const DEFAULT_PUSH_PREFERENCES: PushPreferences = {
  pushEnabled: true,
  orderUpdates: true,
  vendorUpdates: true,
  reminders: true,
  promotions: false,
  securityAlerts: true,
};

export async function loadPushPreferences(): Promise<PushPreferences> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return DEFAULT_PUSH_PREFERENCES;
  const { data, error } = await supabase.from('notification_preferences').select('*').eq('user_id', auth.user.id).maybeSingle();
  if (error) {
    if (error.code === '42P01' || error.code === 'PGRST205') return DEFAULT_PUSH_PREFERENCES;
    throw error;
  }
  if (!data) return DEFAULT_PUSH_PREFERENCES;
  return {
    pushEnabled: data.push_enabled !== false,
    orderUpdates: data.order_updates !== false,
    vendorUpdates: data.vendor_updates !== false,
    reminders: data.reminders !== false,
    promotions: data.promotions === true,
    securityAlerts: data.security_alerts !== false,
  };
}

export async function savePushPreferences(updates: Partial<PushPreferences>) {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('يجب تسجيل الدخول');
  const current = await loadPushPreferences();
  const next = { ...current, ...updates };
  const { error } = await supabase.from('notification_preferences').upsert({
    user_id: auth.user.id,
    push_enabled: next.pushEnabled,
    order_updates: next.orderUpdates,
    vendor_updates: next.vendorUpdates,
    reminders: next.reminders,
    promotions: next.promotions,
    security_alerts: next.securityAlerts,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id' });
  if (error) throw error;
  return next;
}

export function subscribeToPushChanges(listener: (event: SubscriptionChangeEvent) => void) {
  if (!sdkInitialized || !sdk) return () => undefined;
  sdk.User.PushSubscription.addEventListener('change', listener);
  return () => sdk?.User.PushSubscription.removeEventListener('change', listener);
}

async function deleteOneSignalIndexedDb() {
  const indexedDbWithList = indexedDB as IDBFactory & { databases?: () => Promise<Array<{ name?: string }>> };
  if (!indexedDbWithList.databases) return [] as string[];
  const databases = await indexedDbWithList.databases().catch(() => []);
  const names = databases
    .map((item) => item.name)
    .filter((name): name is string => Boolean(name && /one.?signal/i.test(name)));
  await Promise.all(names.map((name) => new Promise<void>((resolve) => {
    const request = indexedDB.deleteDatabase(name);
    request.onsuccess = () => resolve();
    request.onerror = () => resolve();
    request.onblocked = () => resolve();
  })));
  return names;
}

export async function repairPushInstallation() {
  const removed: string[] = [];
  if ('serviceWorker' in navigator) {
    const registrations = await navigator.serviceWorker.getRegistrations();
    for (const registration of registrations) {
      const scriptUrl = registration.active?.scriptURL
        ?? registration.waiting?.scriptURL
        ?? registration.installing?.scriptURL
        ?? '';
      if (registration.scope.includes('/onesignal/') || /OneSignalSDKWorker/i.test(scriptUrl)) {
        if (await registration.unregister()) removed.push(registration.scope);
      }
    }
  }

  if ('caches' in window) {
    const cacheNames = await caches.keys();
    await Promise.all(cacheNames
      .filter((name) => /one.?signal/i.test(name))
      .map((name) => caches.delete(name)));
  }

  for (const storage of [localStorage, sessionStorage]) {
    const keys = Array.from({ length: storage.length }, (_, index) => storage.key(index))
      .filter((key): key is string => Boolean(key && /one.?signal/i.test(key)));
    keys.forEach((key) => storage.removeItem(key));
  }

  const databases = 'indexedDB' in window ? await deleteOneSignalIndexedDb().catch(() => []) : [];
  return { removedRegistrations: removed, removedDatabases: databases };
}

export async function collectPushDiagnostics() {
  const registrations = 'serviceWorker' in navigator
    ? await navigator.serviceWorker.getRegistrations().then((items) => items.map((registration) => ({
        scope: registration.scope,
        active: registration.active?.scriptURL ?? null,
        state: registration.active?.state ?? registration.installing?.state ?? registration.waiting?.state ?? null,
      }))).catch(() => [])
    : [];

  let workerCheck: Record<string, unknown>;
  try {
    const response = await withTimeout(fetch(`/${PRIMARY_WORKER_PATH}?diagnostic=1`, { cache: 'no-store' }), 8000, 'diagnostic timeout');
    workerCheck = {
      ok: response.ok,
      status: response.status,
      contentType: response.headers.get('content-type'),
      serviceWorkerAllowed: response.headers.get('service-worker-allowed'),
      bodyPrefix: (await response.text()).slice(0, 100),
    };
  } catch (cause) {
    workerCheck = { ok: false, error: errorText(cause) };
  }

  const script = document.getElementById('onesignal-web-sdk') as HTMLScriptElement | null;
  const connection = (navigator as Navigator & { connection?: { effectiveType?: string; saveData?: boolean } }).connection;

  return {
    version: '3.3.0',
    timestamp: new Date().toISOString(),
    origin: location.origin,
    href: location.href,
    online: navigator.onLine,
    visibility: document.visibilityState,
    secureContext: window.isSecureContext,
    userAgent: navigator.userAgent,
    ios: isIosDevice(),
    standalone: isStandalonePwa(),
    notificationApi: 'Notification' in window,
    permission: 'Notification' in window ? Notification.permission : 'unsupported',
    serviceWorkerApi: 'serviceWorker' in navigator,
    pushManagerApi: 'PushManager' in window,
    sdkScriptPresent: Boolean(script),
    sdkScriptUrl: script?.src ?? SDK_SCRIPT_URL,
    bootstrapPromisePresent: Boolean(window.__DAWAI_ONESIGNAL_READY__),
    bootstrapError: window.__DAWAI_ONESIGNAL_ERROR__ ? errorText(window.__DAWAI_ONESIGNAL_ERROR__) : null,
    lastInitError: lastInitError ? errorText(lastInitError) : null,
    sdkInitialized,
    appIdSuffix: ONESIGNAL_APP_ID.slice(-8),
    connection: connection ?? null,
    registrations,
    workerCheck,
  };
}

export async function diagnosticsAsText() {
  return JSON.stringify(await collectPushDiagnostics(), null, 2);
}

export async function sendPushTest(): Promise<number> {
  const { data, error } = await supabase.rpc('dawai_create_push_test_v30');
  if (error) throw error;
  return Number(data);
}
