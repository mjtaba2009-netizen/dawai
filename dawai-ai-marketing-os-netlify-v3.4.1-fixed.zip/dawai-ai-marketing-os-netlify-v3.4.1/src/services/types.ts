export type VendorType = 'pharmacy' | 'cosmetic';
export type UserRole = 'patient' | VendorType | 'owner';
export type UserStatus = 'active' | 'pending_approval' | 'approved_pending_signature' | 'rejected';

export interface AppUser {
  id: string;
  name: string;
  phone: string;
  role: UserRole;
  status: UserStatus;
  pharmacyId: number | null;
  avatar?: string | null;
  governorate?: string | null;
  address?: string | null;
  token?: string;
}

export type VendorVerificationStatus = 'not_submitted' | 'submitted' | 'verified' | 'rejected' | 'suspended' | 'expired';

export interface VendorDocument {
  id: number;
  pharmacyId: number;
  documentType: 'license' | 'identity' | 'trade_registration' | 'other';
  filePath: string;
  licenseNumber: string | null;
  expiresAt: string | null;
  status: 'submitted' | 'approved' | 'rejected' | 'expired';
  reviewNotes: string | null;
  createdAt: string;
  signedUrl?: string | null;
}

export interface Pharmacy {
  id: number;
  ownerId?: string | null;
  name: string;
  type: VendorType;
  address: string | null;
  governorate: string;
  phone: string | null;
  whatsapp: string | null;
  instagram?: string | null;
  tiktok?: string | null;
  rating: number;
  distance: number;
  deliveryMinutes: number;
  deliveryFee: number;
  isOpen: boolean;
  imageUrl: string | null;
  status?: string;
  verificationStatus?: VendorVerificationStatus;
  licenseNumber?: string | null;
  licenseExpiresAt?: string | null;
  verifiedAt?: string | null;
  createdAt?: string | null;
}

export type AuthenticityStatus = 'unverified' | 'declared_original' | 'verified' | 'flagged';

export interface Medication {
  id: number;
  name: string;
  genericName: string | null;
  category: string | null;
  description?: string | null;
  requiresPrescription: boolean;
  imageUrl: string | null;
  manufacturer?: string | null;
  countryOfOrigin?: string | null;
  batchNumber?: string | null;
  expiryDate?: string | null;
  originalPrice?: number | null;
  authenticityStatus?: AuthenticityStatus;
}

export interface InventoryItem {
  id: number;
  price: number;
  quantity: number;
  medication: Medication;
}

export interface CatalogItem {
  id: number;
  medicationId: number;
  name: string;
  genericName: string | null;
  category: string | null;
  requiresPrescription: boolean;
  imageUrl: string | null;
  price: number;
  quantity: number;
  pharmacyId: number;
  pharmacyName: string;
  pharmacyType: VendorType;
  manufacturer?: string | null;
  countryOfOrigin?: string | null;
  batchNumber?: string | null;
  expiryDate?: string | null;
  originalPrice?: number | null;
  authenticityStatus?: AuthenticityStatus;
}

export type OrderStatus = 'pending' | 'confirmed' | 'ready' | 'completed' | 'cancelled' | 'rejected' | 'timeout' | 'received';
export type PaymentMethod = 'cash_on_delivery' | 'wallet' | 'card_on_delivery';

export interface PatientOrder {
  id: number;
  status: OrderStatus;
  quantity: number;
  subtotal: number;
  discountAmount: number;
  deliveryFee: number;
  totalPrice: number;
  couponCode: string | null;
  loyaltyPointsRedeemed: number;
  loyaltyPointsEarned: number;
  prescriptionId: number | null;
  trackingCode: string | null;
  paymentMethod: PaymentMethod;
  receivedAt: string | null;
  createdAt: string;
  medication: Medication | null;
  pharmacy: Pick<Pharmacy, 'id' | 'name' | 'type' | 'phone' | 'whatsapp'> | null;
}

export interface KanbanOrder {
  id: number;
  status: OrderStatus;
  trackingCode: string | null;
  quantity: number;
  subtotal: number;
  discountAmount: number;
  deliveryFee: number;
  totalPrice: number;
  prescriptionId: number | null;
  paymentMethod: PaymentMethod;
  createdAt: string;
  medication: (Pick<Medication, 'id' | 'name' | 'genericName' | 'requiresPrescription'>) | null;
}

export interface OrderHistoryEvent {
  id: number;
  orderId: number;
  oldStatus: string | null;
  newStatus: string;
  note: string | null;
  actorName: string | null;
  createdAt: string;
}

export interface AppNotification {
  id: number;
  title: string | null;
  message: string | null;
  type: string;
  isRead: boolean;
  actionUrl?: string | null;
  createdAt: string;
}

export interface OwnerVendorRecord extends Pharmacy {
  ownerProfile?: { id: string; name: string | null; phone: string | null; status: string | null } | null;
  documents?: VendorDocument[];
}

export interface PrescriptionSubmission {
  id: number;
  imagePath: string;
  prescriptionDate: string;
  status?: 'submitted' | 'under_review' | 'approved' | 'rejected' | 'needs_clarification' | 'deleted';
  reviewNotes?: string | null;
}

export interface CouponQuote {
  valid: boolean;
  code: string | null;
  message: string;
  subtotal: number;
  couponDiscount: number;
  pointsDiscount: number;
  deliveryFee: number;
  subscriptionDiscount: number;
  total: number;
  redeemablePoints: number;
}

export interface PublicOffer {
  id: number;
  code: string;
  title: string;
  description: string | null;
  discountType: 'percent' | 'fixed';
  discountValue: number;
  minOrder: number;
  maxDiscount: number | null;
  endsAt: string | null;
}

export interface LoyaltyWallet {
  points: number;
  lifetimeEarned: number;
  lifetimeRedeemed: number;
}

export type SubscriptionStatus = 'pending' | 'active' | 'rejected' | 'expired' | 'cancelled';

export interface UserSubscription {
  id: number;
  userId: string;
  status: SubscriptionStatus;
  planCode: string;
  planName: string;
  monthlyPrice: number;
  deliveryDiscount: number;
  startsAt: string | null;
  endsAt: string | null;
  createdAt: string;
  userName?: string | null;
  userPhone?: string | null;
}

export interface MedicineReminder {
  id: number;
  medicationId: number | null;
  medicationName: string;
  nextReminderAt: string;
  repeatDays: number;
  notes: string | null;
  isActive: boolean;
  createdAt: string;
}

export interface VendorReportProduct {
  name: string;
  quantity: number;
  revenue: number;
}

export interface VendorReport {
  totalOrders: number;
  completedOrders: number;
  cancelledOrders: number;
  activeOrders: number;
  grossSales: number;
  netSales: number;
  averageOrder: number;
  cancellationRate: number;
  topProducts: VendorReportProduct[];
}

export type DisputeStatus = 'open' | 'under_review' | 'resolved' | 'rejected';
export interface OrderDispute {
  id: number;
  orderId: number;
  userId: string;
  reason: string;
  description: string | null;
  evidencePath: string | null;
  status: DisputeStatus;
  ownerResponse: string | null;
  createdAt: string;
  orderTrackingCode?: string | null;
  userName?: string | null;
  userPhone?: string | null;
}

export type ProductReportStatus = 'open' | 'under_review' | 'resolved' | 'dismissed';
export interface ProductReport {
  id: number;
  userId: string;
  pharmacyId: number;
  medicationId: number;
  orderId: number | null;
  reason: string;
  details: string | null;
  evidencePath: string | null;
  status: ProductReportStatus;
  ownerNotes: string | null;
  createdAt: string;
  medicationName?: string | null;
  pharmacyName?: string | null;
  userName?: string | null;
}

export type RatingModerationStatus = 'pending' | 'published' | 'hidden';
export interface ProductRating {
  id: number;
  orderId: number;
  userId: string;
  pharmacyId: number;
  medicationId: number | null;
  rating: number;
  speedRating: number | null;
  packagingRating: number | null;
  matchRating: number | null;
  comment: string | null;
  status: RatingModerationStatus;
  createdAt: string;
  userName?: string | null;
  pharmacyName?: string | null;
  medicationName?: string | null;
}

export interface OwnerAuditLog {
  id: number;
  action: string;
  targetType: string | null;
  targetId: string | null;
  details: Record<string, unknown> | null;
  actorName: string | null;
  createdAt: string;
}

export interface MfaFactorSummary {
  id: string;
  factorType: 'totp' | 'phone';
  status: string;
  friendlyName: string | null;
  phone?: string | null;
}

export interface SecurityState {
  currentLevel: 'aal1' | 'aal2' | null;
  nextLevel: 'aal1' | 'aal2' | null;
  factors: MfaFactorSummary[];
  phoneVerified: boolean;
  authPhone: string | null;
}
