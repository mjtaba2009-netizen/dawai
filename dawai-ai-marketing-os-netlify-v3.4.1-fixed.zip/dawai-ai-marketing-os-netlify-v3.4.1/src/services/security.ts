import { supabase } from './supabase';
import type { AppUser, MfaFactorSummary, SecurityState } from './types';

export function toIraqiE164(value: string): string {
  let digits = value.replace(/\D/g, '');
  if (digits.startsWith('00964')) digits = digits.slice(2);
  if (digits.startsWith('964')) return `+${digits}`;
  if (digits.startsWith('0')) digits = digits.slice(1);
  return `+964${digits}`;
}

export async function getSecurityState(): Promise<SecurityState> {
  const [aalResult, factorsResult, userResult] = await Promise.all([
    supabase.auth.mfa.getAuthenticatorAssuranceLevel(),
    supabase.auth.mfa.listFactors(),
    supabase.auth.getUser(),
  ]);
  if (aalResult.error) throw aalResult.error;
  if (factorsResult.error) throw factorsResult.error;
  if (userResult.error) throw userResult.error;

  const raw = factorsResult.data as any;
  const factors: MfaFactorSummary[] = [
    ...((raw?.totp ?? []) as any[]).map((factor) => ({
      id: factor.id,
      factorType: 'totp' as const,
      status: factor.status,
      friendlyName: factor.friendly_name ?? null,
    })),
    ...((raw?.phone ?? []) as any[]).map((factor) => ({
      id: factor.id,
      factorType: 'phone' as const,
      status: factor.status,
      friendlyName: factor.friendly_name ?? null,
      phone: factor.phone ?? null,
    })),
  ];

  const user = userResult.data.user;
  return {
    currentLevel: (aalResult.data?.currentLevel ?? null) as SecurityState['currentLevel'],
    nextLevel: (aalResult.data?.nextLevel ?? null) as SecurityState['nextLevel'],
    factors,
    phoneVerified: Boolean(user?.phone_confirmed_at),
    authPhone: user?.phone ?? null,
  };
}

export async function requestPhoneOtp(phone: string) {
  const formatted = toIraqiE164(phone);
  const { error } = await supabase.auth.signInWithOtp({
    phone: formatted,
    options: { shouldCreateUser: false },
  });
  if (error) throw error;
  return formatted;
}

export async function verifyPhoneOtp(phone: string, token: string) {
  const formatted = toIraqiE164(phone);
  const { data, error } = await supabase.auth.verifyOtp({ phone: formatted, token: token.trim(), type: 'sms' });
  if (error) throw error;
  if (!data.session?.user) throw new Error('لم يتم إنشاء جلسة بعد التحقق من الرمز');
  return data.session;
}

export async function requestPhoneLink(phone: string) {
  const formatted = toIraqiE164(phone);
  const { error } = await supabase.auth.updateUser({ phone: formatted });
  if (error) throw error;
  return formatted;
}

export async function verifyPhoneLink(phone: string, token: string) {
  const formatted = toIraqiE164(phone);
  const { data, error } = await supabase.auth.verifyOtp({ phone: formatted, token: token.trim(), type: 'phone_change' });
  if (error) throw error;
  return data;
}

export async function startTotpEnrollment() {
  const { data, error } = await supabase.auth.mfa.enroll({
    factorType: 'totp',
    friendlyName: 'منصة دوائي',
  });
  if (error) throw error;
  return {
    factorId: data.id,
    qrCode: data.totp.qr_code,
    secret: data.totp.secret,
    uri: data.totp.uri,
  };
}

export async function verifyTotpEnrollment(factorId: string, code: string) {
  const { data, error } = await supabase.auth.mfa.challengeAndVerify({ factorId, code: code.trim() });
  if (error) throw error;
  return data;
}

export async function challengeMfaFactor(factor: MfaFactorSummary) {
  const { data, error } = await supabase.auth.mfa.challenge({ factorId: factor.id });
  if (error) throw error;
  return data.id;
}

export async function verifyMfaChallenge(factorId: string, challengeId: string, code: string) {
  const { data, error } = await supabase.auth.mfa.verify({
    factorId,
    challengeId,
    code: code.trim(),
  });
  if (error) throw error;
  return data;
}

export async function verifyMfaCode(factor: MfaFactorSummary, code: string) {
  const challengeId = await challengeMfaFactor(factor);
  return verifyMfaChallenge(factor.id, challengeId, code);
}

export async function removeMfaFactor(factorId: string) {
  const { data, error } = await supabase.auth.mfa.unenroll({ factorId });
  if (error) throw error;
  return data;
}

export async function reauthenticateWithPassword(password: string) {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  const email = userData.user?.email;
  if (!email) throw new Error('تعذّر تحديد حساب تسجيل الدخول الحالي');
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw new Error('كلمة المرور غير صحيحة');
  return data;
}

export async function recordSecurityEvent(eventType: string, details: Record<string, unknown> = {}) {
  try {
    await supabase.from('security_events').insert({ event_type: eventType, details });
  } catch {
    // لا نعطّل تسجيل الدخول إذا لم تُشغّل ترقية قاعدة البيانات بعد.
  }
}

export async function loadAuthenticatedProfile(loader: (id: string, token?: string) => Promise<AppUser | null>) {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  const session = data.session;
  if (!session?.user) throw new Error('انتهت جلسة تسجيل الدخول');
  const profile = await loader(session.user.id, session.access_token);
  if (!profile) throw new Error('تعذّر تحميل الملف الشخصي');
  return profile;
}
