import { supabase } from './supabase';
import type {
  AppNotification,
  AppUser,
  CatalogItem,
  CouponQuote,
  InventoryItem,
  KanbanOrder,
  LoyaltyWallet,
  MedicineReminder,
  OrderDispute,
  OrderHistoryEvent,
  OwnerAuditLog,
  OwnerVendorRecord,
  PatientOrder,
  Pharmacy,
  PrescriptionSubmission,
  ProductRating,
  ProductReport,
  PublicOffer,
  UserRole,
  UserStatus,
  UserSubscription,
  VendorType,
} from './types';
import { prepareProductImage } from '@/lib/image';

const DEFAULT_GOVERNORATE = 'البصرة';
const PHONE_DOMAIN = 'phone.dawai.app';

const toNumber = (value: unknown, fallback = 0) => value == null || Number.isNaN(Number(value)) ? fallback : Number(value);
export const normalizePhone = (value: string) => value.replace(/\D/g, '');
export const phoneToEmail = (value: string) => `${normalizePhone(value)}@${PHONE_DOMAIN}`;
const normalizeVendorType = (value: unknown): VendorType => value === 'cosmetic' ? 'cosmetic' : 'pharmacy';

function readCache<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(`dawai_cache_${key}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { value: T; savedAt: number };
    if (Date.now() - parsed.savedAt > 24 * 60 * 60 * 1000) return null;
    return parsed.value;
  } catch { return null; }
}

function writeCache<T>(key: string, value: T) {
  try { localStorage.setItem(`dawai_cache_${key}`, JSON.stringify({ value, savedAt: Date.now() })); } catch { /* storage may be full */ }
}

async function withOfflineCache<T>(key: string, loader: () => Promise<T>): Promise<T> {
  try {
    const value = await loader();
    writeCache(key, value);
    return value;
  } catch (error) {
    const cached = readCache<T>(key);
    if (cached) return cached;
    throw error;
  }
}

export const estimateDeliveryMinutes = (distance: number, configured?: unknown) => {
  const explicit = toNumber(configured);
  if (explicit > 0) return Math.round(explicit);
  return Math.max(15, Math.min(120, Math.round(18 + Math.max(0, distance) * 7)));
};

function mapProfile(row: any, token = ''): AppUser {
  const rawStatus = String(row.status ?? 'active');
  const allowedStatuses: UserStatus[] = ['active', 'pending_approval', 'approved_pending_signature', 'rejected'];
  const status = allowedStatuses.includes(rawStatus as UserStatus) ? rawStatus as UserStatus : 'active';
  const role = (['patient', 'pharmacy', 'cosmetic', 'owner'].includes(row.role) ? row.role : 'patient') as UserRole;
  return {
    id: row.id,
    name: row.name ?? '',
    phone: row.phone ?? '',
    role,
    status,
    pharmacyId: row.pharmacy_id ?? null,
    avatar: row.avatar ?? null,
    governorate: row.governorate ?? null,
    address: row.address ?? null,
    token,
  };
}

function mapPharmacy(row: any): Pharmacy {
  return {
    id: Number(row.id),
    ownerId: row.owner_id ?? null,
    name: row.name,
    type: normalizeVendorType(row.type),
    address: row.address ?? null,
    governorate: row.governorate ?? DEFAULT_GOVERNORATE,
    phone: row.phone ?? null,
    whatsapp: row.whatsapp ?? null,
    instagram: row.instagram ?? null,
    tiktok: row.tiktok ?? null,
    rating: toNumber(row.rating),
    distance: toNumber(row.distance),
    deliveryMinutes: estimateDeliveryMinutes(toNumber(row.distance), row.delivery_minutes),
    deliveryFee: toNumber(row.delivery_fee, 2500),
    isOpen: row.is_open ?? true,
    imageUrl: row.image_url ?? null,
    status: row.status ?? 'approved',
    verificationStatus: row.verification_status ?? (row.status === 'approved' ? 'verified' : 'submitted'),
    licenseNumber: row.license_number ?? null,
    licenseExpiresAt: row.license_expires_at ?? null,
    verifiedAt: row.verified_at ?? null,
    createdAt: row.created_at ?? null,
  };
}

function mapMedication(row: any) {
  return {
    id: Number(row.id),
    name: row.name,
    genericName: row.generic_name ?? null,
    category: row.category ?? null,
    description: row.description ?? null,
    requiresPrescription: Boolean(row.requires_prescription),
    imageUrl: row.image_url ?? null,
    manufacturer: row.manufacturer ?? null,
    countryOfOrigin: row.country_of_origin ?? null,
    batchNumber: row.batch_number ?? null,
    expiryDate: row.expiry_date ?? null,
    originalPrice: row.original_price == null ? null : toNumber(row.original_price),
    authenticityStatus: row.authenticity_status ?? 'unverified',
  };
}

function mapInventory(row: any): InventoryItem {
  return {
    id: Number(row.id),
    price: toNumber(row.price),
    quantity: toNumber(row.quantity),
    medication: mapMedication(row.medication),
  };
}

function mapPatientOrder(row: any): PatientOrder {
  const subtotal = toNumber(row.subtotal, toNumber(row.total_price));
  return {
    id: Number(row.id),
    status: row.status,
    quantity: toNumber(row.quantity, 1),
    subtotal,
    discountAmount: toNumber(row.discount_amount),
    deliveryFee: toNumber(row.delivery_fee),
    totalPrice: toNumber(row.total_price),
    couponCode: row.coupon_code ?? null,
    loyaltyPointsRedeemed: toNumber(row.loyalty_points_redeemed),
    loyaltyPointsEarned: toNumber(row.loyalty_points_earned),
    prescriptionId: row.prescription_id == null ? null : Number(row.prescription_id),
    trackingCode: row.tracking_code ?? null,
    paymentMethod: row.payment_method ?? 'cash_on_delivery',
    receivedAt: row.received_at ?? null,
    createdAt: row.created_at,
    medication: row.medication ? mapMedication(row.medication) : null,
    pharmacy: row.pharmacy ? {
      id: Number(row.pharmacy.id),
      name: row.pharmacy.name,
      type: normalizeVendorType(row.pharmacy.type),
      phone: row.pharmacy.phone ?? null,
      whatsapp: row.pharmacy.whatsapp ?? null,
    } : null,
  };
}

function mapKanbanOrder(row: any): KanbanOrder {
  const subtotal = toNumber(row.subtotal, toNumber(row.total_price));
  return {
    id: Number(row.id),
    status: row.status,
    trackingCode: row.tracking_code ?? null,
    quantity: toNumber(row.quantity, 1),
    subtotal,
    discountAmount: toNumber(row.discount_amount),
    deliveryFee: toNumber(row.delivery_fee),
    totalPrice: toNumber(row.total_price),
    prescriptionId: row.prescription_id == null ? null : Number(row.prescription_id),
    paymentMethod: row.payment_method ?? 'cash_on_delivery',
    createdAt: row.created_at,
    medication: row.medication ? {
      id: Number(row.medication.id),
      name: row.medication.name,
      genericName: row.medication.generic_name ?? null,
      requiresPrescription: Boolean(row.medication.requires_prescription),
    } : null,
  };
}

export async function loadProfile(userId: string, token = ''): Promise<AppUser | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  if (error) throw error;
  return data ? mapProfile(data, token) : null;
}

export async function updateMyProfile(input: {
  name?: string;
  governorate?: string | null;
  address?: string | null;
  vendorName?: string | null;
}): Promise<AppUser> {
  const { data: authData, error: authError } = await supabase.auth.getSession();
  if (authError) throw authError;
  const session = authData.session;
  if (!session?.user) throw new Error('انتهت جلسة تسجيل الدخول');

  const { data, error } = await supabase.rpc('dawai_update_my_profile_v32', {
    p_name: input.name?.trim() || null,
    p_governorate: input.governorate?.trim() || null,
    p_address: input.address?.trim() || null,
  });
  if (error) throw error;

  if (input.vendorName?.trim()) {
    const profile = Array.isArray(data) ? data[0] : data;
    const pharmacyId = profile?.pharmacy_id;
    if (pharmacyId) {
      const { error: vendorError } = await supabase
        .from('pharmacies')
        .update({ name: input.vendorName.trim() })
        .eq('id', pharmacyId);
      if (vendorError) throw vendorError;
    }
  }

  const profile = await loadProfile(session.user.id, session.access_token);
  if (!profile) throw new Error('تعذّر إعادة تحميل الملف الشخصي');
  return profile;
}

export async function changeMyPhone(newPhone: string, currentPassword: string): Promise<AppUser> {
  const normalized = normalizePhone(newPhone);
  if (!/^07\d{9}$/.test(normalized)) throw new Error('أدخل رقمًا عراقيًا صحيحًا يبدأ بـ 07 ويتكون من 11 رقمًا');

  const { data: userResult, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  const email = userResult.user?.email;
  if (!email) throw new Error('تعذّر تحديد حساب تسجيل الدخول الحالي');

  const { error: reauthError } = await supabase.auth.signInWithPassword({ email, password: currentPassword });
  if (reauthError) throw new Error('كلمة المرور الحالية غير صحيحة');

  const { error: updateAuthError } = await supabase.auth.updateUser({
    email: phoneToEmail(normalized),
    data: { phone: normalized },
  });
  if (updateAuthError) throw updateAuthError;

  const { error: profileError } = await supabase.rpc('dawai_update_my_phone_v32', { p_phone: normalized });
  if (profileError) throw profileError;

  const { data: sessionData } = await supabase.auth.getSession();
  const profile = await loadProfile(userResult.user.id, sessionData.session?.access_token ?? '');
  if (!profile) throw new Error('تعذّر إعادة تحميل الحساب');
  return profile;
}

export async function changeMyPassword(currentPassword: string, newPassword: string) {
  if (newPassword.length < 8 || !/[A-Za-z]/.test(newPassword) || !/\d/.test(newPassword)) {
    throw new Error('كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل وتحتوي على حرف ورقم');
  }
  const { data: userResult, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  const email = userResult.user?.email;
  if (!email) throw new Error('تعذّر تحديد حساب تسجيل الدخول الحالي');
  const { error: reauthError } = await supabase.auth.signInWithPassword({ email, password: currentPassword });
  if (reauthError) throw new Error('كلمة المرور الحالية غير صحيحة');
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw error;
}

export async function logoutOtherSessions() {
  const { error } = await supabase.auth.signOut({ scope: 'others' });
  if (error) throw error;
}

export async function submitPlatformFeedback(rating: number, comment: string) {
  const { data: authData } = await supabase.auth.getUser();
  if (!authData.user) throw new Error('يجب تسجيل الدخول');
  const { error } = await supabase.from('platform_feedback').insert({
    user_id: authData.user.id,
    rating,
    comment: comment.trim() || null,
  });
  if (error) throw error;
}

export async function signIn(phone: string, password: string): Promise<AppUser> {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: phoneToEmail(phone),
    password,
  });
  if (error) throw error;
  if (!data.user || !data.session) throw new Error('فشل تسجيل الدخول');

  const profile = await loadProfile(data.user.id, data.session.access_token);
  if (!profile) throw new Error('تعذّر تحميل الملف الشخصي. تأكد من إنشاء سجل الحساب في profiles.');
  return profile;
}

export async function registerAccount(input: {
  name: string;
  phone: string;
  password: string;
  role?: UserRole;
  vendorName?: string | null;
  governorate?: string;
  address?: string | null;
  whatsapp?: string | null;
  instagram?: string | null;
  tiktok?: string | null;
  imageUrl?: string | null;
  licenseNumber?: string | null;
  licenseExpiresAt?: string | null;
  licenseFile?: File | null;
}): Promise<AppUser> {
  const role = input.role ?? 'patient';
  if (role === 'owner') throw new Error('لا يمكن إنشاء حساب مالك من التسجيل العام');

  const { data, error } = await supabase.auth.signUp({
    email: phoneToEmail(input.phone),
    password: input.password,
    options: { data: { name: input.name, phone: normalizePhone(input.phone), role } },
  });
  if (error) throw error;
  if (!data.user) throw new Error('تعذّر إنشاء الحساب');
  if (!data.session) throw new Error('يجب إيقاف تأكيد البريد من إعدادات Supabase Auth لإكمال التسجيل');

  const isVendor = role === 'pharmacy' || role === 'cosmetic';
  let pharmacyId: number | null = null;

  if (isVendor) {
    const { data: vendor, error: vendorError } = await supabase.from('pharmacies').insert({
      owner_id: data.user.id,
      name: input.vendorName || input.name,
      type: role,
      governorate: input.governorate || DEFAULT_GOVERNORATE,
      address: input.address ?? null,
      phone: normalizePhone(input.phone),
      whatsapp: input.whatsapp ?? null,
      instagram: input.instagram ?? null,
      tiktok: input.tiktok ?? null,
      image_url: input.imageUrl ?? null,
      status: 'pending',
      verification_status: 'submitted',
      license_number: input.licenseNumber?.trim() || null,
      license_expires_at: input.licenseExpiresAt || null,
    }).select('id').single();
    if (vendorError) throw vendorError;
    pharmacyId = Number(vendor.id);

    if (input.licenseFile) {
      const safeName = input.licenseFile.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const path = `${data.user.id}/${pharmacyId}/${Date.now()}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from('vendor-documents').upload(path, input.licenseFile, {
        cacheControl: '3600',
        upsert: false,
        contentType: input.licenseFile.type || undefined,
      });
      if (uploadError) throw new Error(`تعذّر رفع وثيقة الترخيص: ${uploadError.message}`);
      const { error: documentError } = await supabase.from('vendor_documents').insert({
        pharmacy_id: pharmacyId,
        owner_id: data.user.id,
        document_type: role === 'pharmacy' ? 'license' : 'trade_registration',
        file_path: path,
        license_number: input.licenseNumber?.trim() || null,
        expires_at: input.licenseExpiresAt || null,
        status: 'submitted',
      });
      if (documentError) throw documentError;
    }
  }

  const status: UserStatus = isVendor ? 'pending_approval' : 'active';
  const { data: profile, error: profileError } = await supabase.from('profiles').upsert({
    id: data.user.id,
    name: input.name,
    phone: normalizePhone(input.phone),
    role,
    status,
    pharmacy_id: pharmacyId,
  }).select('*').single();
  if (profileError) throw profileError;
  return mapProfile(profile, data.session.access_token);
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function activateVendor(userId: string): Promise<void> {
  const { error } = await supabase.from('profiles').update({ status: 'active' }).eq('id', userId);
  if (error) throw error;
}

export async function fetchNearbyPharmacies(): Promise<Pharmacy[]> {
  return withOfflineCache('nearby_pharmacies', async () => {
    const { data, error } = await supabase.from('pharmacies').select('*').eq('status', 'approved').order('distance', { ascending: true });
    if (error) throw error;
    return (data ?? []).filter((row: any) => !row.verification_status || row.verification_status === 'verified').map(mapPharmacy);
  });
}

export async function fetchPharmacy(id: number): Promise<Pharmacy | null> {
  const { data, error } = await supabase.from('pharmacies').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data ? mapPharmacy(data) : null;
}

export async function fetchAvailableMedications(): Promise<CatalogItem[]> {
  return withOfflineCache('available_medications', async () => {
  const { data, error } = await supabase.from('pharmacy_medications').select(
    'id, price, quantity, medication:medications(*), pharmacy:pharmacies(id,name,type,status,verification_status)',
  ).gt('quantity', 0);
  if (error) throw error;
  return (data ?? []).filter((row: any) => row.medication && row.pharmacy && row.pharmacy.status === 'approved' && (!row.pharmacy.verification_status || row.pharmacy.verification_status === 'verified')).map((row: any) => ({
    id: Number(row.id),
    medicationId: Number(row.medication.id),
    name: row.medication.name,
    genericName: row.medication.generic_name ?? null,
    category: row.medication.category ?? null,
    requiresPrescription: Boolean(row.medication.requires_prescription),
    imageUrl: row.medication.image_url ?? null,
    price: toNumber(row.price),
    quantity: toNumber(row.quantity),
    pharmacyId: Number(row.pharmacy.id),
    pharmacyName: row.pharmacy.name,
    pharmacyType: normalizeVendorType(row.pharmacy.type),
    manufacturer: row.medication.manufacturer ?? null,
    countryOfOrigin: row.medication.country_of_origin ?? null,
    batchNumber: row.medication.batch_number ?? null,
    expiryDate: row.medication.expiry_date ?? null,
    originalPrice: row.medication.original_price == null ? null : toNumber(row.medication.original_price),
    authenticityStatus: row.medication.authenticity_status ?? 'unverified',
  }));
  });
}

export async function searchMedications(term: string) {
  const like = `%${term}%`;
  const { data, error } = await supabase.from('medications').select(
    '*, pharmacy_medications(price,quantity,pharmacy:pharmacies(*))',
  ).or(`name.ilike.${like},generic_name.ilike.${like}`);
  if (error) throw error;
  return (data ?? []).map((med: any) => ({
    ...mapMedication(med),
    pharmacies: (med.pharmacy_medications ?? []).filter((link: any) => link.pharmacy?.status === 'approved' && (!link.pharmacy.verification_status || link.pharmacy.verification_status === 'verified')).map((link: any) => ({
      pharmacyId: Number(link.pharmacy.id),
      pharmacyName: link.pharmacy.name,
      type: normalizeVendorType(link.pharmacy.type),
      address: link.pharmacy.address ?? null,
      price: toNumber(link.price),
      quantity: toNumber(link.quantity),
      distance: toNumber(link.pharmacy.distance),
      deliveryMinutes: estimateDeliveryMinutes(toNumber(link.pharmacy.distance), link.pharmacy.delivery_minutes),
      deliveryFee: toNumber(link.pharmacy.delivery_fee, 2500),
      rating: toNumber(link.pharmacy.rating),
      whatsapp: link.pharmacy.whatsapp ?? null,
      isOpen: link.pharmacy.is_open ?? true,
    })),
  }));
}

export async function fetchPharmacyInventory(pharmacyId: number): Promise<InventoryItem[]> {
  const { data, error } = await supabase.from('pharmacy_medications').select('id,price,quantity,medication:medications(*)').eq('pharmacy_id', pharmacyId).order('updated_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).filter((row: any) => row.medication).map(mapInventory);
}

export async function addInventoryItem(input: {
  pharmacyId: number;
  name: string;
  genericName?: string | null;
  category?: string | null;
  requiresPrescription?: boolean;
  imageUrl?: string | null;
  manufacturer?: string | null;
  countryOfOrigin?: string | null;
  batchNumber?: string | null;
  expiryDate?: string | null;
  originalPrice?: number | null;
  authenticityStatus?: 'unverified' | 'declared_original' | 'verified' | 'flagged';
  price: number;
  quantity: number;
}): Promise<InventoryItem> {
  const { data: med, error: medError } = await supabase.from('medications').insert({
    name: input.name,
    generic_name: input.genericName ?? null,
    category: input.category ?? null,
    requires_prescription: Boolean(input.requiresPrescription),
    image_url: input.imageUrl ?? null,
    manufacturer: input.manufacturer?.trim() || null,
    country_of_origin: input.countryOfOrigin?.trim() || null,
    batch_number: input.batchNumber?.trim() || null,
    expiry_date: input.expiryDate || null,
    original_price: input.originalPrice ?? null,
    authenticity_status: input.authenticityStatus ?? 'declared_original',
  }).select('*').single();
  if (medError) throw medError;

  const { data, error } = await supabase.from('pharmacy_medications').insert({
    pharmacy_id: input.pharmacyId,
    medication_id: med.id,
    price: input.price,
    quantity: input.quantity,
  }).select('id,price,quantity,medication:medications(*)').single();
  if (error) throw error;
  return mapInventory(data);
}

export async function updateInventoryItem(id: number, updates: { price?: number; quantity?: number }) {
  const { error } = await supabase.from('pharmacy_medications').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id);
  if (error) throw error;
}

export async function deleteInventoryItem(id: number) {
  const { error } = await supabase.from('pharmacy_medications').delete().eq('id', id);
  if (error) throw error;
}

function trackingCode() {
  return `#DW-${Math.floor(1000 + Math.random() * 9000)}`;
}

export async function uploadPrescription(file: File, prescriptionDate: string): Promise<PrescriptionSubmission> {
  const { data: authData } = await supabase.auth.getUser();
  const userId = authData.user?.id;
  if (!userId) throw new Error('يجب تسجيل الدخول لرفع الوصفة');

  const prepared = await prepareProductImage(file);
  const blob = await (await fetch(prepared)).blob();
  const contentType = blob.type || 'image/jpeg';
  const extension = contentType.includes('png') ? 'png'
    : contentType.includes('webp') ? 'webp'
      : contentType.includes('heic') ? 'heic'
        : contentType.includes('heif') ? 'heif'
          : 'jpg';
  const imagePath = `${userId}/${Date.now()}-${crypto.randomUUID()}.${extension}`;
  const { error: uploadError } = await supabase.storage.from('prescriptions').upload(imagePath, blob, {
    contentType,
    cacheControl: '3600',
    upsert: false,
  });
  if (uploadError) throw uploadError;

  const { data, error } = await supabase.from('prescriptions').insert({
    user_id: userId,
    image_path: imagePath,
    prescription_date: prescriptionDate,
    status: 'submitted',
  }).select('id,image_path,prescription_date').single();

  if (error) {
    await supabase.storage.from('prescriptions').remove([imagePath]);
    throw error;
  }

  return {
    id: Number(data.id),
    imagePath: data.image_path,
    prescriptionDate: data.prescription_date,
  };
}

export async function getPrescriptionSignedUrl(prescriptionId: number): Promise<string> {
  const { data: prescription, error } = await supabase.from('prescriptions').select('image_path,status').eq('id', prescriptionId).neq('status', 'deleted').single();
  if (error) throw error;
  const { data, error: signedError } = await supabase.storage.from('prescriptions').createSignedUrl(prescription.image_path, 600);
  if (signedError) throw signedError;
  return data.signedUrl;
}

export async function quoteOrder(input: {
  pharmacyId: number;
  subtotal: number;
  couponCode?: string | null;
  redeemPoints?: number;
}): Promise<CouponQuote> {
  const { data, error } = await supabase.rpc('dawai_quote_order_v27', {
    p_pharmacy_id: input.pharmacyId,
    p_subtotal: input.subtotal,
    p_coupon_code: input.couponCode?.trim() || null,
    p_redeem_points: Math.max(0, Math.floor(input.redeemPoints ?? 0)),
  });
  if (error) throw error;
  return {
    valid: Boolean(data?.valid),
    code: data?.code ?? null,
    message: String(data?.message ?? ''),
    subtotal: toNumber(data?.subtotal, input.subtotal),
    couponDiscount: toNumber(data?.coupon_discount),
    pointsDiscount: toNumber(data?.points_discount),
    deliveryFee: toNumber(data?.delivery_fee),
    subscriptionDiscount: toNumber(data?.subscription_discount),
    total: toNumber(data?.total, input.subtotal),
    redeemablePoints: toNumber(data?.redeemable_points),
  };
}

export async function createOrder(input: {
  pharmacyId: number;
  medicationId: number;
  quantity: number;
  prescriptionId?: number | null;
  couponCode?: string | null;
  redeemPoints?: number;
  paymentMethod?: 'cash_on_delivery' | 'wallet' | 'card_on_delivery';
  clientRequestId?: string;
}): Promise<PatientOrder> {
  const pendingKey = `dawai_pending_order:${input.pharmacyId}:${input.medicationId}:${input.quantity}`;
  let clientRequestId = input.clientRequestId;
  if (!clientRequestId) {
    try { clientRequestId = sessionStorage.getItem(pendingKey) || undefined; } catch { /* storage unavailable */ }
  }
  clientRequestId ||= crypto.randomUUID();
  try { sessionStorage.setItem(pendingKey, clientRequestId); } catch { /* storage unavailable */ }
  const { data, error } = await supabase.rpc('dawai_create_order_v28', {
    p_pharmacy_id: input.pharmacyId,
    p_medication_id: input.medicationId,
    p_quantity: Math.max(1, Math.floor(input.quantity || 1)),
    p_prescription_id: input.prescriptionId ?? null,
    p_coupon_code: input.couponCode?.trim() || null,
    p_redeem_points: Math.max(0, Math.floor(input.redeemPoints ?? 0)),
    p_payment_method: input.paymentMethod ?? 'cash_on_delivery',
    p_client_request_id: clientRequestId,
  });
  if (error) {
    if (error.code === 'PGRST202' || error.code === '42883') {
      throw new Error('ميزات الأمان والطلبات تحتاج تشغيل ملف SQL الإصدار 2.8 في Supabase');
    }
    throw error;
  }

  const orderId = Number(data?.order_id ?? data?.id);
  if (!Number.isFinite(orderId) || orderId <= 0) throw new Error('تعذّر قراءة رقم الطلب الجديد');
  const { data: row, error: readError } = await supabase
    .from('orders')
    .select('*,medication:medications(*),pharmacy:pharmacies(*)')
    .eq('id', orderId)
    .single();
  if (readError) throw readError;
  try { sessionStorage.removeItem(pendingKey); } catch { /* storage unavailable */ }
  return mapPatientOrder(row);
}

const STATUS_MESSAGES: Record<string, string> = {
  confirmed: 'تم قبول طلبك وبدأ المتجر بتحضيره',
  ready: 'طلبك أصبح جاهزاً للاستلام أو التوصيل',
  completed: 'تم إكمال طلبك بنجاح',
  rejected: 'عذراً، تم رفض الطلب من المتجر',
  cancelled: 'تم إلغاء الطلب',
  received: 'تم تأكيد استلام الطلب',
};

export async function updateOrderStatus(orderId: number, status: string, note?: string | null) {
  const { error } = await supabase.rpc('dawai_update_order_status_v28', {
    p_order_id: orderId,
    p_status: status,
    p_note: note?.trim() || null,
  });
  if (error) throw error;
}

export async function fetchPatientOrders(userId: string): Promise<PatientOrder[]> {
  const { data, error } = await supabase.from('orders').select('*,medication:medications(*),pharmacy:pharmacies(*)').eq('user_id', userId).order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map(mapPatientOrder);
}

export async function fetchPharmacyOrders(pharmacyId: number): Promise<KanbanOrder[]> {
  const { data, error } = await supabase.from('orders').select('*,medication:medications(*)').eq('pharmacy_id', pharmacyId).order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map(mapKanbanOrder);
}

export async function fetchNotifications(userId: string): Promise<AppNotification[]> {
  const { data, error } = await supabase.from('notifications').select('*').eq('user_id', userId).order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    id: Number(row.id),
    title: row.title ?? null,
    message: row.message ?? null,
    type: row.type ?? 'system',
    isRead: Boolean(row.is_read),
    actionUrl: row.action_url ?? null,
    createdAt: row.created_at,
  }));
}

export async function markNotificationRead(id: number) {
  const { error } = await supabase.from('notifications').update({ is_read: true }).eq('id', id);
  if (error) throw error;
}


export async function fetchPublicOffers(): Promise<PublicOffer[]> {
  const now = new Date().toISOString();
  const { data, error } = await supabase.from('coupons').select('*')
    .eq('is_active', true)
    .eq('is_public', true)
    .lte('starts_at', now)
    .or(`ends_at.is.null,ends_at.gte.${now}`)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    id: Number(row.id),
    code: row.code,
    title: row.title,
    description: row.description ?? null,
    discountType: row.discount_type,
    discountValue: toNumber(row.discount_value),
    minOrder: toNumber(row.min_order),
    maxDiscount: row.max_discount == null ? null : toNumber(row.max_discount),
    endsAt: row.ends_at ?? null,
  }));
}

export async function fetchLoyaltyWallet(userId: string): Promise<LoyaltyWallet> {
  const { data, error } = await supabase.from('loyalty_wallets').select('*').eq('user_id', userId).maybeSingle();
  if (error) throw error;
  return {
    points: toNumber(data?.points),
    lifetimeEarned: toNumber(data?.lifetime_earned),
    lifetimeRedeemed: toNumber(data?.lifetime_redeemed),
  };
}

function mapSubscription(row: any): UserSubscription {
  return {
    id: Number(row.id),
    userId: row.user_id,
    status: row.status,
    planCode: row.plan_code,
    planName: row.plan?.name ?? row.plan_name ?? 'دوائي بلس',
    monthlyPrice: toNumber(row.plan?.monthly_price ?? row.monthly_price),
    deliveryDiscount: toNumber(row.plan?.delivery_discount ?? row.delivery_discount),
    startsAt: row.starts_at ?? null,
    endsAt: row.ends_at ?? null,
    createdAt: row.created_at,
    userName: row.profile?.name ?? null,
    userPhone: row.profile?.phone ?? null,
  };
}

export async function fetchMySubscription(userId: string): Promise<UserSubscription | null> {
  const { data, error } = await supabase.from('user_subscriptions')
    .select('*,plan:subscription_plans(*)')
    .eq('user_id', userId)
    .in('status', ['pending', 'active'])
    .order('created_at', { ascending: false })
    .limit(10);
  if (error) throw error;

  const now = Date.now();
  const row = (data ?? []).find((item: any) => {
    if (item.status === 'pending') return true;
    if (item.status !== 'active') return false;
    return !item.ends_at || new Date(item.ends_at).getTime() > now;
  });

  return row ? mapSubscription(row) : null;
}

export async function requestSubscription(planCode = 'dawai_plus'): Promise<UserSubscription> {
  const { data: authData } = await supabase.auth.getUser();
  const userId = authData.user?.id;
  if (!userId) throw new Error('يجب تسجيل الدخول');

  const { data: existingRows, error: existingError } = await supabase.from('user_subscriptions')
    .select('*,plan:subscription_plans(*)')
    .eq('user_id', userId)
    .in('status', ['pending', 'active'])
    .order('created_at', { ascending: false })
    .limit(10);
  if (existingError) throw existingError;
  const now = Date.now();
  const existing = (existingRows ?? []).find((item: any) =>
    item.status === 'pending' ||
    (item.status === 'active' && (!item.ends_at || new Date(item.ends_at).getTime() > now))
  );
  if (existing) return mapSubscription(existing);

  const { data, error } = await supabase.from('user_subscriptions').insert({
    user_id: userId,
    plan_code: planCode,
    status: 'pending',
    payment_method: 'manual',
  }).select('*,plan:subscription_plans(*)').single();
  if (error) throw error;
  return mapSubscription(data);
}

export async function fetchMedicineReminders(userId: string): Promise<MedicineReminder[]> {
  const { data, error } = await supabase.from('medicine_reminders').select('*')
    .eq('user_id', userId).order('next_reminder_at', { ascending: true });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    id: Number(row.id),
    medicationId: row.medication_id == null ? null : Number(row.medication_id),
    medicationName: row.medication_name,
    nextReminderAt: row.next_reminder_at,
    repeatDays: toNumber(row.repeat_days, 30),
    notes: row.notes ?? null,
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
  }));
}

export async function createMedicineReminder(input: {
  medicationId?: number | null;
  medicationName: string;
  nextReminderAt: string;
  repeatDays: number;
  notes?: string | null;
}): Promise<MedicineReminder> {
  const { data: authData } = await supabase.auth.getUser();
  const userId = authData.user?.id;
  if (!userId) throw new Error('يجب تسجيل الدخول');
  const { data, error } = await supabase.from('medicine_reminders').insert({
    user_id: userId,
    medication_id: input.medicationId ?? null,
    medication_name: input.medicationName.trim(),
    next_reminder_at: input.nextReminderAt,
    repeat_days: Math.max(1, Math.floor(input.repeatDays)),
    notes: input.notes?.trim() || null,
    is_active: true,
  }).select('*').single();
  if (error) throw error;
  return {
    id: Number(data.id),
    medicationId: data.medication_id == null ? null : Number(data.medication_id),
    medicationName: data.medication_name,
    nextReminderAt: data.next_reminder_at,
    repeatDays: toNumber(data.repeat_days, 30),
    notes: data.notes ?? null,
    isActive: Boolean(data.is_active),
    createdAt: data.created_at,
  };
}

export async function updateMedicineReminder(id: number, updates: Partial<Pick<MedicineReminder, 'nextReminderAt' | 'repeatDays' | 'notes' | 'isActive'>>) {
  const payload: Record<string, unknown> = {};
  if (updates.nextReminderAt !== undefined) payload.next_reminder_at = updates.nextReminderAt;
  if (updates.repeatDays !== undefined) payload.repeat_days = Math.max(1, Math.floor(updates.repeatDays));
  if (updates.notes !== undefined) payload.notes = updates.notes;
  if (updates.isActive !== undefined) payload.is_active = updates.isActive;
  const { error } = await supabase.from('medicine_reminders').update(payload).eq('id', id);
  if (error) throw error;
}

export async function deleteMedicineReminder(id: number) {
  const { error } = await supabase.from('medicine_reminders').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchOwnerSubscriptions(): Promise<UserSubscription[]> {
  const { data: subscriptions, error } = await supabase.from('user_subscriptions')
    .select('*,plan:subscription_plans(*)')
    .order('created_at', { ascending: false });
  if (error) throw error;

  const userIds = [...new Set((subscriptions ?? []).map((item: any) => item.user_id).filter(Boolean))];
  let profiles: any[] = [];
  if (userIds.length) {
    const result = await supabase.from('profiles').select('id,name,phone').in('id', userIds);
    if (result.error) throw result.error;
    profiles = result.data ?? [];
  }
  const profileById = new Map(profiles.map((profile) => [profile.id, profile]));

  return (subscriptions ?? []).map((row: any) =>
    mapSubscription({ ...row, profile: profileById.get(row.user_id) ?? null })
  );
}

export async function setOwnerSubscriptionStatus(subscriptionId: number, action: 'active' | 'rejected') {
  const { data, error } = await supabase.rpc('dawai_owner_set_subscription_v28', {
    p_subscription_id: subscriptionId,
    p_action: action,
  });
  if (error) throw error;
  return data;
}

export async function fetchOwnerVendors(): Promise<OwnerVendorRecord[]> {
  const { data: vendors, error } = await supabase.from('pharmacies').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  const visible = (vendors ?? []).filter((vendor: any) => vendor.status !== 'deleted');
  const ownerIds = [...new Set(visible.map((v: any) => v.owner_id).filter(Boolean))];
  const vendorIds = visible.map((v: any) => Number(v.id));
  let profiles: any[] = [];
  let documents: any[] = [];
  if (ownerIds.length) {
    const result = await supabase.from('profiles').select('id,name,phone,status').in('id', ownerIds);
    if (result.error) throw result.error;
    profiles = result.data ?? [];
  }
  if (vendorIds.length) {
    const result = await supabase.from('vendor_documents').select('*').in('pharmacy_id', vendorIds).order('created_at', { ascending: false });
    if (result.error) throw result.error;
    documents = result.data ?? [];
  }
  const profileById = new Map(profiles.map((p) => [p.id, p]));
  const documentsByVendor = new Map<number, any[]>();
  documents.forEach((doc) => {
    const id = Number(doc.pharmacy_id);
    documentsByVendor.set(id, [...(documentsByVendor.get(id) ?? []), doc]);
  });
  return visible.map((v: any) => ({
    ...mapPharmacy(v),
    ownerProfile: profileById.get(v.owner_id) ?? null,
    documents: (documentsByVendor.get(Number(v.id)) ?? []).map((doc: any) => ({
      id: Number(doc.id),
      pharmacyId: Number(doc.pharmacy_id),
      documentType: doc.document_type,
      filePath: doc.file_path,
      licenseNumber: doc.license_number ?? null,
      expiresAt: doc.expires_at ?? null,
      status: doc.status,
      reviewNotes: doc.review_notes ?? null,
      createdAt: doc.created_at,
    })),
  }));
}

export async function getVendorDocumentSignedUrl(filePath: string) {
  const { data, error } = await supabase.storage.from('vendor-documents').createSignedUrl(filePath, 300);
  if (error) throw error;
  return data.signedUrl;
}

export async function setVendorApproval(vendorId: number, action: 'approved' | 'rejected', note?: string | null) {
  const { data, error } = await supabase.rpc('dawai_owner_review_vendor_v28', {
    p_vendor_id: vendorId,
    p_action: action,
    p_note: note?.trim() || null,
  });
  if (error) throw error;
  return data;
}

export async function suspendOwnerVendor(vendorId: number, reason: string) {
  const { data, error } = await supabase.rpc('dawai_owner_suspend_vendor_v28', {
    p_vendor_id: vendorId,
    p_reason: reason.trim(),
  });
  if (error) throw error;
  return data;
}

export async function deleteOwnerVendor(vendorId: number) {
  const { data, error } = await supabase.rpc('dawai_owner_delete_vendor_v28', {
    p_vendor_id: vendorId,
  });
  if (error) throw error;
  if (data && typeof data === 'object' && 'success' in data && data.success === false) {
    throw new Error(typeof data.message === 'string' ? data.message : 'تعذّر حذف المتجر');
  }
  return data;
}

export async function fetchOrderHistory(orderId: number): Promise<OrderHistoryEvent[]> {
  const { data, error } = await supabase.from('order_status_history')
    .select('*')
    .eq('order_id', orderId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  const rows = data ?? [];
  const actorIds = [...new Set(rows.map((row: any) => row.changed_by).filter(Boolean))];
  const actorById = new Map<string, string | null>();
  if (actorIds.length) {
    const result = await supabase.from('profiles').select('id,name').in('id', actorIds);
    if (!result.error) (result.data ?? []).forEach((profile: any) => actorById.set(profile.id, profile.name ?? null));
  }
  return rows.map((row: any) => ({
    id: Number(row.id),
    orderId: Number(row.order_id),
    oldStatus: row.old_status ?? null,
    newStatus: row.new_status,
    note: row.note ?? null,
    actorName: row.changed_by ? actorById.get(row.changed_by) ?? null : null,
    createdAt: row.created_at,
  }));
}

export async function reviewPrescription(prescriptionId: number, status: 'approved' | 'rejected' | 'needs_clarification', notes?: string | null) {
  const { data, error } = await supabase.rpc('dawai_review_prescription_v28', {
    p_prescription_id: prescriptionId,
    p_status: status,
    p_notes: notes?.trim() || null,
  });
  if (error) throw error;
  return data;
}

export async function deletePrescription(prescriptionId: number) {
  const { data: row, error: readError } = await supabase.from('prescriptions').select('image_path,user_id').eq('id', prescriptionId).single();
  if (readError) throw readError;
  const { error } = await supabase.rpc('dawai_delete_prescription_v28', { p_prescription_id: prescriptionId });
  if (error) throw error;
  if (row?.image_path) await supabase.storage.from('prescriptions').remove([row.image_path]).catch(() => undefined);
}

export async function createOrderDispute(input: { orderId: number; reason: string; description?: string | null; evidenceFile?: File | null }): Promise<OrderDispute> {
  let evidencePath: string | null = null;
  if (input.evidenceFile) {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) throw new Error('يجب تسجيل الدخول');
    const safeName = input.evidenceFile.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    evidencePath = `${auth.user.id}/${input.orderId}/${Date.now()}-${safeName}`;
    const { error: uploadError } = await supabase.storage.from('dispute-evidence').upload(evidencePath, input.evidenceFile, {
      contentType: input.evidenceFile.type || undefined,
      upsert: false,
    });
    if (uploadError) throw uploadError;
  }
  const { data, error } = await supabase.rpc('dawai_create_dispute_v28', {
    p_order_id: input.orderId,
    p_reason: input.reason,
    p_description: input.description?.trim() || null,
    p_evidence_path: evidencePath,
  });
  if (error) throw error;
  return {
    id: Number(data.id), orderId: input.orderId, userId: data.user_id,
    reason: input.reason, description: input.description ?? null, evidencePath,
    status: data.status ?? 'open', ownerResponse: null, createdAt: data.created_at ?? new Date().toISOString(),
  };
}

export async function fetchMyDisputes(): Promise<OrderDispute[]> {
  const { data, error } = await supabase.from('order_disputes').select('*,order:orders(tracking_code)').order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    id: Number(row.id), orderId: Number(row.order_id), userId: row.user_id, reason: row.reason,
    description: row.description ?? null, evidencePath: row.evidence_path ?? null, status: row.status,
    ownerResponse: row.owner_response ?? null, createdAt: row.created_at,
    orderTrackingCode: row.order?.tracking_code ?? null,
  }));
}

export async function getDisputeEvidenceSignedUrl(filePath: string) {
  const { data, error } = await supabase.storage.from('dispute-evidence').createSignedUrl(filePath, 300);
  if (error) throw error;
  return data.signedUrl;
}

export async function fetchOwnerDisputes(): Promise<OrderDispute[]> {
  const { data, error } = await supabase.from('order_disputes')
    .select('*,order:orders(tracking_code)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  const rows = data ?? [];
  const userIds = [...new Set(rows.map((row: any) => row.user_id).filter(Boolean))];
  const profileById = new Map<string, any>();
  if (userIds.length) {
    const result = await supabase.from('profiles').select('id,name,phone').in('id', userIds);
    if (!result.error) (result.data ?? []).forEach((profile: any) => profileById.set(profile.id, profile));
  }
  return rows.map((row: any) => {
    const profile = profileById.get(row.user_id);
    return {
      id: Number(row.id), orderId: Number(row.order_id), userId: row.user_id, reason: row.reason,
      description: row.description ?? null, evidencePath: row.evidence_path ?? null, status: row.status,
      ownerResponse: row.owner_response ?? null, createdAt: row.created_at,
      orderTrackingCode: row.order?.tracking_code ?? null, userName: profile?.name ?? null, userPhone: profile?.phone ?? null,
    };
  });
}

export async function resolveDispute(id: number, status: 'under_review' | 'resolved' | 'rejected', response?: string | null) {
  const { data, error } = await supabase.rpc('dawai_owner_resolve_dispute_v28', {
    p_dispute_id: id,
    p_status: status,
    p_response: response?.trim() || null,
  });
  if (error) throw error;
  return data;
}

export async function submitProductReport(input: {
  pharmacyId: number; medicationId: number; orderId?: number | null; reason: string; details?: string | null; evidenceFile?: File | null;
}): Promise<void> {
  const { data: auth, error: authError } = await supabase.auth.getUser();
  if (authError) throw authError;
  if (!auth.user) throw new Error('يجب تسجيل الدخول');
  let evidencePath: string | null = null;
  if (input.evidenceFile) {
    const safeName = input.evidenceFile.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    evidencePath = `${auth.user.id}/${input.medicationId}/${Date.now()}-${safeName}`;
    const { error: uploadError } = await supabase.storage.from('product-report-evidence').upload(evidencePath, input.evidenceFile, {
      contentType: input.evidenceFile.type || undefined,
      upsert: false,
    });
    if (uploadError) throw uploadError;
  }
  const { error } = await supabase.from('product_reports').insert({
    user_id: auth.user.id,
    pharmacy_id: input.pharmacyId,
    medication_id: input.medicationId,
    order_id: input.orderId ?? null,
    reason: input.reason,
    details: input.details?.trim() || null,
    evidence_path: evidencePath,
  });
  if (error) throw error;
}

export async function getProductReportEvidenceSignedUrl(filePath: string) {
  const { data, error } = await supabase.storage.from('product-report-evidence').createSignedUrl(filePath, 300);
  if (error) throw error;
  return data.signedUrl;
}

export async function fetchOwnerProductReports(): Promise<ProductReport[]> {
  const { data, error } = await supabase.from('product_reports')
    .select('*,medication:medications(name),pharmacy:pharmacies(name)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  const rows = data ?? [];
  const userIds = [...new Set(rows.map((row: any) => row.user_id).filter(Boolean))];
  const profileById = new Map<string, any>();
  if (userIds.length) {
    const result = await supabase.from('profiles').select('id,name').in('id', userIds);
    if (!result.error) (result.data ?? []).forEach((profile: any) => profileById.set(profile.id, profile));
  }
  return rows.map((row: any) => ({
    id: Number(row.id), userId: row.user_id, pharmacyId: Number(row.pharmacy_id), medicationId: Number(row.medication_id),
    orderId: row.order_id == null ? null : Number(row.order_id), reason: row.reason, details: row.details ?? null,
    evidencePath: row.evidence_path ?? null, status: row.status, ownerNotes: row.owner_notes ?? null, createdAt: row.created_at,
    medicationName: row.medication?.name ?? null, pharmacyName: row.pharmacy?.name ?? null, userName: profileById.get(row.user_id)?.name ?? null,
  }));
}

export async function moderateProductReport(id: number, status: 'under_review' | 'resolved' | 'dismissed', notes?: string | null) {
  const { data, error } = await supabase.rpc('dawai_owner_moderate_product_report_v28', {
    p_report_id: id,
    p_status: status,
    p_notes: notes?.trim() || null,
  });
  if (error) throw error;
  return data;
}

export async function submitRating(input: {
  orderId: number; rating: number; speedRating?: number | null; packagingRating?: number | null; matchRating?: number | null; comment?: string | null;
}) {
  const { data, error } = await supabase.rpc('dawai_submit_rating_v28', {
    p_order_id: input.orderId,
    p_rating: input.rating,
    p_speed_rating: input.speedRating ?? null,
    p_packaging_rating: input.packagingRating ?? null,
    p_match_rating: input.matchRating ?? null,
    p_comment: input.comment?.trim() || null,
  });
  if (error) throw error;
  return data;
}

export async function fetchOrderRating(orderId: number): Promise<ProductRating | null> {
  const { data, error } = await supabase.from('product_ratings').select('*').eq('order_id', orderId).maybeSingle();
  if (error) throw error;
  if (!data) return null;
  return {
    id: Number(data.id), orderId: Number(data.order_id), userId: data.user_id, pharmacyId: Number(data.pharmacy_id),
    medicationId: data.medication_id == null ? null : Number(data.medication_id), rating: Number(data.rating),
    speedRating: data.speed_rating == null ? null : Number(data.speed_rating), packagingRating: data.packaging_rating == null ? null : Number(data.packaging_rating),
    matchRating: data.match_rating == null ? null : Number(data.match_rating), comment: data.comment ?? null,
    status: data.status, createdAt: data.created_at,
  };
}

export async function fetchOwnerRatings(): Promise<ProductRating[]> {
  const { data, error } = await supabase.from('product_ratings')
    .select('*,pharmacy:pharmacies(name),medication:medications(name)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  const rows = data ?? [];
  const userIds = [...new Set(rows.map((row: any) => row.user_id).filter(Boolean))];
  const profileById = new Map<string, any>();
  if (userIds.length) {
    const result = await supabase.from('profiles').select('id,name').in('id', userIds);
    if (!result.error) (result.data ?? []).forEach((profile: any) => profileById.set(profile.id, profile));
  }
  return rows.map((row: any) => ({
    id: Number(row.id), orderId: Number(row.order_id), userId: row.user_id, pharmacyId: Number(row.pharmacy_id),
    medicationId: row.medication_id == null ? null : Number(row.medication_id), rating: Number(row.rating),
    speedRating: row.speed_rating == null ? null : Number(row.speed_rating), packagingRating: row.packaging_rating == null ? null : Number(row.packaging_rating),
    matchRating: row.match_rating == null ? null : Number(row.match_rating), comment: row.comment ?? null,
    status: row.status, createdAt: row.created_at, userName: profileById.get(row.user_id)?.name ?? null,
    pharmacyName: row.pharmacy?.name ?? null, medicationName: row.medication?.name ?? null,
  }));
}

export async function moderateRating(id: number, status: 'published' | 'hidden') {
  const { data, error } = await supabase.rpc('dawai_owner_moderate_rating_v28', { p_rating_id: id, p_status: status });
  if (error) throw error;
  return data;
}

export async function fetchOwnerAuditLogs(): Promise<OwnerAuditLog[]> {
  const { data, error } = await supabase.from('owner_audit_logs').select('*').order('created_at', { ascending: false }).limit(200);
  if (error) throw error;
  const rows = data ?? [];
  const ownerIds = [...new Set(rows.map((row: any) => row.owner_id).filter(Boolean))];
  const profileById = new Map<string, any>();
  if (ownerIds.length) {
    const result = await supabase.from('profiles').select('id,name').in('id', ownerIds);
    if (!result.error) (result.data ?? []).forEach((profile: any) => profileById.set(profile.id, profile));
  }
  return rows.map((row: any) => ({
    id: Number(row.id), action: row.action, targetType: row.target_type ?? null, targetId: row.target_id ?? null,
    details: row.details ?? null, actorName: profileById.get(row.owner_id)?.name ?? null, createdAt: row.created_at,
  }));
}

export async function generateLicenseExpiryAlerts() {
  const { data, error } = await supabase.rpc('dawai_generate_license_expiry_alerts_v28');
  if (error) throw error;
  return Number(data ?? 0);
}

export async function markAllNotificationsRead() {
  const { error } = await supabase.rpc('dawai_mark_all_notifications_read_v28');
  if (error) throw error;
}
