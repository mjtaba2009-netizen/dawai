import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// OneSignal warns against duplicate SDK initialization under React StrictMode in development.
ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
