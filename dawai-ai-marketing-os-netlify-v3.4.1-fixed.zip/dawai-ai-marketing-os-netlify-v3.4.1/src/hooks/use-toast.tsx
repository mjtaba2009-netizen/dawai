import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

export interface ToastInput {
  title: string;
  description?: string;
  variant?: 'default' | 'destructive';
  duration?: number;
}

interface ToastRecord extends ToastInput { id: number }
interface ToastContextValue {
  toasts: ToastRecord[];
  toast: (input: ToastInput) => void;
  dismiss: (id: number) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);
let nextId = 1;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastRecord[]>([]);
  const dismiss = useCallback((id: number) => setToasts((items) => items.filter((item) => item.id !== id)), []);
  const toast = useCallback((input: ToastInput) => {
    const id = nextId++;
    setToasts((items) => [...items, { ...input, id }]);
    window.setTimeout(() => dismiss(id), input.duration ?? 4200);
  }, [dismiss]);
  const value = useMemo(() => ({ toasts, toast, dismiss }), [toasts, toast, dismiss]);
  return <ToastContext.Provider value={value}>{children}</ToastContext.Provider>;
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used inside ToastProvider');
  return context;
}
