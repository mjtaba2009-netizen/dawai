import { BellRing, CheckCircle2, Info, Loader2, ShieldAlert, Smartphone } from 'lucide-react';
import { useState } from 'react';
import { usePushNotifications } from '@/contexts/PushNotificationsContext';
import { diagnosticsAsText, repairPushInstallation, sendPushTest } from '@/services/push';

export function PushNotificationsCard({ compact = false }: { compact?: boolean }) {
  const push = usePushNotifications();
  const [testing, setTesting] = useState(false);
  const [testMessage, setTestMessage] = useState<string | null>(null);
  const [diagnosticMessage, setDiagnosticMessage] = useState<string | null>(null);
  const [diagnosticText, setDiagnosticText] = useState<string | null>(null);
  const [repairing, setRepairing] = useState(false);
  const enabled = push.permission === 'granted' && push.optedIn && push.preferences.pushEnabled;

  const statusText = push.loading
    ? 'جاري فحص الجهاز...'
    : push.iosInstallRequired
      ? 'ثبّت المنصة على الشاشة الرئيسية أولاً'
      : push.error && !push.initialized
        ? 'تعذّر الاتصال بخدمة الإشعارات مؤقتًا'
        : !push.supported
          ? 'الإشعارات غير مدعومة في هذا المتصفح'
        : push.permission === 'denied'
          ? 'الإشعارات محظورة من إعدادات الجهاز'
          : enabled
            ? 'الإشعارات الفورية مفعّلة'
            : 'فعّل الإشعارات حتى تصلك تحديثات الطلبات';

  return (
    <section className={`relative overflow-hidden border rounded-3xl ${enabled ? 'bg-gradient-to-br from-emerald-950 via-teal-900 to-teal-700 border-teal-500/30 text-white' : 'bg-white border-slate-100 text-slate-900'} ${compact ? 'p-4' : 'p-5 shadow-sm'}`}>
      <span className="absolute -top-12 -left-12 w-32 h-32 rounded-full bg-amber-300/10 blur-2xl" />
      <div className="relative flex items-start gap-3">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${enabled ? 'bg-white/15' : 'bg-teal-50'}`}>
          {push.loading ? <Loader2 className="w-6 h-6 animate-spin text-teal-500" /> : enabled ? <CheckCircle2 className="w-6 h-6 text-emerald-300" /> : push.permission === 'denied' ? <ShieldAlert className="w-6 h-6 text-red-500" /> : <BellRing className="w-6 h-6 text-teal-600" />}
        </div>
        <div className="flex-1 text-right">
          <h3 className="font-black text-sm">إشعارات دوائي الفورية</h3>
          <p className={`text-xs leading-5 mt-1 ${enabled ? 'text-teal-50/80' : 'text-slate-500'}`}>{statusText}</p>
          {push.error && (
            <div className="mt-2 rounded-xl bg-red-50 px-3 py-2">
              <p className="text-[11px] leading-5 text-red-500">{push.error}</p>
              <div className="mt-1 flex flex-wrap justify-end gap-3">
                <button
                  type="button"
                  onClick={() => void (push.permission === 'granted' ? push.refresh() : push.enable())}
                  className="text-[11px] font-black text-teal-700 underline underline-offset-2"
                >
                  إعادة المحاولة
                </button>
                <button
                  type="button"
                  onClick={() => void (async () => {
                    try {
                      const text = await diagnosticsAsText();
                      setDiagnosticText(text);
                      if (navigator.share) {
                        await navigator.share({ title: 'فحص إشعارات دوائي', text }).catch(() => undefined);
                        setDiagnosticMessage('تم فتح مشاركة تفاصيل الفحص');
                      } else {
                        const textarea = document.createElement('textarea');
                        textarea.value = text;
                        textarea.style.position = 'fixed';
                        textarea.style.opacity = '0';
                        document.body.appendChild(textarea);
                        textarea.select();
                        const copied = document.execCommand('copy');
                        textarea.remove();
                        setDiagnosticMessage(copied ? 'تم نسخ تفاصيل الفحص' : 'تم عرض تفاصيل الفحص بالأسفل');
                      }
                    } catch {
                      setDiagnosticMessage('تعذر تجهيز تفاصيل الفحص');
                    }
                    window.setTimeout(() => setDiagnosticMessage(null), 3000);
                  })()}
                  className="text-[11px] font-black text-slate-600 underline underline-offset-2"
                >
                  مشاركة تفاصيل الفحص
                </button>
                <button
                  type="button"
                  disabled={repairing}
                  onClick={() => void (async () => {
                    setRepairing(true);
                    setDiagnosticMessage('جاري تنظيف تسجيل الإشعارات القديم...');
                    try {
                      await repairPushInstallation();
                      location.reload();
                    } catch {
                      setDiagnosticMessage('تعذر إصلاح التسجيل تلقائيًا');
                      setRepairing(false);
                    }
                  })()}
                  className="text-[11px] font-black text-red-600 underline underline-offset-2 disabled:opacity-50"
                >
                  {repairing ? 'جاري الإصلاح...' : 'إصلاح الإشعارات'}
                </button>
              </div>
              {diagnosticMessage && <p className="mt-1 text-[10px] text-slate-500">{diagnosticMessage}</p>}
              {diagnosticText && (
                <details className="mt-2 text-right">
                  <summary className="cursor-pointer text-[10px] font-bold text-slate-600">عرض تفاصيل الفحص</summary>
                  <pre dir="ltr" className="mt-2 max-h-44 overflow-auto whitespace-pre-wrap break-all rounded-xl bg-slate-950 p-2 text-left text-[9px] leading-4 text-emerald-200 select-text">{diagnosticText}</pre>
                </details>
              )}
            </div>
          )}
          {push.iosInstallRequired && (
            <div className={`mt-3 flex items-start gap-2 rounded-2xl px-3 py-2.5 text-[11px] leading-5 ${enabled ? 'bg-white/10 text-white/85' : 'bg-blue-50 text-blue-700'}`}>
              <Smartphone className="w-4 h-4 shrink-0 mt-0.5" />
              <span>من Safari اضغط مشاركة ← إضافة إلى الشاشة الرئيسية، ثم افتح دوائي من الأيقونة واضغط تفعيل.</span>
            </div>
          )}
          {!push.iosInstallRequired && push.permission === 'denied' && (
            <div className="mt-3 flex items-start gap-2 rounded-2xl bg-amber-50 text-amber-700 px-3 py-2.5 text-[11px] leading-5">
              <Info className="w-4 h-4 shrink-0 mt-0.5" />
              <span>افتح إعدادات الجهاز ← الإشعارات ← Safari أو دوائي، ثم اسمح بالإشعارات.</span>
            </div>
          )}
        </div>
      </div>
      {!push.loading && push.supported && !push.iosInstallRequired && push.permission !== 'denied' && (
        <div className="relative mt-4 grid gap-2">
          <button
            type="button"
            disabled={push.busy}
            onClick={() => void (enabled ? push.disable() : push.enable())}
            className={`w-full h-11 rounded-2xl font-black text-xs disabled:opacity-50 ${enabled ? 'bg-white/12 border border-white/20 text-white' : 'bg-gradient-to-l from-teal-600 to-emerald-500 text-white shadow-lg shadow-teal-500/20'}`}
          >
            {push.busy ? 'جاري التنفيذ...' : enabled ? 'إيقاف الإشعارات على هذا الجهاز' : 'تفعيل الإشعارات الآن'}
          </button>
          {enabled && (
            <button
              type="button"
              disabled={testing}
              onClick={() => void (async () => {
                setTesting(true); setTestMessage(null);
                try { await sendPushTest(); setTestMessage('تم إرسال الاختبار، انتظر عدة ثوانٍ.'); }
                catch (error) { setTestMessage(error instanceof Error ? error.message : 'تعذّر إرسال الاختبار'); }
                finally { setTesting(false); }
              })()}
              className="w-full h-10 rounded-2xl bg-amber-300 text-slate-950 font-black text-xs disabled:opacity-50"
            >
              {testing ? 'جاري إرسال الاختبار...' : 'إرسال إشعار تجريبي'}
            </button>
          )}
          {testMessage && <p className={`text-[11px] text-center ${enabled ? 'text-white/80' : 'text-slate-500'}`}>{testMessage}</p>}
        </div>
      )}
    </section>
  );
}
