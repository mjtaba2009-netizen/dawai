import { useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Camera, Upload, AlertTriangle, CheckCircle, Calendar, Loader2, ShieldCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { uploadPrescription } from '@/services/api';
import { prepareProductImage } from '@/lib/image';
import type { PrescriptionSubmission } from '@/services/types';
import { getErrorMessage } from '@/lib/error';

interface PrescriptionModalProps {
  medicationName: string;
  onConfirm: (prescription: PrescriptionSubmission) => void | Promise<void>;
  onClose: () => void;
  submitLabel?: string;
}

const validatePrescriptionDate = (selectedDateStr: string): string => {
  if (!selectedDateStr) return 'يرجى إدخال تاريخ الوصفة';
  const selectedDate = new Date(`${selectedDateStr}T12:00:00`);
  const currentDate = new Date();
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(currentDate.getMonth() - 6);
  if (Number.isNaN(selectedDate.getTime())) return 'تاريخ الوصفة غير صالح';
  if (selectedDate > currentDate) return 'لا يمكن أن يكون تاريخ الوصفة في المستقبل';
  if (selectedDate < sixMonthsAgo) return 'الوصفة منتهية الصلاحية لأنها أقدم من 6 أشهر';
  return '';
};

export function PrescriptionModal({ medicationName, onConfirm, onClose, submitLabel = 'رفع الوصفة وتأكيد الطلب' }: PrescriptionModalProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [prescriptionDate, setPrescriptionDate] = useState('');
  const [dateError, setDateError] = useState('');
  const [isPreparing, setIsPreparing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const today = useMemo(() => new Date().toISOString().split('T')[0], []);
  const sixMonthsAgoStr = useMemo(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 6);
    return d.toISOString().split('T')[0];
  }, []);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0];
    event.target.value = '';
    if (!selected) return;
    setIsPreparing(true);
    try {
      const prepared = await prepareProductImage(selected);
      setFile(selected);
      setImagePreview(prepared);
    } catch (error) {
      toast({ title: 'تعذّر تجهيز الصورة', description: getErrorMessage(error), variant: 'destructive' });
    } finally {
      setIsPreparing(false);
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!file) {
      toast({ title: 'الوصفة الطبية مطلوبة', description: 'ارفع صورة واضحة للوصفة أولاً', variant: 'destructive' });
      return;
    }
    const errorMessage = validatePrescriptionDate(prescriptionDate);
    setDateError(errorMessage);
    if (errorMessage) return;

    setIsSubmitting(true);
    try {
      const prescription = await uploadPrescription(file, prescriptionDate);
      await onConfirm(prescription);
      toast({ title: 'تم رفع الوصفة بأمان', description: 'سيتمكن المتجر من مراجعتها مع الطلب' });
    } catch (error) {
      toast({
        title: 'تعذّر رفع الوصفة',
        description: getErrorMessage(error, 'تأكد من تشغيل SQL الإصدار 2.7 ثم حاول مرة أخرى'),
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-[90] flex items-end justify-center bg-black/45 backdrop-blur-sm"
        onClick={(event) => event.target === event.currentTarget && !isSubmitting && onClose()}
      >
        <motion.div
          initial={{ y: '100%', opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: '100%', opacity: 0 }}
          transition={{ type: 'spring', damping: 28, stiffness: 300 }}
          className="w-full max-w-[430px] overflow-hidden rounded-t-[30px] bg-white shadow-2xl"
          dir="rtl"
        >
          <div className="relative overflow-hidden bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 px-5 pt-5 pb-6">
            <div className="absolute -left-12 -top-16 w-40 h-40 rounded-full bg-white/15 blur-2xl" />
            <div className="relative flex items-center justify-between mb-3">
              <button type="button" onClick={onClose} disabled={isSubmitting} className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center disabled:opacity-50">
                <X className="w-4 h-4 text-white" />
              </button>
              <div className="w-11 h-11 rounded-2xl bg-white/20 border border-white/30 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-white" />
              </div>
            </div>
            <h2 className="relative text-white font-extrabold text-lg">وصفة طبية مطلوبة</h2>
            <p className="relative text-orange-50 text-sm mt-1">دواء <strong>{medicationName}</strong> يحتاج وصفة سارية وواضحة</p>
          </div>

          <form onSubmit={handleSubmit} className="px-5 py-5 space-y-5 max-h-[72vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom)+20px)]">
            <div>
              <p className="text-slate-700 font-bold text-sm mb-2">صورة الوصفة <span className="text-red-500">*</span></p>
              {imagePreview ? (
                <div className="relative rounded-2xl overflow-hidden border-2 border-teal-400 shadow-sm">
                  <img src={imagePreview} alt="معاينة الوصفة" className="w-full h-44 object-cover" />
                  <span className="absolute top-2 left-2 w-8 h-8 rounded-xl bg-teal-500 text-white flex items-center justify-center"><CheckCircle className="w-4 h-4" /></span>
                  <button type="button" onClick={() => { setFile(null); setImagePreview(null); }} className="absolute top-2 right-2 w-8 h-8 rounded-xl bg-red-500 text-white flex items-center justify-center"><X className="w-4 h-4" /></button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => { fileInputRef.current?.removeAttribute('capture'); fileInputRef.current?.click(); }} className="h-28 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 text-slate-500 flex flex-col items-center justify-center gap-2">
                    {isPreparing ? <Loader2 className="w-6 h-6 animate-spin" /> : <Upload className="w-6 h-6" />}<span className="text-xs font-bold">من الصور</span>
                  </button>
                  <button type="button" onClick={() => { fileInputRef.current?.setAttribute('capture', 'environment'); fileInputRef.current?.click(); }} className="h-28 rounded-2xl border-2 border-dashed border-teal-200 bg-teal-50/60 text-teal-700 flex flex-col items-center justify-center gap-2">
                    <Camera className="w-6 h-6" /><span className="text-xs font-bold">التقاط صورة</span>
                  </button>
                </div>
              )}
              <input ref={fileInputRef} type="file" accept="image/*,.heic,.heif" className="hidden" onChange={handleFileChange} />
            </div>

            <div>
              <label className="text-slate-700 font-bold text-sm mb-2 flex items-center gap-1.5"><Calendar className="w-4 h-4 text-teal-500" />تاريخ الوصفة <span className="text-red-500">*</span></label>
              <input
                type="date" value={prescriptionDate} max={today} min={sixMonthsAgoStr}
                onChange={(event) => { setPrescriptionDate(event.target.value); setDateError(validatePrescriptionDate(event.target.value)); }}
                className={`w-full h-12 px-4 rounded-xl border bg-slate-50 outline-none ${dateError ? 'border-red-400' : 'border-slate-200 focus:border-teal-400'}`}
              />
              {dateError ? <p className="mt-2 text-xs text-red-600 flex gap-1.5"><AlertTriangle className="w-3.5 h-3.5" />{dateError}</p> : <p className="mt-2 text-xs text-slate-400">يجب ألا يتجاوز عمر الوصفة 6 أشهر.</p>}
            </div>

            <div className="rounded-2xl bg-teal-50 border border-teal-100 p-3 text-xs text-teal-800 leading-5">
              تُحفظ الوصفة بشكل خاص ولا تظهر إلا لك وللمتجر المسؤول عن الطلب.
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button type="button" onClick={onClose} disabled={isSubmitting} className="h-12 rounded-xl bg-slate-100 text-slate-700 font-bold disabled:opacity-50">إلغاء</button>
              <motion.button whileTap={{ scale: 0.97 }} type="submit" disabled={isSubmitting || isPreparing} className="h-12 rounded-xl bg-gradient-to-r from-teal-500 to-teal-600 text-white font-extrabold flex items-center justify-center gap-2 disabled:opacity-50">
                {isSubmitting ? <><Loader2 className="w-4 h-4 animate-spin" />جاري الرفع...</> : submitLabel}
              </motion.button>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
