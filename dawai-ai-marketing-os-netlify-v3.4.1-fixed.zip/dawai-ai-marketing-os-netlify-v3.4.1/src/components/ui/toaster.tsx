import { X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function Toaster() {
  const { toasts, dismiss } = useToast();
  return (
    <div className="fixed z-[300] top-[calc(env(safe-area-inset-top)+12px)] inset-x-3 flex flex-col gap-2 pointer-events-none max-w-md mx-auto">
      {toasts.map((toast) => (
        <div key={toast.id} className={`pointer-events-auto rounded-2xl border p-4 shadow-2xl backdrop-blur-xl ${toast.variant === 'destructive' ? 'bg-red-50/95 border-red-200 text-red-900' : 'bg-white/95 border-white text-slate-900'}`}>
          <div className="flex items-start gap-3">
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm">{toast.title}</p>
              {toast.description && <p className="text-xs opacity-75 mt-1 leading-relaxed break-words">{toast.description}</p>}
            </div>
            <button onClick={() => dismiss(toast.id)} className="w-7 h-7 rounded-lg bg-black/5 flex items-center justify-center"><X className="w-4 h-4" /></button>
          </div>
        </div>
      ))}
    </div>
  );
}
