import { Clock3, LogOut, ShieldX } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

export function VendorStatusGate() {
  const { user, logout } = useAuth();
  const rejected = user?.status === 'rejected';
  return (
    <div className="min-h-[100dvh] flex items-center justify-center p-6 bg-gradient-to-br from-slate-950 via-teal-950 to-slate-950" dir="rtl">
      <div className="w-full max-w-sm rounded-[32px] bg-white/95 border border-white p-7 text-center shadow-2xl">
        <div className={`w-20 h-20 rounded-3xl mx-auto mb-5 flex items-center justify-center ${rejected ? 'bg-red-50 text-red-500' : 'bg-amber-50 text-amber-600'}`}>
          {rejected ? <ShieldX className="w-10 h-10" /> : <Clock3 className="w-10 h-10" />}
        </div>
        <h1 className="text-xl font-black text-slate-900">{rejected ? 'تم رفض طلب الانضمام' : 'طلبك قيد مراجعة الإدارة'}</h1>
        <p className="text-sm text-slate-500 leading-relaxed mt-3">
          {rejected
            ? 'راجع بيانات المتجر وتواصل مع إدارة منصة دوائي لمعرفة سبب الرفض أو إعادة التقديم.'
            : 'سيظهر لك إشعار فور موافقة مالك المنصة. لا تحتاج لإغلاق التطبيق؛ الحالة تتحدث تلقائياً.'}
        </p>
        <button onClick={logout} className="mt-6 w-full h-12 rounded-2xl bg-slate-100 text-slate-700 font-bold flex items-center justify-center gap-2">
          <LogOut className="w-4 h-4" /> تسجيل الخروج
        </button>
      </div>
    </div>
  );
}
