/**
 * ═══════════════════════════════════════════════════════════════════
 *  Dawai_Intro_Premium_V2 — الانترو السينمائي الرسمي
 * ═══════════════════════════════════════════════════════════════════
 *  السرد (تحوّل واحد متصل، لا مشاهد منفصلة):
 *  إشارة حياة (ECG) ← بذرة ضوء ← شبكة صيدليات ذكية ← مسار توصيل
 *  ← ضوء يسافر بسرعة ← وصول وعناية ← اللوغو الرسمي.
 *
 *  اللوغو: أصول Logo_Master_DoNotEdit فقط (الأيقونة الرسمية + مسارات
 *  «دوائي» الفيكتور الأصلية). التأثيرات (توهّج/لمعة) طبقات مؤقتة فوقه.
 *
 *  AUDIO PLACEHOLDERS (مواضع المزامنة الصوتية):
 *    Audio_Heartbeat      @ T.beat      نبضة عميقة واحدة
 *    Audio_TechRise       @ T.network   صعود تقني ناعم
 *    Audio_RouteActivate  @ T.route     تفعيل المسار
 *    Audio_Whoosh         @ T.delivery  انطلاق التوصيل
 *    Audio_Confirm        @ T.arrival   نغمة تأكيد راقية
 *    Audio_LogoImpact     @ T.logo      لمسة سينمائية مضبوطة
 * ═══════════════════════════════════════════════════════════════════
 */
import { useEffect } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { WordmarkAR, OfficialAppIcon } from "../brand/LogoMaster";

/* ─── Global Controls (قابلة للتحرير) ─────────────────────────── */
const BRAND = {
  teal: "#12B3A6",
  teal2: "#0FA294",
  deep: "#0A6A63",
  amber: "#FFB454",
  mist: "#F2FBFA",
  bg0: "#08302f",
  bg1: "#04191b",
  bg2: "#010a0b",
};
const CTRL = {
  glow: 1,            // شدة التوهّج (0.5–1.5)
  particles: 10,      // عدد الجزيئات
  logoScale: 1,       // مقياس اللوغو النهائي
  taglineSize: "1.05rem",
};
/* الخط الزمني (ثوانٍ) — عدّل هنا لضبط الإيقاع كاملاً */
const T = {
  beat: 0.15,      // S1 إشارة الحياة
  seed: 0.95,      // S2 التحوّل لبذرة ضوء
  network: 1.55,   // S3 الشبكة الذكية
  route: 2.35,     //     تفعيل المسار
  delivery: 2.95,  // S4 رحلة التوصيل
  arrival: 4.35,   // S5 الوصول والعناية
  logo: 5.25,      // S6 اللوغو البطل
  word: 5.7,       //     كلمة دوائي
  tagline: 6.15,   //     السطر
  // App unmount @ 7.1s + خروج 0.8s = ~7.9s
};

const GRAIN =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='140' height='140' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")";

const EASE_OUT: [number, number, number, number] = [0.16, 1, 0.3, 1];
const EASE_CAM: [number, number, number, number] = [0.3, 0, 0.2, 1];

/* ─── BG_DeepTeal ──────────────────────────────────────────────── */
function BG_DeepTeal() {
  return (
    <>
      <div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(120% 90% at 50% 58%, ${BRAND.bg0} 0%, ${BRAND.bg1} 55%, ${BRAND.bg2} 100%)`,
        }}
      />
      {/* نبضة بيئية متزامنة مع النبضة الرئيسية */}
      <motion.div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(80% 60% at 50% 55%, ${BRAND.deep}33 0%, transparent 70%)`,
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.9, 0.15] }}
        transition={{ duration: 0.9, delay: T.beat + 0.35, times: [0, 0.3, 1], ease: "easeOut" }}
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ backgroundImage: GRAIN, opacity: 0.05, mixBlendMode: "overlay" }}
      />
      {/* Vignette سينمائي */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(120% 120% at 50% 50%, transparent 55%, rgba(0,0,0,0.55) 100%)" }}
      />
    </>
  );
}

/* ─── Particles_Subtle ─────────────────────────────────────────── */
function Particles_Subtle() {
  const dots = Array.from({ length: CTRL.particles }, (_, i) => ({
    left: `${(i * 71 + 9) % 100}%`,
    top: `${18 + ((i * 37) % 60)}%`,
    s: 1.5 + (i % 3),
    amber: i % 5 === 0,
    d: (i % 6) * 0.5,
    dur: 7 + (i % 4) * 1.5,
  }));
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {dots.map((p, i) => (
        <motion.span
          key={i}
          className="absolute rounded-full"
          style={{
            left: p.left, top: p.top, width: p.s, height: p.s,
            background: p.amber ? BRAND.amber : BRAND.teal,
            boxShadow: `0 0 ${6 * CTRL.glow}px ${p.amber ? BRAND.amber : BRAND.teal}`,
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.5, 0.15, 0.5, 0], y: -60 }}
          transition={{ duration: p.dur, delay: p.d, repeat: Infinity, ease: "linear" }}
        />
      ))}
    </div>
  );
}

/* ─── S1+S2: ECG_MainPath → Seed ──────────────────────────────── */
function ECG_MainPath() {
  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
      initial={{ opacity: 1 }}
      animate={{ opacity: 0 }}
      transition={{ delay: T.seed + 0.45, duration: 0.25 }}
    >
      <svg width="min(78vw, 560px)" viewBox="0 0 560 120" fill="none" style={{ overflow: "visible" }}>
        {/* AUDIO_CUE: Audio_Heartbeat @ الذروة */}
        <motion.path
          d="M0 60 H210 L232 60 L246 30 L262 88 L276 60 H560"
          stroke={BRAND.amber}
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ filter: `drop-shadow(0 0 ${8 * CTRL.glow}px ${BRAND.amber}) drop-shadow(0 0 ${26 * CTRL.glow}px rgba(255,180,84,0.35))` }}
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ pathLength: { duration: 0.85, delay: T.beat, ease: [0.4, 0, 0.2, 1] }, opacity: { duration: 0.2, delay: T.beat } }}
        />
        {/* S2: الخط ينكمش نحو المركز ويتكثّف إلى بذرة ضوء */}
        <motion.path
          d="M0 60 H210 L232 60 L246 30 L262 88 L276 60 H560"
          stroke={BRAND.mist}
          strokeWidth="2.4"
          strokeLinecap="round"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: [0, 1], opacity: [0, 0.9, 0] }}
          transition={{ duration: 0.5, delay: T.seed, ease: "easeIn", times: [0, 0.7, 1] }}
        />
      </svg>
      {/* بذرة الضوء */}
      <motion.span
        className="absolute rounded-full"
        style={{
          width: 10, height: 10,
          background: `radial-gradient(circle, #fff 0%, ${BRAND.amber} 45%, ${BRAND.teal} 100%)`,
          boxShadow: `0 0 ${18 * CTRL.glow}px ${BRAND.amber}, 0 0 ${44 * CTRL.glow}px ${BRAND.teal}66`,
        }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 1.5, 1], opacity: [0, 1, 1] }}
        transition={{ duration: 0.45, delay: T.seed + 0.3, ease: EASE_OUT }}
      />
    </motion.div>
  );
}

/* ─── S3+S4+S5: Map_Network + Route + Delivery + Arrival ─────── */
function Map_Network() {
  // عقد الصيدليات (إحداثيات داخل viewBox 800×420)
  const nodes = [
    { x: 150, y: 120 }, { x: 300, y: 78 }, { x: 470, y: 132 },
    { x: 205, y: 265 }, { x: 388, y: 228 }, { x: 585, y: 96 },
  ];
  const nearest = { x: 205, y: 265 };       // الصيدلية الأقرب
  const dest = { x: 648, y: 300 };          // وجهة الزبون
  const routeD = `M ${nearest.x} ${nearest.y} C 300 330, 430 190, 520 235 S 620 320, ${dest.x} ${dest.y}`;

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: [0, 1, 1, 0] }}
      transition={{ duration: T.logo - T.network + 0.15, delay: T.network, times: [0, 0.12, 0.86, 1], ease: "easeInOut" }}
    >
      {/* AUDIO_CUE: Audio_TechRise @ T.network */}
      <motion.svg
        width="min(96vw, 760px)"
        viewBox="0 0 800 420"
        fill="none"
        style={{ overflow: "visible", transform: "perspective(900px) rotateX(14deg)" }}
        initial={{ scale: 0.92, y: 12 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ duration: 1.1, delay: T.network, ease: EASE_CAM }}
      >
        {/* شبكة أرضية خفيفة (عمق) */}
        <g opacity="0.14" stroke={BRAND.teal} strokeWidth="0.6">
          {Array.from({ length: 9 }, (_, i) => (
            <line key={"h" + i} x1="0" y1={40 + i * 42} x2="800" y2={40 + i * 42} />
          ))}
          {Array.from({ length: 13 }, (_, i) => (
            <line key={"v" + i} x1={40 + i * 60} y1="0" x2={40 + i * 60} y2="420" />
          ))}
        </g>

        {/* وصلات بين العقد */}
        <g stroke={BRAND.teal} strokeWidth="1" opacity="0.28">
          <motion.path d="M150 120 L300 78 L470 132 L585 96 M300 78 L388 228 M150 120 L205 265 M388 228 L470 132"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
            transition={{ duration: 0.7, delay: T.network + 0.15, ease: "easeOut" }} />
        </g>

        {/* Pharmacy_Nodes — تتفعّل تباعاً */}
        {nodes.map((n, i) => (
          <motion.g key={i}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: T.network + 0.2 + i * 0.08, ease: EASE_OUT }}
            style={{ originX: `${n.x}px`, originY: `${n.y}px` }}
          >
            <circle cx={n.x} cy={n.y} r="5" fill={BRAND.teal}
              style={{ filter: `drop-shadow(0 0 ${6 * CTRL.glow}px ${BRAND.teal})` }} />
            <circle cx={n.x} cy={n.y} r="9" stroke={BRAND.teal} strokeWidth="1" opacity="0.4" fill="none" />
          </motion.g>
        ))}

        {/* الصيدلية الأقرب — تمييز عنبري */}
        {/* AUDIO_CUE: Audio_RouteActivate @ T.route */}
        <motion.circle cx={nearest.x} cy={nearest.y} r="14" stroke={BRAND.amber} strokeWidth="1.6" fill="none"
          initial={{ opacity: 0, scale: 0.4 }}
          animate={{ opacity: [0, 1, 0.65], scale: [0.4, 1.15, 1] }}
          transition={{ duration: 0.5, delay: T.route, ease: EASE_OUT }}
          style={{ originX: `${nearest.x}px`, originY: `${nearest.y}px`, filter: `drop-shadow(0 0 ${8 * CTRL.glow}px ${BRAND.amber})` }}
        />

        {/* Destination_Marker — بيت الزبون */}
        <motion.g
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: T.route + 0.15, ease: EASE_OUT }}
        >
          <path d={`M ${dest.x - 13} ${dest.y + 4} v -12 l 13 -11 l 13 11 v 12 h -9 v -9 h -8 v 9 Z`}
            stroke={BRAND.mist} strokeWidth="1.6" fill="none" strokeLinejoin="round" opacity="0.9" />
        </motion.g>

        {/* Route_Main — المسار يُرسم من الصيدلية للوجهة */}
        <motion.path d={routeD}
          stroke={BRAND.amber} strokeWidth="2" strokeLinecap="round" fill="none"
          strokeDasharray="1 0"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.9 }}
          transition={{ pathLength: { duration: 0.55, delay: T.route + 0.1, ease: [0.4, 0, 0.2, 1] }, opacity: { duration: 0.2, delay: T.route + 0.1 } }}
          style={{ filter: `drop-shadow(0 0 ${6 * CTRL.glow}px rgba(255,180,84,0.7))` }}
        />

        {/* Delivery_Object — ضوء التوصيل يسافر المسار (offset-path) */}
        {/* AUDIO_CUE: Audio_Whoosh @ T.delivery */}
        {[0, 0.05, 0.1, 0.16].map((lag, i) => (
          <motion.circle key={i} cx={205} cy={265} r={i === 0 ? 6 : 5 - i} fill={i === 0 ? "#fff" : BRAND.amber}
            style={{
              offsetPath: `path("${routeD}")`,
              filter: i === 0 ? `drop-shadow(0 0 ${12 * CTRL.glow}px ${BRAND.amber}) drop-shadow(0 0 30px rgba(255,180,84,0.5))` : "blur(1px)",
              opacity: i === 0 ? 1 : 0.5 - i * 0.1,
            } as React.CSSProperties}
            initial={{ offsetDistance: "0%", opacity: 0 } as any}
            animate={{ offsetDistance: "100%", opacity: [0, 1, 1, 0] } as any}
            transition={{ duration: 1.25, delay: T.delivery + lag, ease: [0.45, 0, 0.25, 1], times: [0, 0.08, 0.92, 1] }}
          />
        ))}

        {/* Arrival_Pulse — نبضتا تأكيد راقيتان عند الوجهة */}
        {/* AUDIO_CUE: Audio_Confirm @ T.arrival */}
        {[BRAND.teal, BRAND.amber].map((c, i) => (
          <motion.circle key={c} cx={dest.x} cy={dest.y - 4} r="10" stroke={c} strokeWidth="1.4" fill="none"
            initial={{ opacity: 0, scale: 0.3 }}
            animate={{ opacity: [0, 0.9, 0], scale: [0.3, 3.4] }}
            transition={{ duration: 0.85, delay: T.arrival + i * 0.16, ease: "easeOut" }}
            style={{ originX: `${dest.x}px`, originY: `${dest.y - 4}px` }}
          />
        ))}
        <motion.circle cx={dest.x} cy={dest.y - 4} r="4.5" fill={BRAND.amber}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: [0, 1, 1], scale: [0, 1.4, 1] }}
          transition={{ duration: 0.5, delay: T.arrival, ease: EASE_OUT }}
          style={{ originX: `${dest.x}px`, originY: `${dest.y - 4}px`, filter: `drop-shadow(0 0 ${10 * CTRL.glow}px ${BRAND.amber})` }}
        />
      </motion.svg>
    </motion.div>
  );
}

/* ─── S6: Final_Logo + Tagline_AR ─────────────────────────────── */
function Final_Logo() {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: T.logo - 0.1, duration: 0.3 }}
    >
      {/* تجمّع الضوء — وميض مضبوط (لا انفجار) */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 420, height: 420,
          background: `radial-gradient(circle, ${BRAND.mist}cc 0%, ${BRAND.teal}55 35%, transparent 70%)`,
          filter: "blur(30px)",
        }}
        initial={{ opacity: 0, scale: 0.2 }}
        animate={{ opacity: [0, 0.9, 0], scale: [0.2, 1.1, 1.5] }}
        transition={{ duration: 0.7, delay: T.logo - 0.12, times: [0, 0.4, 1], ease: "easeOut" }}
      />
      {/* هالة تنفّس هادئة خلف اللوغو */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 560, height: 560,
          background: `radial-gradient(circle, ${BRAND.teal}40 0%, ${BRAND.deep}22 40%, transparent 70%)`,
          filter: "blur(90px)",
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0.25, 0.4, 0.3, 0.4] }}
        transition={{ duration: 3.2, delay: T.logo, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
      />

      <div className="relative flex flex-col items-center" dir="rtl" style={{ scale: CTRL.logoScale }}>
        {/* AUDIO_CUE: Audio_LogoImpact @ T.logo */}
        {/* الأيقونة الرسمية — blur-to-focus واستقرار واثق بلا دوران */}
        <motion.div
          initial={{ opacity: 0, scale: 1.14, filter: "blur(14px)" }}
          animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
          transition={{ duration: 0.75, delay: T.logo, ease: EASE_OUT }}
          className="relative"
          style={{ filter: `drop-shadow(0 18px 50px rgba(10,106,99,0.5))` }}
        >
          <OfficialAppIcon size={116} />
          {/* لمعة ضوئية مؤقتة تعبر الأيقونة (طبقة فوق الأصل، لا تعديل عليه) */}
          <motion.div
            className="absolute inset-0 pointer-events-none"
            style={{
              borderRadius: 116 * 0.24,
              background: "linear-gradient(115deg, transparent 30%, rgba(255,255,255,0.5) 48%, rgba(255,255,255,0.12) 52%, transparent 68%)",
              backgroundSize: "260% 100%",
            }}
            initial={{ backgroundPosition: "220% 0", opacity: 0 }}
            animate={{ backgroundPosition: "-120% 0", opacity: [0, 1, 0] }}
            transition={{ duration: 0.9, delay: T.word + 0.35, ease: "easeInOut", times: [0, 0.5, 1] }}
          />
        </motion.div>

        {/* كلمة «دوائي» — المسارات الأصلية، كشف بقناع صاعد + blur-to-focus */}
        <motion.div
          className="mt-6 overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2, delay: T.word }}
        >
          <motion.div
            initial={{ y: "60%", filter: "blur(8px)", opacity: 0 }}
            animate={{ y: "0%", filter: "blur(0px)", opacity: 1 }}
            transition={{ duration: 0.7, delay: T.word, ease: EASE_OUT }}
            style={{ filter: `drop-shadow(0 0 40px rgba(18,179,166,0.35))` }}
          >
            <WordmarkAR width={196} color={BRAND.mist} />
          </motion.div>
        </motion.div>

        {/* فاصل رفيع */}
        <motion.div
          className="mt-5 h-px"
          style={{ background: `linear-gradient(to right, transparent, ${BRAND.teal}, transparent)` }}
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 150, opacity: 0.8 }}
          transition={{ duration: 0.55, delay: T.tagline - 0.1, ease: EASE_OUT }}
        />

        {/* Tagline_AR — السطر الرسمي بالضبط */}
        <motion.p
          className="mt-4 select-none"
          dir="rtl"
          style={{
            fontFamily: "'Cairo', sans-serif",
            fontWeight: 600,
            fontSize: CTRL.taglineSize,
            color: "rgba(242,251,250,0.94)",
            letterSpacing: "0.06em",
          }}
          initial={{ opacity: 0, y: 10, filter: "blur(6px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ duration: 0.6, delay: T.tagline, ease: EASE_OUT }}
        >
          دواؤك… يوصل لباب بيتك
        </motion.p>
      </div>

      <motion.p
        className="absolute bottom-8 text-[10px] select-none"
        style={{ color: "rgba(148,163,184,0.5)", letterSpacing: "0.2em" }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: T.tagline + 0.25 }}
      >
        Powered by Promptify IQ
      </motion.p>
    </motion.div>
  );
}

/* ─── المكوّن الرئيسي ─────────────────────────────────────────── */
export function DawaiIntroPremiumV2() {
  useEffect(() => {
    document.getElementById("pre-splash")?.remove();
  }, []);

  const reduced = useReducedMotion();

  return (
    <motion.div
      key="splash"
      className="fixed inset-0 z-[9999] overflow-hidden"
      style={{ background: BRAND.bg2 }}
      exit={{ opacity: 0, transition: { duration: 0.8, ease: [0.4, 0, 0.2, 1] } }}
    >
      {/* Camera_Main — دفع سينمائي بطيء متصل */}
      <motion.div
        className="absolute inset-0"
        initial={{ scale: 1 }}
        animate={{ scale: reduced ? 1 : 1.035 }}
        transition={{ duration: 7, ease: "linear" }}
      >
        <BG_DeepTeal />
        {!reduced && <Particles_Subtle />}
        {!reduced && <ECG_MainPath />}
        {!reduced && <Map_Network />}
        <Final_Logo />
      </motion.div>
    </motion.div>
  );
}
