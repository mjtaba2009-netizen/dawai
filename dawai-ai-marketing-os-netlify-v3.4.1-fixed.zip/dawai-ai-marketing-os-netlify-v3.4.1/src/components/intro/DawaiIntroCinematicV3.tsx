/**
 * ═══════════════════════════════════════════════════════════════════
 *  Dawai_Intro_Cinematic_V3 — "من نبضة… إلى باب البيت"
 * ═══════════════════════════════════════════════════════════════════
 *  S1 نبضة ECG واحدة قوية ← S2 الخط يتحوّل إلى علامة «+» الرسمية
 *  (الكبسولة الأفقية تحتضن النبض — تشريح اللوغو الحقيقي) مع زوم كاميرا
 *  وانتشار ضوء ذهبي ← S3 خريطة مدينة مستقبلية: طلب يظهر، أقرب صيدلية
 *  تتفعّل ← S4/S5 راكب توصيل سيلويت فاخر، كاميرا تتبع، موشن بلر،
 *  ذيول ضوئية، البيت يتوهّج ← S6 وصول: كبسولة دواء متوهّجة فوق الطرد،
 *  توهّج ذهبي مضبوط ← S7 اللقطة البطلة: اللوغو الرسمي + انعكاس زجاجي
 *  + «دواؤك... يوصل لباب بيتك» ← تلاشٍ سينمائي للأسود.
 *
 *  اللوغو: أصول Logo_Master_DoNotEdit فقط — بلا تعديل.
 *  AUDIO CUES: Heartbeat@0.55 · Whoosh@1.05 · LightSweep@1.5 ·
 *  TechRise@2.1 · RouteTone@2.75 · EngineWhoosh@3.35 · DeepBass@5.9 ·
 *  LuxuryTone@6.35 · AmbientTail@7.2
 * ═══════════════════════════════════════════════════════════════════
 */
import { useEffect } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { WordmarkAR, OfficialAppIcon } from "../brand/LogoMaster";
import { ShieldCheck, Zap, Lock, HeartPulse } from "lucide-react";

const B = {
  teal: "#12B3A6", teal2: "#0FA294", deep: "#0A6A63",
  amber: "#FFB454", mist: "#F2FBFA",
  bg0: "#07292a", bg1: "#031517", bg2: "#000505",
};

/* الخط الزمني — عدّل الإيقاع كله من هنا */
const T = {
  ecg: 0.12, beat: 0.55,
  morph: 1.0, plusV: 1.32, zoom: 1.05, bloom: 1.4,
  map: 2.0, ping: 2.3, pharm: 2.6, route: 2.8,
  ride: 3.35, house: 4.75,
  arrive: 5.15, pill: 5.45, flash: 5.95,
  hero: 6.1, word: 6.45, tag: 6.7, badges: 7.0,
  black: 8.25, // fade to black — App unmount @8.55s
};
const EO: [number, number, number, number] = [0.16, 1, 0.3, 1];
const CAM: [number, number, number, number] = [0.3, 0, 0.15, 1];

/** مدة الانترو الكاملة حتى تظهر لقطة الشعار الختامية بوضوح. */
export const DAWAI_INTRO_DURATION_MS = 9000;

const GRAIN =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='140' height='140' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")";

/* ── S1+S2: النبضة تتحوّل إلى «+» الرسمية ─────────────────────── */
function ECG_To_Plus() {
  return (
    <motion.div
      className="absolute inset-0 grid place-items-center pointer-events-none"
      style={{ transformStyle: "preserve-3d" }}
      initial={{ opacity: 1, scale: 1 }}
      animate={{ opacity: [1, 1, 0], scale: [1, 1, 0.6] }}
      transition={{ delay: T.map - 0.05, duration: 0.4, times: [0, 0.4, 1], ease: "easeIn" }}
    >
      {/* زوم الكاميرا السريع ثم الاستقرار */}
      <motion.div
        className="relative grid place-items-center"
        style={{ transformStyle: "preserve-3d" }}
        initial={{ scale: 1, rotateX: 16, z: -70 }}
        animate={{ scale: [1, 1.16, 1], rotateX: [16, 4, 0], z: [-70, 26, 0] }}
        transition={{ duration: 1.05, delay: T.zoom, times: [0, 0.45, 1], ease: CAM }}
      >
        {/* انتشار الضوء الذهبي */}
        <motion.div
          className="absolute rounded-full"
          style={{ width: 380, height: 380, background: `radial-gradient(circle, ${B.amber}55 0%, ${B.amber}18 40%, transparent 70%)` }}
          initial={{ opacity: 0, scale: 0.3 }}
          animate={{ opacity: [0, 1, 0.35], scale: [0.3, 1.25, 1.6] }}
          transition={{ duration: 0.9, delay: T.bloom, times: [0, 0.45, 1], ease: "easeOut" }}
        />
        <svg width="min(80vw, 460px)" viewBox="-230 -115 460 230" style={{ overflow: "visible" }}>
          {/* AUDIO: Heartbeat @T.beat */}
          <motion.path
            d="M -230 0 H -62 L -40 0 L -26 -34 L -8 40 L 4 0 H 230"
            stroke={B.amber} strokeWidth="2.6" fill="none" strokeLinecap="round" strokeLinejoin="round"
            style={{ filter: `drop-shadow(0 0 9px ${B.amber}))` }}
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: [0, 1, 1, 0] }}
            transition={{
              pathLength: { duration: 0.8, delay: T.ecg, ease: [0.4, 0, 0.2, 1] },
              opacity: { duration: T.morph - T.ecg + 0.25, delay: T.ecg, times: [0, 0.15, 0.85, 1] },
            }}
          />
          {/* هالة ذهبية ناعمة خلف العلامة — تتنفّس */}
          <motion.circle cx="0" cy="0" r="62" fill="url(#v3disc)"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.6, 0.45, 0.6] }}
            transition={{ duration: 2.2, delay: T.morph, times: [0, 0.35, 0.7, 1], ease: "easeInOut" }} />

          {/* مدار متقطّع يدور ببطء — متمركز تماماً */}
          <motion.g
            style={{ originX: 0.5, originY: 0.5 }}
            initial={{ rotate: 0, opacity: 0 }}
            animate={{ rotate: -50, opacity: 0.32 }}
            transition={{ rotate: { duration: 3.4, ease: "linear" }, opacity: { duration: 0.5, delay: T.plusV } }}>
            <circle cx="0" cy="0" r="118" fill="none" stroke={B.amber} strokeWidth="0.9" strokeDasharray="2 9" strokeLinecap="round" />
          </motion.g>

          {/* الحلقة الرئيسية — تُرسم حول العلامة بتدرّج ذهبي وتُختم بنقطة */}
          <motion.g style={{ originX: 0.5, originY: 0.5 }} initial={{ rotate: -90 }} animate={{ rotate: -90 }}>
            <motion.circle cx="0" cy="0" r="100" fill="none" stroke="url(#v3goldRing)" strokeWidth="1.4" strokeLinecap="round"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.9 }}
              transition={{ pathLength: { duration: 0.7, delay: T.plusV - 0.12, ease: [0.4, 0, 0.2, 1] }, opacity: { duration: 0.2, delay: T.plusV - 0.12 } }}
              style={{ filter: "drop-shadow(0 0 5px rgba(255,180,84,0.5))" }} />
          </motion.g>
          <motion.circle cx="0" cy="-100" r="2.6" fill={B.amber}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: [0, 1, 0.85], scale: [0, 1.5, 1] }}
            transition={{ duration: 0.4, delay: T.plusV + 0.55 }}
            style={{ originX: 0.5, originY: 0.5, filter: `drop-shadow(0 0 7px ${B.amber})` }} />

          {/* نبضتا اتّساع — متمركزتان (تحريك نصف القطر لا التكبير) */}
          {[0, 0.16].map((lag, i) => (
            <motion.circle key={"pulse" + i} cx="0" cy="0" fill="none" stroke={B.amber} strokeWidth={1.1 - i * 0.3}
              initial={{ r: 74, opacity: 0 }}
              animate={{ r: 150 + i * 18, opacity: [0, 0.55, 0] }}
              transition={{ duration: 0.85, delay: T.plusV + lag, ease: "easeOut" }} />
          ))}

          {/* علامات شعاعية قصيرة خارج الحلقة — تُضاء بالتتابع */}
          {Array.from({ length: 8 }, (_, i) => (
            <motion.line key={"tick" + i} x1="0" y1="-126" x2="0" y2="-140"
              stroke={B.amber} strokeWidth="1.4" strokeLinecap="round"
              transform={`rotate(${i * 45})`}
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 0.75, 0.3] }}
              transition={{ duration: 0.5, delay: T.bloom + 0.05 + i * 0.045, ease: "easeOut" }} />
          ))}
          {/* AUDIO: Whoosh @T.morph — الكبسولة الأفقية تولد من الخط نفسه */}
          <motion.rect x="-72" y="-22" width="144" height="44" rx="22" fill="url(#v3gold)" stroke="#ffe9b8" strokeWidth="0.9" strokeOpacity="0.7"
            initial={{ scaleY: 0.06, scaleX: 1.6, opacity: 0 }}
            animate={{ scaleY: [0.06, 1.06, 1], scaleX: [1.6, 0.99, 1], opacity: 1 }}
            transition={{ duration: 0.55, delay: T.morph, ease: EO, times: [0, 0.72, 1] }}
            style={{ originX: 0.5, originY: 0.5 }}
          />
          {/* الكبسولة العمودية */}
          <motion.rect x="-22" y="-72" width="44" height="144" rx="22" fill="url(#v3gold)" stroke="#ffe9b8" strokeWidth="0.9" strokeOpacity="0.7"
            initial={{ scaleY: 0, opacity: 0 }}
            animate={{ scaleY: [0, 1.07, 1], opacity: 1 }}
            transition={{ duration: 0.5, delay: T.plusV, ease: EO, times: [0, 0.72, 1] }}
            style={{ originX: 0.5, originY: 0.5 }}
          />
          {/* نبض اللوغو داخل الكبسولة — استمرارية مباشرة من الـ ECG */}
          <motion.path
            d="M -54 0 H -16 L -9 -11 L 0 14 L 6 0 H 54"
            stroke={B.mist} strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"
            style={{ filter: "drop-shadow(0 0 5px rgba(255,255,255,0.75))" }}
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 0.45, delay: T.morph + 0.22, ease: [0.4, 0, 0.2, 1] }}
          />
          {/* AUDIO: LightSweep @1.5 — لمعة تعبر داخل العلامة فقط */}
          <g clipPath="url(#v3plusClip)">
            <g transform="skewX(-18)">
              <motion.rect x="-20" y="-100" width="40" height="200" fill="url(#v3sweep)"
                initial={{ x: -140, opacity: 0 }}
                animate={{ x: 140, opacity: [0, 1, 0] }}
                transition={{ duration: 0.6, delay: T.bloom + 0.12, ease: "easeInOut" }}
              />
            </g>
          </g>
          <defs>
            <clipPath id="v3plusClip">
              <rect x="-72" y="-22" width="144" height="44" rx="22" />
              <rect x="-22" y="-72" width="44" height="144" rx="22" />
            </clipPath>
            <linearGradient id="v3goldRing" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#ffe6b0" />
              <stop offset="0.5" stopColor={B.amber} />
              <stop offset="1" stopColor="#d99a2b" />
            </linearGradient>
            <radialGradient id="v3disc">
              <stop offset="0" stopColor={B.amber} stopOpacity="0.5" />
              <stop offset="0.7" stopColor={B.amber} stopOpacity="0.14" />
              <stop offset="1" stopColor={B.amber} stopOpacity="0" />
            </radialGradient>
            <linearGradient id="v3gold" x1="0" y1="0" x2="0.9" y2="1">
              <stop offset="0" stopColor="#ffdf9a" />
              <stop offset="0.55" stopColor="#f3b64e" />
              <stop offset="1" stopColor="#d99a2b" />
            </linearGradient>
            <linearGradient id="v3sweep" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stopColor="#fff" stopOpacity="0" />
              <stop offset="0.5" stopColor="#fff" stopOpacity="0.55" />
              <stop offset="1" stopColor="#fff" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </motion.div>
    </motion.div>
  );
}

/* ── راكب التوصيل — سيلويت فاخر بإضاءة حافة ───────────────────── */
function Rider_Silhouette() {
  return (
    <g>
      {/* ذيول ضوئية */}
      {[0, 1, 2].map((i) => (
        <motion.line key={i} x1={-118 - i * 26} y1={-14 + i * 10} x2={-58 - i * 20} y2={-14 + i * 10}
          stroke={i === 1 ? B.amber : B.teal} strokeWidth={2.5 - i * 0.5} strokeLinecap="round"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.8, 0], x: [-8, -30] }}
          transition={{ duration: 0.38, delay: T.ride + 0.1 + i * 0.1, repeat: 4, ease: "easeOut" }}
        />
      ))}
      {/* أشباح موشن بلر */}
      {[10, 20].map((off, i) => (
        <g key={off} opacity={0.18 - i * 0.06} transform={`translate(${-off},0)`}>
          <RiderBody rim={false} />
        </g>
      ))}
      <RiderBody rim />
    </g>
  );
}
function RiderBody({ rim }: { rim: boolean }) {
  const fill = "#0c3634";
  const rimC = rim ? B.teal : "none";
  return (
    <g>
      <ellipse cx="0" cy="26" rx="52" ry="4" fill="#000" opacity="0.5" />
      {/* عجلتان */}
      <circle cx="-30" cy="16" r="13" fill={fill} stroke={rimC} strokeWidth="1.4" />
      <circle cx="32" cy="16" r="13" fill={fill} stroke={rimC} strokeWidth="1.4" />
      <circle cx="-30" cy="16" r="4" fill={B.teal} opacity="0.9" />
      <circle cx="32" cy="16" r="4" fill={B.teal} opacity="0.9" />
      {/* جسم الدراجة + الراكب — كتلة سيلويت واحدة أنيقة */}
      <path d="M -34 8 Q -22 2 -10 4 L 6 6 Q 18 4 26 8 L 34 12 L 30 2 Q 22 -6 8 -6 L 2 -6 Q -2 -26 -14 -32 Q -20 -35 -24 -32 Q -16 -26 -12 -14 L -14 -6 Q -28 -4 -34 8 Z"
        fill={fill} stroke={rimC} strokeWidth="1.2" strokeLinejoin="round" />
      {/* خوذة بلمعة */}
      <circle cx="-17" cy="-33" r="7.5" fill={fill} stroke={rimC} strokeWidth="1.2" />
      {rim && <path d="M -22 -36 A 7.5 7.5 0 0 1 -13 -39" stroke={B.mist} strokeWidth="1.4" fill="none" strokeLinecap="round" opacity="0.8" />}
      {/* صندوق دوائي خلفي بعلامة + */}
      <rect x="-52" y="-20" width="22" height="20" rx="5" fill={B.teal2} stroke={rim ? B.mist : "none"} strokeWidth="0.8" />
      <rect x="-44.5" y="-16" width="7" height="12" rx="1.5" fill={B.mist} />
      <rect x="-47" y="-13.5" width="12" height="7" rx="1.5" fill={B.mist} />
      {/* ضوء أمامي + شعاع */}
      <circle cx="36" cy="4" r="3.4" fill="#ffe9c4" style={{ filter: `drop-shadow(0 0 8px ${B.amber})` }} />
      <polygon points="39,2 96,-8 96,16" fill={B.amber} opacity="0.16" />
    </g>
  );
}

/* ── S3–S6: الخريطة + الرحلة + الوصول ─────────────────────────── */
function City_Journey() {
  const nodes = [
    { x: 160, y: 120 }, { x: 320, y: 84 }, { x: 505, y: 128 },
    { x: 232, y: 236 }, { x: 430, y: 208 }, { x: 640, y: 100 },
  ];
  const pharm = { x: 232, y: 236 };
  const dest = { x: 700, y: 292 };
  const routeD = `M ${pharm.x} ${pharm.y} C 340 320, 480 210, 560 244 S 660 316, ${dest.x} ${dest.y}`;

  return (
    <motion.div
      className="absolute inset-0 grid place-items-center pointer-events-none"
      style={{ transformStyle: "preserve-3d" }}
      initial={{ opacity: 0 }}
      animate={{ opacity: [0, 1, 1, 0] }}
      transition={{ duration: T.flash - T.map + 0.25, delay: T.map, times: [0, 0.1, 0.9, 1] }}
    >
      {/* AUDIO: TechRise @T.map · كاميرا تتبع: المشهد ينزاح يسار مع الرحلة */}
      {/* أرضية 3D — شبكة تنحسر للأفق بضباب مسافة، تتحرك مع الرحلة */}
      <motion.div
        className="absolute pointer-events-none"
        style={{
          width: "190%", height: "64%", left: "-45%", top: "46%",
          transformOrigin: "50% 0%",
          transform: "rotateX(63deg) translateZ(-70px)",
          backgroundImage: `repeating-linear-gradient(to right, ${B.teal}24 0 1px, transparent 1px 64px), repeating-linear-gradient(to bottom, ${B.teal}1a 0 1px, transparent 1px 54px)`,
          maskImage: "linear-gradient(to bottom, transparent 0%, black 24%, black 76%, transparent 100%)",
          WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 24%, black 76%, transparent 100%)",
          opacity: 0.55,
        }}
        initial={{ x: 0 }}
        animate={{ x: [0, 0, -280, -280] }}
        transition={{ duration: T.arrive - T.map + 0.5, delay: T.map, times: [0, 0.32, 0.78, 1], ease: CAM }}
      />
      <motion.div
        style={{ transformStyle: "preserve-3d" }}
        initial={{ rotateX: 24, z: -50 }}
        animate={{ rotateX: [24, 12, 11, 9], rotateY: [0, 0, -2.4, 1.4], z: [-50, 0, 0, 30] }}
        transition={{ duration: T.arrive - T.map + 0.5, delay: T.map, times: [0, 0.32, 0.78, 1], ease: CAM }}
      >
      <motion.svg
        width="min(120vw, 900px)" viewBox="0 0 840 400" fill="none"
        style={{ overflow: "visible" }}
        initial={{ x: 40, scale: 0.94 }}
        animate={{ x: [40, 40, -46, -46], scale: [0.94, 1, 1, 1.02] }}
        transition={{ duration: T.arrive - T.map + 0.5, delay: T.map, times: [0, 0.32, 0.78, 1], ease: CAM }}
      >
        {/* طبقة الشبكة — بارالاكس أبطأ */}
        <motion.g opacity="0.13" stroke={B.teal} strokeWidth="0.6"
          initial={{ x: 0 }} animate={{ x: [0, 0, 26] }}
          transition={{ duration: T.arrive - T.map + 0.5, delay: T.map, times: [0, 0.35, 1], ease: CAM }}>
          {Array.from({ length: 8 }, (_, i) => <line key={"h"+i} x1="-80" y1={36 + i * 46} x2="920" y2={36 + i * 46} />)}
          {Array.from({ length: 16 }, (_, i) => <line key={"v"+i} x1={-60 + i * 62} y1="0" x2={-60 + i * 62} y2="400" />)}
        </motion.g>

        {/* بنايات سيلويت خفيفة (عمق) */}
        <g opacity="0.32">
          {[[60,150,58],[150,110,44],[360,140,66],[470,96,40],[560,150,52],[760,120,60]].map(([x,h,w],i)=>(
            <rect key={i} x={x} y={330-(h as number)} width={w} height={h} rx="3" fill="#0a2f2e" />
          ))}
        </g>
        <line x1="-80" y1="330" x2="920" y2="330" stroke="#0d3a38" strokeWidth="2" />

        {/* العقد */}
        {nodes.map((n, i) => (
          <motion.g key={i} initial={{ opacity: 0, scale: 0.4, y: -10 }} animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.4, delay: T.map + 0.15 + i * 0.07, ease: EO }}
            style={{ originX: 0.5, originY: 0.5 }}>
            {/* دبوس موقع مضيء (لقطة 03) */}
            <path
              d={`M ${n.x} ${n.y - 16} C ${n.x + 7} ${n.y - 16} ${n.x + 10} ${n.y - 10} ${n.x + 10} ${n.y - 6} C ${n.x + 10} ${n.y} ${n.x} ${n.y + 8} ${n.x} ${n.y + 8} C ${n.x} ${n.y + 8} ${n.x - 10} ${n.y} ${n.x - 10} ${n.y - 6} C ${n.x - 10} ${n.y - 10} ${n.x - 7} ${n.y - 16} ${n.x} ${n.y - 16} Z`}
              fill={B.teal} style={{ filter: `drop-shadow(0 0 7px ${B.teal})` }} />
            <circle cx={n.x} cy={n.y - 6.5} r="3" fill={B.mist} />
          </motion.g>
        ))}

        {/* مبنى الصيدلية الأقرب — بصليب مضيء (لقطة 03) */}
        <motion.g initial={{ opacity: 0, scale: 0.6, y: 6 }} animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.45, delay: T.pharm - 0.05, ease: EO }}
          style={{ originX: 0.5, originY: 0.5 }}>
          <rect x={pharm.x - 16} y={pharm.y - 6} width="32" height="22" rx="2.5" fill="#0a3a37" stroke={B.mist} strokeWidth="0.9" opacity="0.95" />
          <rect x={pharm.x - 3.5} y={pharm.y + 6} width="7" height="10" rx="1" fill="#08302d" stroke={B.mist} strokeWidth="0.6" />
          <rect x={pharm.x - 2.6} y={pharm.y - 16} width="5.2" height="13" rx="1.4" fill={B.teal}
            style={{ filter: `drop-shadow(0 0 6px ${B.teal})` }} />
          <rect x={pharm.x - 6.5} y={pharm.y - 12.1} width="13" height="5.2" rx="1.4" fill={B.teal}
            style={{ filter: `drop-shadow(0 0 6px ${B.teal})` }} />
        </motion.g>

        {/* طلب توصيل يظهر عند البيت */}
        <motion.circle cx={dest.x} cy={dest.y - 26} r="7" stroke={B.mist} strokeWidth="1.4" fill="none"
          initial={{ opacity: 0, scale: 0.3 }} animate={{ opacity: [0, 1, 0], scale: [0.3, 2.6] }}
          transition={{ duration: 0.7, delay: T.ping, ease: "easeOut" }}
          style={{ originX: 0.5, originY: 0.5 }} />

        {/* أقرب صيدلية تتفعّل */}
        <motion.circle cx={pharm.x} cy={pharm.y} r="13" stroke={B.amber} strokeWidth="1.6" fill="none"
          initial={{ opacity: 0, scale: 0.4 }} animate={{ opacity: [0, 1, 0.6], scale: [0.4, 1.15, 1] }}
          transition={{ duration: 0.5, delay: T.pharm, ease: EO }}
          style={{ originX: 0.5, originY: 0.5, filter: `drop-shadow(0 0 8px ${B.amber})` }} />

        {/* AUDIO: RouteTone @T.route */}
        <motion.path d={routeD} stroke={B.amber} strokeWidth="2.2" strokeLinecap="round" fill="none" strokeDasharray="7 6"
          initial={{ pathLength: 0, opacity: 0 }} animate={{ pathLength: 1, opacity: 0.85 }}
          transition={{ pathLength: { duration: 0.5, delay: T.route, ease: [0.4, 0, 0.2, 1] }, opacity: { duration: 0.2, delay: T.route } }}
          style={{ filter: "drop-shadow(0 0 6px rgba(255,180,84,0.6))" }} />

        {/* البيت — يتوهّج عند الاقتراب */}
        <motion.g initial={{ opacity: 0.75 }} animate={{ opacity: 1 }} transition={{ delay: T.house, duration: 0.3 }}>
          <motion.path d={`M ${dest.x - 16} ${dest.y + 6} v -15 l 16 -13 l 16 13 v 15 h -11 v -11 h -10 v 11 Z`}
            stroke={B.mist} strokeWidth="1.8" fill="none" strokeLinejoin="round"
            initial={{ filter: "drop-shadow(0 0 0px transparent)" }}
            animate={{ filter: [`drop-shadow(0 0 0px transparent)`, `drop-shadow(0 0 12px ${B.amber})`] }}
            transition={{ delay: T.house, duration: 0.4 }} />
        </motion.g>

        {/* دبوس فوق منزل العميل (لقطة 05) */}
        <motion.g initial={{ opacity: 0, y: -14, scale: 0.5 }}
          animate={{ opacity: [0, 1, 1], y: [-14, 2, 0], scale: [0.5, 1.08, 1] }}
          transition={{ duration: 0.5, delay: T.house + 0.1, ease: EO, times: [0, 0.7, 1] }}
          style={{ originX: 0.5, originY: 0.5 }}>
          <path d={`M ${dest.x} ${dest.y - 48} C ${dest.x + 6.5} ${dest.y - 48} ${dest.x + 9.5} ${dest.y - 42.5} ${dest.x + 9.5} ${dest.y - 39} C ${dest.x + 9.5} ${dest.y - 33.5} ${dest.x} ${dest.y - 26} ${dest.x} ${dest.y - 26} C ${dest.x} ${dest.y - 26} ${dest.x - 9.5} ${dest.y - 33.5} ${dest.x - 9.5} ${dest.y - 39} C ${dest.x - 9.5} ${dest.y - 42.5} ${dest.x - 6.5} ${dest.y - 48} ${dest.x} ${dest.y - 48} Z`}
            fill={B.teal} style={{ filter: `drop-shadow(0 0 8px ${B.teal})` }} />
          <circle cx={dest.x} cy={dest.y - 39.5} r="2.8" fill={B.mist} />
        </motion.g>

        {/* AUDIO: EngineWhoosh @T.ride — الراكب يقطع المدينة بتسارع/تباطؤ سينمائي */}
        <motion.g
          initial={{ x: pharm.x - 40, y: pharm.y + 24, opacity: 0, scale: 0.9 }}
          animate={{
            x: [pharm.x - 40, 380, 560, dest.x - 58],
            y: [pharm.y + 24, 300, 288, dest.y + 8],
            opacity: [0, 1, 1, 1],
            scale: [0.9, 1, 1, 0.97],
          }}
          transition={{ duration: T.arrive - T.ride + 0.35, delay: T.ride, times: [0, 0.42, 0.75, 1], ease: [0.45, 0, 0.18, 1] }}
        >
          <Rider_Silhouette />
        </motion.g>

        {/* حقيبة دوائي الطبية عند الباب (لقطة 06) */}
        <motion.g initial={{ opacity: 0, y: 6, scale: 0.7 }} animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.45, delay: T.arrive + 0.05, ease: EO }}
          style={{ originX: 0.5, originY: 0.5 }}>
          <path d={`M ${dest.x - 40} ${dest.y - 10} A 6.5 6 0 0 1 ${dest.x - 27} ${dest.y - 10}`}
            stroke={B.teal2} strokeWidth="2" fill="none" />
          <rect x={dest.x - 46} y={dest.y - 10} width="25" height="16" rx="3.5" fill={B.teal2} stroke={B.mist} strokeWidth="0.7" />
          <rect x={dest.x - 35.6} y={dest.y - 7} width="4.2" height="10" rx="1.1" fill={B.mist} />
          <rect x={dest.x - 38.5} y={dest.y - 4.1} width="10" height="4.2" rx="1.1" fill={B.mist} />
        </motion.g>
        {/* هالة ثابتة حول الكبسولة (لقطة 06) */}
        <motion.circle cx={dest.x - 34} cy={dest.y - 27} r="15" stroke={B.amber} strokeWidth="1.1" fill="none"
          initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: [0, 0.75, 0.55], scale: [0.5, 1.06, 1] }}
          transition={{ duration: 0.5, delay: T.pill + 0.1, ease: EO }}
          style={{ originX: 0.5, originY: 0.5, filter: `drop-shadow(0 0 7px ${B.amber})` }} />

        {/* S6: الوصول — كبسولة دواء متوهّجة فوق الطرد */}
        <motion.g initial={{ opacity: 0, y: 8, scale: 0.6 }}
          animate={{ opacity: [0, 1, 1], y: [8, -6, -10], scale: [0.6, 1.1, 1] }}
          transition={{ duration: 0.6, delay: T.pill, ease: EO }}
          style={{ originX: 0.5, originY: 0.5 }}>
          <rect x={dest.x - 44} y={dest.y - 34} width="21" height="10" rx="5" fill={B.mist}
            transform={`rotate(-24 ${dest.x - 34} ${dest.y - 29})`} />
          <rect x={dest.x - 44} y={dest.y - 34} width="10.5" height="10" rx="5" fill={B.amber}
            transform={`rotate(-24 ${dest.x - 34} ${dest.y - 29})`}
            style={{ filter: `drop-shadow(0 0 10px ${B.amber})` }} />
        </motion.g>
        {[B.amber, B.teal].map((c, i) => (
          <motion.circle key={c} cx={dest.x - 34} cy={dest.y - 26} r="9" stroke={c} strokeWidth="1.3" fill="none"
            initial={{ opacity: 0, scale: 0.3 }} animate={{ opacity: [0, 0.85, 0], scale: [0.3, 3.4] }}
            transition={{ duration: 0.8, delay: T.pill + 0.15 + i * 0.14, ease: "easeOut" }}
            style={{ originX: 0.5, originY: 0.5 }} />
        ))}
      </motion.svg>
      </motion.div>
    </motion.div>
  );
}

/* ── S7: اللقطة البطلة ────────────────────────────────────────── */
function Hero_Logo() {
  return (
    <motion.div className="absolute inset-0 flex flex-col items-center justify-center"
      style={{ transformStyle: "preserve-3d" }}
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: T.hero - 0.15, duration: 0.3 }}>
      {/* أشعة الانفجار الضوئي (لقطة 07) */}
      <svg className="absolute pointer-events-none" width="560" height="560" viewBox="-280 -280 560 560" style={{ overflow: "visible" }}>
        {Array.from({ length: 12 }, (_, i) => (
          <motion.line key={i} x1="0" y1="-56" x2="0" y2="-196"
            stroke={i % 3 === 0 ? B.amber : B.teal} strokeWidth={i % 3 === 0 ? 2 : 1.2} strokeLinecap="round"
            transform={`rotate(${i * 30})`}
            initial={{ opacity: 0, scale: 0.4 }}
            animate={{ opacity: [0, 0.85, 0], scale: [0.4, 1.15, 1.3] }}
            transition={{ duration: 0.65, delay: T.flash - 0.08 + (i % 4) * 0.04, ease: "easeOut" }}
            style={{ originX: 0.5, originY: 0.5 }} />
        ))}
      </svg>
      {/* AUDIO: DeepBass @T.flash — تجمّع ذهبي مضبوط */}
      <motion.div className="absolute rounded-full"
        style={{ width: 460, height: 460, background: `radial-gradient(circle, ${B.mist}c8 0%, ${B.amber}44 30%, ${B.teal}30 50%, transparent 72%)` }}
        initial={{ opacity: 0, scale: 0.2 }} animate={{ opacity: [0, 0.95, 0], scale: [0.2, 1.15, 1.6] }}
        transition={{ duration: 0.7, delay: T.flash - 0.1, times: [0, 0.4, 1], ease: "easeOut" }} />
      {/* هالة تنفّس */}
      <motion.div className="absolute rounded-full"
        style={{ width: 600, height: 600, background: `radial-gradient(circle, ${B.teal}38 0%, ${B.deep}1f 40%, transparent 70%)` }}
        initial={{ opacity: 0 }} animate={{ opacity: [0.22, 0.38, 0.28, 0.38] }}
        transition={{ duration: 3.2, delay: T.hero, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }} />

      {/* أرضية جزيئات 3D — لقطة الختام (08) */}
      <motion.div
        className="absolute pointer-events-none"
        style={{
          left: "-30%", right: "-30%", bottom: "-6%", height: "42%",
          transformOrigin: "50% 100%",
          transform: "rotateX(74deg)",
          backgroundImage: `radial-gradient(circle, ${B.teal}70 1px, transparent 1.7px), radial-gradient(circle, ${B.amber}45 1px, transparent 1.6px)`,
          backgroundSize: "36px 30px, 58px 46px",
          backgroundPosition: "0 0, 17px 12px",
          maskImage: "linear-gradient(to top, black 10%, transparent 82%)",
          WebkitMaskImage: "linear-gradient(to top, black 10%, transparent 82%)",
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.55, backgroundPositionY: ["0px, 12px", "44px, 48px"] }}
        transition={{ opacity: { delay: T.hero + 0.15, duration: 0.9 }, backgroundPositionY: { duration: 7, repeat: Infinity, ease: "linear", delay: T.hero } }}
      />

      {/* لوح زجاجي — يدخل من العمق ثم يطفو بلطف في فضاء 3D */}
      <motion.div
        style={{ transformStyle: "preserve-3d" }}
        animate={{ rotateX: [0, 1.2, -1, 0], rotateY: [0, -1.4, 1.2, 0] }}
        transition={{ duration: 7, delay: T.hero + 1.0, repeat: Infinity, ease: "easeInOut" }}
      >
      <motion.div
        className="relative flex flex-col items-center rounded-[32px] px-12 pt-10 pb-9"
        style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.07)", boxShadow: "0 30px 80px -30px rgba(0,0,0,0.7)", transformStyle: "preserve-3d" }}
        dir="rtl"
        initial={{ opacity: 0, scale: 1.05, rotateX: 13, z: -60 }} animate={{ opacity: 1, scale: 1, rotateX: 0, z: 0 }}
        transition={{ duration: 0.85, delay: T.hero, ease: EO }}
      >
        {/* AUDIO: LuxuryTone @T.hero+0.25 — الأيقونة الرسمية + انعكاس */}
        <motion.div className="relative"
          initial={{ opacity: 0, scale: 1.16, z: -30 }}
          animate={{ opacity: 1, scale: 1, z: 26 }}
          transition={{ duration: 0.75, delay: T.hero + 0.05, ease: EO }}
          style={{ filter: "drop-shadow(0 18px 46px rgba(10,106,99,0.55))" }}>
          <OfficialAppIcon size={112} />
          {/* لمعة عابرة (طبقة مؤقتة فوق الأصل) */}
          <motion.div className="absolute inset-0 pointer-events-none"
            style={{ borderRadius: 112 * 0.24, background: "linear-gradient(115deg, transparent 32%, rgba(255,255,255,0.5) 48%, rgba(255,255,255,0.1) 52%, transparent 66%)", backgroundSize: "260% 100%" }}
            initial={{ backgroundPosition: "220% 0", opacity: 0 }}
            animate={{ backgroundPosition: "-120% 0", opacity: [0, 1, 0] }}
            transition={{ duration: 0.9, delay: T.word + 0.3, ease: "easeInOut", times: [0, 0.5, 1] }} />
          {/* انعكاس فاخر */}
          <div className="absolute left-0 right-0" style={{ top: "104%", transform: "scaleY(-1)", opacity: 0.16, maskImage: "linear-gradient(to top, transparent 30%, black 100%)", WebkitMaskImage: "linear-gradient(to top, transparent 30%, black 100%)" }}>
            <OfficialAppIcon size={112} />
          </div>
        </motion.div>

        {/* كلمة «دوائي» الأصلية */}
        <motion.div className="mt-10 overflow-hidden"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2, delay: T.word }}>
          <motion.div initial={{ y: "55%", opacity: 0 }}
            animate={{ y: "0%", opacity: 1 }}
            transition={{ duration: 0.65, delay: T.word, ease: EO }}
            style={{ filter: "drop-shadow(0 0 34px rgba(18,179,166,0.35))" }}>
            <WordmarkAR width={188} color={B.mist} />
          </motion.div>
        </motion.div>

        <motion.div className="mt-5 h-px" style={{ background: `linear-gradient(to right, transparent, ${B.teal}, transparent)` }}
          initial={{ width: 0, opacity: 0 }} animate={{ width: 150, opacity: 0.8 }}
          transition={{ duration: 0.5, delay: T.tag - 0.1, ease: EO }} />

        <motion.p className="mt-4 select-none" dir="rtl"
          style={{ fontFamily: "'Cairo', sans-serif", fontWeight: 600, fontSize: "1.05rem", color: "rgba(242,251,250,0.94)", letterSpacing: "0.05em" }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: T.tag, ease: EO }}>
          دواؤك... يوصل لباب بيتك
        </motion.p>
      </motion.div>
      </motion.div>

      {/* فاصل ذهبي بقلب + شريط الثقة (لقطة الختام) */}
      <motion.div className="mt-6 flex flex-col items-center" dir="rtl"
        initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: T.badges, ease: EO }}>
        <div className="flex items-center gap-2 mb-3.5">
          <span className="h-px w-12" style={{ background: `linear-gradient(to left, transparent, ${B.amber}aa)` }} />
          <HeartPulse size={11} color={B.amber} strokeWidth={2.2} />
          <span className="h-px w-12" style={{ background: `linear-gradient(to right, transparent, ${B.amber}aa)` }} />
        </div>
        <div className="flex items-center">
          {[
            { I: ShieldCheck, l: "موثوق" },
            { I: Zap, l: "سريع" },
            { I: Lock, l: "آمن" },
            { I: HeartPulse, l: "نهتم بك" },
          ].map(({ I, l }, i) => (
            <div key={l} className="flex items-center">
              {i > 0 && <span className="mx-4 h-6 w-px" style={{ background: "rgba(242,251,250,0.14)" }} />}
              <div className="flex flex-col items-center gap-1.5">
                <I size={15} color={B.teal} strokeWidth={2} />
                <span style={{ fontFamily: "'Cairo', sans-serif", fontSize: 10.5, color: "rgba(242,251,250,0.72)" }}>{l}</span>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.p className="absolute bottom-7 text-[10px] select-none"
        style={{ color: "rgba(148,163,184,0.45)", letterSpacing: "0.2em" }}
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: T.tag + 0.25 }}>
        Powered by Promptify IQ
      </motion.p>
    </motion.div>
  );
}

/* ── جزيئات هادئة (المشهد الأخير فقط) ─────────────────────────── */
function Particles_Final() {
  const dots = Array.from({ length: 9 }, (_, i) => ({
    left: `${(i * 79 + 11) % 100}%`, top: `${20 + ((i * 41) % 55)}%`,
    s: 1.5 + (i % 2), amber: i % 4 === 0, d: (i % 5) * 0.5,
  }));
  return (
    <motion.div className="absolute inset-0 overflow-hidden pointer-events-none"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: T.hero, duration: 0.8 }}>
      {dots.map((p, i) => (
        <motion.span key={i} className="absolute rounded-full"
          style={{ left: p.left, top: p.top, width: i % 3 === 0 ? p.s + 1.5 : p.s, height: i % 3 === 0 ? p.s + 1.5 : p.s, background: p.amber ? B.amber : B.teal, opacity: i % 3 === 0 ? 0.7 : 1 }}
          animate={{ opacity: [0, 0.5, 0.15, 0.5, 0], y: -45 }}
          transition={{ duration: 8, delay: p.d, repeat: Infinity, ease: "linear" }} />
      ))}
    </motion.div>
  );
}

/* ── المكوّن الرئيسي ─────────────────────────────────────────── */
export function DawaiIntroCinematicV3() {
  useEffect(() => { document.getElementById("pre-splash")?.remove(); }, []);
  const reduced = useReducedMotion();

  return (
    <motion.div key="splash" className="fixed inset-0 z-[9999] overflow-hidden" style={{ background: B.bg2 }}
      exit={{ opacity: 0, transition: { duration: 0.5, ease: "easeOut" } }}>
      {/* خلفية سينمائية */}
      <div className="absolute inset-0" style={{ background: `radial-gradient(120% 90% at 50% 58%, ${B.bg0} 0%, ${B.bg1} 55%, ${B.bg2} 100%)` }} />
      <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: GRAIN, opacity: 0.035 }} />
      <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(120% 120% at 50% 50%, transparent 55%, rgba(0,0,0,0.6) 100%)" }} />

      {/* Camera_Main — دفع متصل */}
      <motion.div
        className="absolute inset-0"
        style={{ perspective: 1100, transformStyle: "preserve-3d", willChange: "transform" }}
        initial={{ scale: 1, rotateX: 0, rotateY: 0 }}
        animate={reduced ? { scale: 1 } : { scale: [1, 1.02, 1.05, 1.03, 1.03], rotateX: [0, 2.2, 3, 0, 0], rotateY: [0, -1.6, 2.2, 0, 0] }}
        transition={{ duration: 7.4, times: [0, 0.3, 0.62, 0.84, 1], ease: "easeInOut" }}
      >
        {!reduced && <ECG_To_Plus />}
        {!reduced && <City_Journey />}
        <Particles_Final />
        <Hero_Logo />
      </motion.div>

      {/* AUDIO: AmbientTail — تلاشٍ سينمائي للأسود */}
      <motion.div className="absolute inset-0 bg-black pointer-events-none"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        transition={{ delay: T.black, duration: 0.45, ease: "easeIn" }} />
    </motion.div>
  );
}
