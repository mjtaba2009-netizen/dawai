import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, Package, ReceiptText, ShoppingBag, TrendingUp, XCircle } from 'lucide-react';
import type { InventoryItem, KanbanOrder, VendorReport } from '@/services/types';
import { formatIQD } from '@/lib/utils';

function buildReport(orders: KanbanOrder[]): VendorReport {
  const completed = orders.filter((order) => order.status === 'received' || order.status === 'completed');
  const cancelled = orders.filter((order) => ['cancelled', 'rejected', 'timeout'].includes(order.status));
  const active = orders.filter((order) => ['pending', 'confirmed', 'ready'].includes(order.status));
  const byProduct = new Map<string, { quantity: number; revenue: number }>();
  for (const order of completed) {
    const name = order.medication?.name || 'منتج غير معروف';
    const current = byProduct.get(name) || { quantity: 0, revenue: 0 };
    current.quantity += order.quantity;
    current.revenue += order.totalPrice;
    byProduct.set(name, current);
  }
  const topProducts = [...byProduct.entries()]
    .map(([name, value]) => ({ name, ...value }))
    .sort((a, b) => b.quantity - a.quantity || b.revenue - a.revenue)
    .slice(0, 5);
  const grossSales = orders.reduce((sum, order) => sum + order.totalPrice, 0);
  const netSales = completed.reduce((sum, order) => sum + order.totalPrice, 0);
  return {
    totalOrders: orders.length,
    completedOrders: completed.length,
    cancelledOrders: cancelled.length,
    activeOrders: active.length,
    grossSales,
    netSales,
    averageOrder: completed.length ? netSales / completed.length : 0,
    cancellationRate: orders.length ? (cancelled.length / orders.length) * 100 : 0,
    topProducts,
  };
}

function MetricCard({ icon: Icon, label, value, sub, tone }: { icon: typeof Package; label: string; value: string; sub?: string; tone: string }) {
  return <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl bg-white border border-slate-100 p-4 shadow-sm"><div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tone}`}><Icon className="w-5 h-5" /></div><p className="text-xl font-black text-slate-900 mt-3 tabular-nums">{value}</p><p className="text-xs font-bold text-slate-600 mt-1">{label}</p>{sub && <p className="text-[10px] text-slate-400 mt-1">{sub}</p>}</motion.div>;
}

export function PharmacyReports({ orders, inventory }: { orders: KanbanOrder[]; inventory: InventoryItem[] }) {
  const [period, setPeriod] = useState<'7' | '30' | 'all'>('30');
  const filteredOrders = useMemo(() => {
    if (period === 'all') return orders;
    const since = Date.now() - Number(period) * 86_400_000;
    return orders.filter((order) => new Date(order.createdAt).getTime() >= since);
  }, [orders, period]);
  const report = useMemo(() => buildReport(filteredOrders), [filteredOrders]);
  const topMax = Math.max(1, ...report.topProducts.map((product) => product.quantity));
  const lowStock = inventory.filter((item) => item.quantity <= 5).length;

  return (
    <div className="flex-1 overflow-y-auto px-4 pt-4 pb-8 space-y-5" dir="rtl">
      <div className="grid grid-cols-3 gap-1 rounded-2xl bg-white border border-slate-200 p-1">
        {([['7', '7 أيام'], ['30', '30 يوم'], ['all', 'الكل']] as const).map(([key, label]) => <button key={key} onClick={() => setPeriod(key)} className={`h-9 rounded-xl text-xs font-bold ${period === key ? 'bg-teal-500 text-white' : 'text-slate-500'}`}>{label}</button>)}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <MetricCard icon={TrendingUp} label="المبيعات المكتملة" value={formatIQD(report.netSales)} sub={`${report.completedOrders} طلب مكتمل`} tone="bg-teal-50 text-teal-600" />
        <MetricCard icon={ReceiptText} label="متوسط الطلب" value={formatIQD(report.averageOrder)} sub="للطلبات المكتملة" tone="bg-blue-50 text-blue-600" />
        <MetricCard icon={ShoppingBag} label="إجمالي الطلبات" value={String(report.totalOrders)} sub={`${report.activeOrders} طلب نشط`} tone="bg-amber-50 text-amber-600" />
        <MetricCard icon={XCircle} label="الطلبات الملغاة" value={String(report.cancelledOrders)} sub={`${report.cancellationRate.toFixed(1)}% نسبة الإلغاء`} tone="bg-red-50 text-red-600" />
      </div>

      <section className="rounded-3xl bg-white border border-slate-100 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4"><div className="flex items-center gap-2"><BarChart3 className="w-5 h-5 text-teal-600" /><h3 className="font-extrabold text-slate-900">الأكثر طلباً</h3></div><span className="text-[10px] text-slate-400">حسب الكمية</span></div>
        {report.topProducts.length ? <div className="space-y-4">{report.topProducts.map((product, index) => <div key={product.name}><div className="flex items-center justify-between text-xs mb-1.5"><div className="flex items-center gap-2"><span className="w-6 h-6 rounded-lg bg-teal-50 text-teal-700 font-black flex items-center justify-center">{index + 1}</span><span className="font-bold text-slate-700 max-w-[180px] truncate">{product.name}</span></div><span className="text-slate-500">{product.quantity} قطعة</span></div><div className="h-2 rounded-full bg-slate-100 overflow-hidden"><motion.div initial={{ width: 0 }} animate={{ width: `${(product.quantity / topMax) * 100}%` }} className="h-full rounded-full bg-gradient-to-l from-teal-500 to-emerald-400" /></div><p className="text-[10px] text-slate-400 mt-1">مبيعات: {formatIQD(product.revenue)}</p></div>)}</div> : <div className="py-10 text-center text-slate-400 text-sm">لا توجد طلبات مكتملة في هذه الفترة</div>}
      </section>

      <section className="rounded-3xl bg-gradient-to-l from-slate-900 to-teal-950 text-white p-4">
        <div className="flex items-center gap-3"><div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center"><Package className="w-5 h-5 text-amber-300" /></div><div><p className="font-extrabold">مراقبة المخزون</p><p className="text-xs text-slate-300 mt-1">{lowStock ? `${lowStock} منتج كميته منخفضة أو نافدة` : 'المخزون بحالة جيدة'}</p></div></div>
      </section>
    </div>
  );
}
