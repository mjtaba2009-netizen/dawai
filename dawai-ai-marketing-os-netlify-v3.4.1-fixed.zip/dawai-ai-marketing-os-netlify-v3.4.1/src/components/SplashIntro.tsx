/**
 * SplashIntro — "رحلة الدواء" — Narrative Delivery Intro
 * ──────────────────────────────────────────────────────
 * القصة: مدينة ليلية → دراجة التوصيل تدخل المشهد وتتوقف → المندوب يسلّم
 * الطرد للزبون → لحظة فرح (شرارات + قلب) → الطرد يتوهّج ويغمر الشاشة
 * بالضوء → من الضوء يولد شعار "دوائي" مع لمعة ذهبية.
 *
 * Timeline (App unmounts at 4.6s → +1.0s glass-wipe = 5.6s):
 *   0.00  سماء زمردية ليلية + نجوم + قمر + أفق مدينة
 *   0.30  الدراجة تدخل من اليسار (عجلات تدور، خطوط سرعة، ضوء أمامي)
 *   1.70  تتوقف أمام الزبون (ميلان كبح ثم استقرار)
 *   1.95  الطرد يقفز بقوس متوهّج من الدراجة إلى يدي الزبون
 *   2.15  الزبون يرفع ذراعيه ويستلم
 *   2.50  شرارات ذهبية + قلب فوق رأسه
 *   2.85  الطرد يتوهّج → وميض يغمر الشاشة
 *   3.25  من الضوء: "دوائي" يظهر + لمعة ذهبية تمسح الحروف
 *   4.15  فاصل + «دواؤك يوصل لباب بيتك» + التوقيع
 *   4.60  خروج زجاجي ناعم
 */
import { useEffect } from "react";
import { motion } from "framer-motion";
import { DawaiMark } from "./brand/DawaiMark";

const TEAL = "#2dd4bf"; // نبض الهوية على الداكن
const AMBER = "#FFB454"; // العنبر الرسمي

const GRAIN =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='140' height='140' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")";

// ═══════════════ المشهد: المدينة الليلية ═══════════════
function Sky() {
  const stars = Array.from({ length: 12 }, (_, i) => ({
    x: (i * 67 + 30) % 780,
    y: 20 + ((i * 41) % 150),
    r: 1 + (i % 2),
    d: (i % 5) * 0.6,
  }));
  return (
    <g>
      {stars.map((s, i) => (
        <motion.circle
          key={i} cx={s.x} cy={s.y} r={s.r} fill="#ccfbf1"
          initial={{ opacity: 0.15 }}
          animate={{ opacity: [0.15, 0.8, 0.15] }}
          transition={{ duration: 2.4, delay: s.d, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
      {/* القمر */}
      <motion.circle
        cx={668} cy={82} r={26} fill="#ebfffc"
        initial={{ opacity: 0 }} animate={{ opacity: 0.9 }}
        transition={{ duration: 1.2, delay: 0.2 }}
        style={{ filter: "drop-shadow(0 0 30px rgba(204,251,241,0.55)) drop-shadow(0 0 80px rgba(45,212,191,0.25))" }}
      />
    </g>
  );
}

function Skyline() {
  const b = [
    { x: 0, w: 70, h: 120 }, { x: 78, w: 55, h: 170 }, { x: 140, w: 90, h: 95 },
    { x: 238, w: 60, h: 150 }, { x: 306, w: 84, h: 110 }, { x: 398, w: 58, h: 185 },
    { x: 464, w: 92, h: 100 }, { x: 564, w: 62, h: 145 }, { x: 634, w: 96, h: 118 }, { x: 738, w: 62, h: 160 },
  ];
  return (
    <motion.g initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.15 }}>
      {b.map((r, i) => (
        <rect key={i} x={r.x} y={360 - r.h} width={r.w} height={r.h} rx={4} fill={i % 2 ? "#072826" : "#09302e"} />
      ))}
      {/* نوافذ مضيئة */}
      {b.map((r, i) => (
        <g key={"w" + i}>
          <rect x={r.x + 12} y={360 - r.h + 16} width={7} height={9} rx={1.5} fill={i % 3 === 0 ? AMBER : TEAL} opacity={0.5} />
          <rect x={r.x + r.w - 20} y={360 - r.h + 34} width={7} height={9} rx={1.5} fill={TEAL} opacity={0.32} />
          {i % 2 === 0 && (
            <motion.rect
              x={r.x + 26} y={360 - r.h + 52} width={7} height={9} rx={1.5} fill={AMBER}
              animate={{ opacity: [0.15, 0.7, 0.15] }}
              transition={{ duration: 2.8, delay: i * 0.3, repeat: Infinity }}
            />
          )}
        </g>
      ))}
      {/* الأرض */}
      <rect x={0} y={358} width={800} height={4} rx={2} fill="#0b3a38" />
      <rect x={0} y={362} width={800} height={88} fill="#041413" />
    </motion.g>
  );
}

// ═══════════════ عجلة تدور ═══════════════
function Wheel({ cx }: { cx: number }) {
  return (
    <g>
      <circle cx={cx} cy={334} r={24} fill="#081f1f" stroke="#11504c" strokeWidth={4} />
      <motion.g
        style={{ originX: `${cx}px`, originY: "334px" }}
        animate={{ rotate: 360 }}
        transition={{ duration: 0.5, repeat: Infinity, ease: "linear" }}
      >
        <line x1={cx - 15} y1={334} x2={cx + 15} y2={334} stroke="#1a5f5b" strokeWidth={3} />
        <line x1={cx} y1={319} x2={cx} y2={349} stroke="#1a5f5b" strokeWidth={3} />
        <line x1={cx - 11} y1={323} x2={cx + 11} y2={345} stroke="#1a5f5b" strokeWidth={2.5} />
      </motion.g>
      <circle cx={cx} cy={334} r={7} fill={TEAL} />
    </g>
  );
}

// ═══════════════ الدراجة + المندوب ═══════════════
function Rider() {
  return (
    <motion.g initial={{ x: -280 }} animate={{ x: 330 }} transition={{ duration: 1.35, delay: 0.25, ease: [0.22, 0.9, 0.3, 1] }}>
      {/* ميلان الكبح عند التوقف */}
      <motion.g
        style={{ originX: "170px", originY: "334px" }}
        initial={{ rotate: 0 }}
        animate={{ rotate: [0, 0, -4.5, 1.8, 0] }}
        transition={{ duration: 1.95, times: [0, 0.74, 0.83, 0.92, 1], ease: "easeOut" }}
      >
        {/* اهتزاز محرّك خفيف */}
        <motion.g animate={{ y: [0, -1.4, 0] }} transition={{ duration: 0.34, repeat: Infinity, ease: "easeInOut" }}>
          {/* ظل */}
          <ellipse cx={105} cy={358} rx={92} ry={6} fill="#010a0a" opacity={0.7} />

          {/* خطوط السرعة — تختفي عند التوقف */}
          <motion.g initial={{ opacity: 1 }} animate={{ opacity: 0 }} transition={{ delay: 1.55, duration: 0.25 }}>
            {[298, 314, 330].map((y, i) => (
              <motion.line
                key={y} x1={-88} y1={y} x2={-24} y2={y}
                stroke={TEAL} strokeWidth={3.5} strokeLinecap="round"
                animate={{ opacity: [0, 0.75, 0], x: [0, -22] }}
                transition={{ duration: 0.4, delay: 0.35 + i * 0.12, repeat: 3, ease: "easeOut" }}
              />
            ))}
          </motion.g>

          {/* ضوء أمامي + شعاع */}
          <motion.polygon
            points="196,256 330,230 330,288"
            fill="url(#beamGrad)"
            animate={{ opacity: [0.14, 0.24, 0.14] }}
            transition={{ duration: 0.9, repeat: Infinity }}
          />
          <circle cx={193} cy={259} r={5.5} fill="#fde68a" style={{ filter: `drop-shadow(0 0 8px ${AMBER})` }} />

          {/* هيكل الدراجة */}
          <line x1={42} y1={334} x2={82} y2={317} stroke="#0d3a38" strokeWidth={9} strokeLinecap="round" />
          <line x1={82} y1={320} x2={150} y2={322} stroke="#0d3a38" strokeWidth={11} strokeLinecap="round" />
          <line x1={170} y1={334} x2={179} y2={284} stroke="#0d3a38" strokeWidth={8} strokeLinecap="round" />
          <line x1={179} y1={284} x2={191} y2={257} stroke="#0FA294" strokeWidth={9} strokeLinecap="round" />
          <line x1={183} y1={257} x2={200} y2={251} stroke="#07302e" strokeWidth={6} strokeLinecap="round" />
          {/* مقعد */}
          <line x1={86} y1={281} x2={122} y2={279} stroke="#07302e" strokeWidth={12} strokeLinecap="round" />

          {/* صندوق التوصيل — عليه صليب طبي وحزام ذهبي */}
          <rect x={16} y={266} width={60} height={52} rx={9} fill="url(#boxGrad)" stroke="#0c4f4a" strokeWidth={2} />
          <rect x={40} y={276} width={12} height={32} rx={2.5} fill="#f0fdfa" />
          <rect x={30} y={286} width={32} height={12} rx={2.5} fill="#f0fdfa" />
          <rect x={16} y={293} width={60} height={5} fill={AMBER} opacity={0.9} />

          {/* المندوب */}
          <path d="M 100 284 L 119 306 L 139 317" fill="none" stroke="#0b4340" strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
          <line x1={139} y1={318} x2={150} y2={318} stroke="#081f1f" strokeWidth={8} strokeLinecap="round" />
          <line x1={98} y1={281} x2={131} y2={239} stroke="#0c4f4a" strokeWidth={13} strokeLinecap="round" />
          <line x1={127} y1={245} x2={183} y2={257} stroke="#0c4f4a" strokeWidth={8} strokeLinecap="round" />
          <circle cx={184} cy={257} r={4.5} fill="#e9b98c" />
          <circle cx={141} cy={221} r={14} fill="#e9b98c" />
          <path d="M 125 222 A 16 16 0 0 1 157 222 Z" fill="#0FA294" />
          <rect x={146} y={214} width={13} height={7} rx={3} fill="#ccfbf1" opacity={0.85} />

          {/* العجلات */}
          <Wheel cx={42} />
          <Wheel cx={170} />
        </motion.g>
      </motion.g>
    </motion.g>
  );
}

// ═══════════════ الزبون ═══════════════
function Customer() {
  return (
    <g>
      <ellipse cx={600} cy={358} rx={26} ry={5} fill="#010a0a" opacity={0.7} />
      {/* أرجل */}
      <line x1={594} y1={300} x2={590} y2={352} stroke="#0b3a38" strokeWidth={9} strokeLinecap="round" />
      <line x1={606} y1={300} x2={610} y2={352} stroke="#0b3a38" strokeWidth={9} strokeLinecap="round" />
      {/* جسد */}
      <line x1={600} y1={302} x2={600} y2={246} stroke="#0d4a46" strokeWidth={15} strokeLinecap="round" />
      {/* رأس */}
      <circle cx={600} cy={226} r={14} fill="#e9b98c" />
      <path d="M 586 224 A 14 14 0 0 1 614 224 Z" fill="#122a2a" />

      {/* ذراعان لأسفل → تختفي عند الاستلام */}
      <motion.g initial={{ opacity: 1 }} animate={{ opacity: 0 }} transition={{ delay: 2.05, duration: 0.12 }}>
        <line x1={600} y1={252} x2={583} y2={288} stroke="#0d4a46" strokeWidth={8} strokeLinecap="round" />
        <line x1={600} y1={252} x2={617} y2={288} stroke="#0d4a46" strokeWidth={8} strokeLinecap="round" />
      </motion.g>
      {/* ذراعان للاستلام */}
      <motion.g initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2.05, duration: 0.15 }}>
        <line x1={600} y1={252} x2={577} y2={262} stroke="#0d4a46" strokeWidth={8} strokeLinecap="round" />
        <line x1={600} y1={252} x2={592} y2={266} stroke="#0d4a46" strokeWidth={8} strokeLinecap="round" />
        <circle cx={576} cy={262} r={4} fill="#e9b98c" />
        <circle cx={591} cy={267} r={4} fill="#e9b98c" />
      </motion.g>

      {/* قلب فوق الرأس */}
      <motion.path
        d="M 600 194 c -3 -6 -12 -6 -12 1 c 0 5 7 9 12 13 c 5 -4 12 -8 12 -13 c 0 -7 -9 -7 -12 -1 Z"
        fill={AMBER}
        initial={{ opacity: 0, scale: 0, y: 6 }}
        animate={{ opacity: [0, 1, 1, 0], scale: [0, 1.25, 1, 0.9], y: [6, 0, -4, -10] }}
        transition={{ duration: 1.0, delay: 2.5, times: [0, 0.25, 0.7, 1] }}
        style={{ originX: "600px", originY: "200px", filter: `drop-shadow(0 0 8px ${AMBER})` }}
      />
    </g>
  );
}

// ═══════════════ الطرد المتنقل + الشرارات + الوميض ═══════════════
function Handoff() {
  const sparks = [
    { x: 562, y: 238, d: 2.4 }, { x: 612, y: 246, d: 2.52 },
    { x: 570, y: 282, d: 2.64 }, { x: 604, y: 226, d: 2.76 },
  ];
  return (
    <g>
      {/* الطرد يقفز بقوس */}
      <motion.g
        initial={{ x: 398, y: 288, opacity: 0, rotate: 0 }}
        animate={{ x: [398, 498, 574], y: [288, 232, 254], opacity: [0, 1, 1], rotate: [0, 16, 0] }}
        transition={{ duration: 0.55, delay: 1.8, times: [0, 0.55, 1], ease: "easeOut" }}
      >
        <rect x={0} y={0} width={26} height={22} rx={4} fill="url(#boxGrad)" stroke="#0c4f4a" strokeWidth={1.5}
          style={{ filter: "drop-shadow(0 0 10px rgba(45,212,191,0.8))" }} />
        <rect x={10} y={4} width={6} height={14} rx={1.5} fill="#f0fdfa" />
        <rect x={5} y={8} width={16} height={6} rx={1.5} fill="#f0fdfa" />
      </motion.g>

      {/* شرارات ذهبية */}
      {sparks.map((s, i) => (
        <motion.path
          key={i}
          d={`M ${s.x} ${s.y - 6} L ${s.x + 1.8} ${s.y - 1.8} L ${s.x + 6} ${s.y} L ${s.x + 1.8} ${s.y + 1.8} L ${s.x} ${s.y + 6} L ${s.x - 1.8} ${s.y + 1.8} L ${s.x - 6} ${s.y} L ${s.x - 1.8} ${s.y - 1.8} Z`}
          fill={AMBER}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: [0, 1, 0], scale: [0, 1.15, 0], rotate: 90 }}
          transition={{ duration: 0.55, delay: s.d }}
          style={{ originX: `${s.x}px`, originY: `${s.y}px`, filter: `drop-shadow(0 0 6px ${AMBER})` }}
        />
      ))}
    </g>
  );
}

// ═══════════════ المكوّن الرئيسي ═══════════════
export function SplashIntro() {
  // إزالة شاشة التمهيد الثابتة فور جهوز الانترو الحقيقي (نفس الخلفية = انتقال غير محسوس)
  useEffect(() => {
    document.getElementById("pre-splash")?.remove();
  }, []);

  const titleStyle: React.CSSProperties = {
    fontFamily: "'Cairo', sans-serif",
    fontWeight: 800,
    fontSize: "clamp(44px, 10vw, 72px)",
    lineHeight: 1.15,
    padding: "0 0.15em",
  };

  return (
    <motion.div
      key="splash"
      className="fixed inset-0 z-[9999] overflow-hidden"
      style={{ background: "radial-gradient(120% 90% at 50% 62%, #083134 0%, #051e21 55%, #020b0c 100%)" }}
      exit={{
        scale: 1.08, opacity: 0, filter: "blur(24px)",
        transition: { duration: 1.0, ease: [0.4, 0, 0.2, 1] },
      }}
    >
      {/* حبيبات سينمائية */}
      <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: GRAIN, opacity: 0.055, mixBlendMode: "overlay" }} />

      {/* ══ المشهد السردي ══ */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ delay: 3.3, duration: 0.35 }}
      >
        <svg viewBox="0 0 800 450" style={{ width: "min(100vw, 780px)", height: "auto" }} className="select-none">
          <defs>
            <linearGradient id="boxGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0FA294" />
              <stop offset="100%" stopColor="#0A6A63" />
            </linearGradient>
            <linearGradient id="beamGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor={AMBER} stopOpacity="0.55" />
              <stop offset="100%" stopColor={AMBER} stopOpacity="0" />
            </linearGradient>
          </defs>
          <Sky />
          <Skyline />
          <Customer />
          <Rider />
          <Handoff />
        </svg>
      </motion.div>

      {/* ══ الوميض — الطرد يغمر الشاشة بالضوء ══ */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(circle at 68% 56%, #fffbe8 0%, #a7f3d0 30%, rgba(45,212,191,0.6) 50%, transparent 72%)",
          transformOrigin: "68% 56%",
        }}
        initial={{ opacity: 0, scale: 0.1 }}
        animate={{ opacity: [0, 1, 1, 0], scale: [0.1, 1.6, 2.4, 3] }}
        transition={{ duration: 0.75, delay: 2.95, times: [0, 0.45, 0.75, 1], ease: "easeIn" }}
      />

      {/* ══ مشهد الشعار — يولد من الضوء ══ */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 3.25, duration: 0.3 }}
      >
        {/* هالة تتنفس */}
        <motion.div
          className="absolute rounded-full pointer-events-none"
          style={{
            width: 620, height: 620, top: "50%", left: "50%", x: "-50%", y: "-50%",
            background: "radial-gradient(circle, rgba(45,212,191,0.5) 0%, rgba(15,162,148,0.18) 35%, transparent 70%)",
            filter: "blur(100px)",
          }}
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{ opacity: [0, 0.42, 0.32, 0.42], scale: [0.6, 1, 0.96, 1] }}
          transition={{
            opacity: { duration: 2.4, delay: 3.35, times: [0, 0.35, 0.7, 1], repeat: Infinity, repeatType: "reverse", ease: "easeInOut" },
            scale: { duration: 3.0, delay: 3.35, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" },
          }}
        />

        <div className="relative z-10 flex flex-col items-center" dir="rtl">
          {/* الرمز الرسمي — يولد من الضوء بدوران خفيف */}
          <motion.div
            initial={{ opacity: 0, scale: 0.4, rotate: -14, filter: "blur(10px)" }}
            animate={{ opacity: 1, scale: 1, rotate: 0, filter: "blur(0px)" }}
            transition={{ duration: 0.7, delay: 3.3, ease: [0.2, 0.9, 0.3, 1.15] }}
            className="mb-5"
            style={{ filter: "drop-shadow(0 14px 40px rgba(10,106,99,0.55))" }}
          >
            <DawaiMark size={112} />
          </motion.div>

          <div className="relative">
            <motion.h1
              className="text-white select-none"
              style={{
                ...titleStyle,
                textShadow: "0 0 60px rgba(45,212,191,0.45), 0 0 160px rgba(45,212,191,0.18), 0 4px 30px rgba(0,0,0,0.7)",
              }}
              initial={{ opacity: 0, scale: 1.18, filter: "blur(12px)" }}
              animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
              transition={{ duration: 0.7, delay: 3.55, ease: [0.22, 0.8, 0.3, 1] }}
            >
              دوائي
            </motion.h1>
            {/* لمعة ذهبية */}
            <motion.h1
              aria-hidden="true"
              className="absolute inset-0 select-none pointer-events-none"
              style={{
                ...titleStyle,
                color: "transparent",
                backgroundImage: `linear-gradient(105deg, transparent 42%, rgba(255,244,214,0.95) 50%, ${AMBER} 53%, transparent 61%)`,
                backgroundSize: "260% 100%",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
              }}
              initial={{ backgroundPosition: "210% 0", opacity: 0 }}
              animate={{ backgroundPosition: "-120% 0", opacity: [0, 1, 1, 0] }}
              transition={{ duration: 1.0, delay: 4.3, ease: "easeInOut", times: [0, 0.15, 0.85, 1] }}
            >
              دوائي
            </motion.h1>
          </div>

          {/* فاصل بنقطة ماسية */}
          <motion.div className="flex items-center gap-2 mt-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4, delay: 4.45 }}>
            <motion.span className="h-px" style={{ background: `linear-gradient(to left, transparent, ${TEAL})` }}
              initial={{ width: 0 }} animate={{ width: 56 }} transition={{ duration: 0.5, delay: 4.45, ease: "easeOut" }} />
            <span className="block" style={{ width: 5, height: 5, transform: "rotate(45deg)", background: AMBER, boxShadow: `0 0 10px ${AMBER}` }} />
            <motion.span className="h-px" style={{ background: `linear-gradient(to right, transparent, ${TEAL})` }}
              initial={{ width: 0 }} animate={{ width: 56 }} transition={{ duration: 0.5, delay: 4.45, ease: "easeOut" }} />
          </motion.div>

          {/* العنوان الفرعي — يربط القصة */}
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 4.6, ease: "easeOut" }}
            className="select-none mt-3.5 text-base"
            style={{ fontFamily: "'Cairo', sans-serif", fontWeight: 600, color: "rgba(204,251,241,0.95)", letterSpacing: "0.12em" }}
          >
            دواؤك يوصل لباب بيتك
          </motion.p>
        </div>
      </motion.div>

      {/* توقيع المطوّر */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.7, delay: 4.75 }}
        className="absolute bottom-8 left-0 right-0 flex justify-center pointer-events-none">
        <p className="text-slate-600 text-[10px] select-none" style={{ letterSpacing: "0.2em" }}>
          Powered by Promptify IQ
        </p>
      </motion.div>
    </motion.div>
  );
}
