import type { ReactNode } from 'react';
import { useContext } from 'react';
import { useLocation } from 'react-router-dom';
import { AuthContext } from '@/contexts/AuthContext';
import { BottomNav } from './BottomNav';
import { Navbar } from './Navbar';

export function Layout({ children }: { children: ReactNode }) {
  const auth = useContext(AuthContext);
  const location = useLocation();
  const hasUser = Boolean(auth?.user);
  const onOwnerDashboard = auth?.user?.role === 'owner' && location.pathname.startsWith('/owner');
  const onMarketingOS = auth?.user?.role === 'owner' && location.pathname.startsWith('/owner/marketing');

  return (
    <div className="min-h-[100dvh] bg-slate-100 flex justify-center" dir="rtl">
      <main className={`relative w-full ${onMarketingOS ? 'max-w-none shadow-none' : onOwnerDashboard ? 'max-w-6xl shadow-2xl' : 'max-w-[430px] shadow-2xl'} min-h-[100dvh] bg-white overflow-x-hidden flex flex-col ${hasUser && !onOwnerDashboard ? 'pb-[calc(64px+env(safe-area-inset-bottom))]' : ''}`}>
        <Navbar />
        {children}
        {hasUser && !onOwnerDashboard && <BottomNav />}
      </main>
    </div>
  );
}
