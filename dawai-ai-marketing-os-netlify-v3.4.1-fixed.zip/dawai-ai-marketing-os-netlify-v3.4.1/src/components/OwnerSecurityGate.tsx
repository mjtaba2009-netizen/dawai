import { useEffect, useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { KeyRound, Loader2, ShieldAlert } from 'lucide-react';
import { getSecurityState, verifyMfaCode } from '@/services/security';
import type { MfaFactorSummary, SecurityState } from '@/services/types';
import { getErrorMessage } from '@/lib/error';

export function OwnerSecurityGate({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [state, setState] = useState<SecurityState | null>(null);
  const [factor, setFactor] = useState<MfaFactorSummary | null>(null);
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const refresh = async () => {
    setLoading(true);
    try {
      const next = await getSecurityState();
      setState(next);
      setFactor(next.factors.find((item) => item.status === 'verified') ?? null);
    } catch (err) { setError(getErrorMessage(err)); }
    finally { setLoading(false); }
  };
  useEffect(() => { void refresh(); }, []);

  if (loading) return <div className="min-h-[70dvh] flex items-center justify-center"><Loader2 className="w-8 h-8 text-teal-500 animate-spin" /></div>;
  if (state?.currentLevel === 'aal2') return <>{children}</>;

  const verify = async () => {
    if (!factor) return;
    setLoading(true); setError('');
    try { await verifyMfaCode(factor, code); await refresh(); }
    catch (err) { setError(getErrorMessage(err, 'الرمز غير صحيح أو انتهت صلاحيته')); setLoading(false); }
  };

  return (
    <div className="min-h-[100dvh] bg-slate-950 text-white flex items-center justify-center p-5" dir="rtl">
      <div className="w-full max-w-md rounded-[32px] bg-white text-slate-900 p-6 shadow-2xl text-center">
        <div className="w-16 h-16 rounded-3xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto"><ShieldAlert className="w-8 h-8" /></div>
        <h1 className="font-black text-xl mt-4">حماية لوحة المالك</h1>
        {!factor ? <><p className="text-sm text-slate-500 leading-6 mt-2">يجب تفعيل المصادقة بخطوتين قبل إدارة الصيدليات والكوزمتك أو حذف أي متجر.</p><button onClick={() => navigate('/security')} className="mt-5 w-full h-12 rounded-2xl bg-teal-600 text-white font-bold flex items-center justify-center gap-2"><KeyRound className="w-5 h-5" />فتح مركز الأمان</button></> : <><p className="text-sm text-slate-500 mt-2">أدخل رمز تطبيق المصادقة لإكمال الدخول.</p><input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))} inputMode="numeric" dir="ltr" className="mt-5 w-full h-14 rounded-2xl border border-slate-200 text-center text-xl font-black tracking-[0.5em] outline-none focus:border-teal-400" placeholder="000000" />{error && <p className="text-xs text-red-600 mt-2">{error}</p>}<button onClick={verify} disabled={code.length !== 6 || loading} className="mt-4 w-full h-12 rounded-2xl bg-slate-900 text-white font-bold disabled:opacity-50">التحقق والدخول</button></>}
      </div>
    </div>
  );
}
