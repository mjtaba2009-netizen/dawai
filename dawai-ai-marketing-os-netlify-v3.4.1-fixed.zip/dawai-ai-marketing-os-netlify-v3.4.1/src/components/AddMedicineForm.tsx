import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Pill, DollarSign, Hash, ShieldCheck, Tag, ImagePlus, Trash2, Factory, Globe2, Barcode, CalendarDays, BadgeCheck } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { prepareProductImage } from '@/lib/image';
import { getErrorMessage } from '@/lib/error';

// الفئات المتاحة حسب نوع البائع — يجب أن تطابق VENDOR_CATEGORIES على الخادم
const CATEGORIES_BY_ROLE: Record<'pharmacy' | 'cosmetic', readonly string[]> = {
  pharmacy: ['مسكنات', 'مضادات حيوية', 'فيتامينات', 'أمراض مزمنة', 'أجهزة طبية'],
  cosmetic: ['فيتامينات', 'سكن كير', 'مكياج'],
};

// يتم ضغط صور الهاتف تلقائياً قبل حفظها، بما فيها صور iPhone المدعومة من Safari.
interface AddMedicineFormProps {
  onAdd: (data: {
    medicationName: string;
    price: number;
    quantity: number;
    requiresPrescription: boolean;
    category: string;
    imageUrl?: string;
    manufacturer?: string;
    countryOfOrigin?: string;
    batchNumber?: string;
    expiryDate?: string;
    originalPrice?: number;
    authenticityStatus?: 'unverified' | 'declared_original';
  }) => Promise<void>;
  onClose: () => void;
}

function ToggleSwitch({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      style={{ width: '52px' }}
      className={`relative inline-flex h-7 flex-shrink-0 cursor-pointer rounded-full
        border border-white/30
        transition-colors duration-200 focus:outline-none
        backdrop-blur-sm
        ${checked ? 'bg-teal-500/90' : 'bg-slate-300/70'}`}
      data-testid="toggle-prescription"
    >
      <span
        aria-hidden="true"
        className="absolute left-[2px] top-[1px] h-6 w-6 rounded-full bg-white shadow-md transition-transform duration-200 ease-out"
        style={{ transform: `translateX(${checked ? 24 : 0}px)` }}
      />
    </button>
  );
}

export function AddMedicineForm({ onAdd, onClose }: AddMedicineFormProps) {
  const { user } = useAuth();
  const isCosmetic = user?.role === 'cosmetic';
  const categories = CATEGORIES_BY_ROLE[isCosmetic ? 'cosmetic' : 'pharmacy'];
  const itemLabel = isCosmetic ? 'المنتج' : 'الدواء';

  const [medicationName, setMedicationName] = useState('');
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [requiresPrescription, setRequiresPrescription] = useState(false);
  const [category, setCategory] = useState<string>(categories[0]);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [manufacturer, setManufacturer] = useState('');
  const [countryOfOrigin, setCountryOfOrigin] = useState('');
  const [batchNumber, setBatchNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [declaredOriginal, setDeclaredOriginal] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [imageProcessing, setImageProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setImageError(null);
    setImageProcessing(true);
    try {
      setImageUrl(await prepareProductImage(file));
    } catch (error) {
      setImageError(getErrorMessage(error, 'تعذر تجهيز الصورة'));
    } finally {
      setImageProcessing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!medicationName.trim() || !price || quantity === '') return;

    setIsLoading(true);
    try {
      await onAdd({
        medicationName: medicationName.trim(),
        price: parseInt(price, 10),
        quantity: parseInt(quantity, 10),
        requiresPrescription,
        category,
        imageUrl: imageUrl ?? undefined,
        manufacturer: manufacturer.trim() || undefined,
        countryOfOrigin: countryOfOrigin.trim() || undefined,
        batchNumber: batchNumber.trim() || undefined,
        expiryDate: expiryDate || undefined,
        originalPrice: originalPrice ? Number(originalPrice) : undefined,
        authenticityStatus: declaredOriginal ? 'declared_original' : 'unverified',
      });
      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  const inputClass =
    `w-full h-12 px-4 rounded-xl text-sm text-slate-800 outline-none transition-all
    bg-white/50 backdrop-blur-md
    border border-white/60
    shadow-[0_2px_8px_rgb(0,0,0,0.04)]
    placeholder-slate-300
    focus:border-slate-600/40 focus:ring-1 focus:ring-slate-600/20`;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.22 }}
      className="fixed inset-0 z-[120] flex items-stretch sm:items-end justify-center bg-black/50 backdrop-blur-sm overscroll-contain"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ y: '100%', opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: '100%', opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300, mass: 0.8 }}
        className="w-full max-w-[430px] h-[100dvh] sm:h-auto max-h-[100dvh] sm:max-h-[calc(100dvh-10px)] overflow-hidden rounded-none sm:rounded-t-3xl
          bg-white/90 backdrop-blur-2xl border-t border-white/60
          shadow-[0_-12px_40px_rgb(0,0,0,0.18)] flex flex-col"
      >
        {/* رأس النموذج */}
        <div className="shrink-0 bg-slate-900/90 backdrop-blur-xl px-5 pt-[calc(env(safe-area-inset-top)+14px)] sm:pt-5 pb-5 border-b border-white/10">
          <div className="flex items-center justify-between mb-4">
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center transition-colors border border-white/10"
              data-testid="button-close-add-form"
            >
              <X className="w-4 h-4 text-white" />
            </button>
            <div className="w-10 h-10 bg-teal-500/20 backdrop-blur-sm border border-teal-400/30 rounded-2xl flex items-center justify-center">
              <Pill className="w-5 h-5 text-teal-400" />
            </div>
          </div>
          <h2 className="text-white font-bold text-lg">{isCosmetic ? 'إضافة منتج جديد' : 'إضافة دواء جديد'}</h2>
          <p className="text-slate-400 text-sm mt-0.5">أدخل بيانات {itemLabel} يدوياً لإضافته للمخزون</p>
        </div>

        {/* النموذج */}
        <form onSubmit={handleSubmit} className="flex-1 min-h-0 px-5 py-5 space-y-4 overflow-y-auto overscroll-contain pb-[calc(env(safe-area-inset-bottom)+24px)]">

          {/* اسم الدواء */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-sm font-semibold text-slate-700">
              <Pill className="w-3.5 h-3.5 text-slate-400" />
              اسم {itemLabel} <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              value={medicationName}
              onChange={(e) => setMedicationName(e.target.value)}
              required
              placeholder={isCosmetic ? 'مثال: كريم مرطب للوجه' : 'مثال: باراسيتامول 500mg'}
              className={inputClass}
              data-testid="input-medication-name"
            />
          </div>

          {/* الفئة */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-sm font-semibold text-slate-700">
              <Tag className="w-3.5 h-3.5 text-slate-400" />
              الفئة <span className="text-red-400">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className={`${inputClass} appearance-none cursor-pointer`}
              data-testid="select-category"
            >
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* السعر */}
            <div className="space-y-1.5">
              <label className="flex items-center gap-1.5 text-sm font-semibold text-slate-700">
                <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                السعر (د.ع) <span className="text-red-400">*</span>
              </label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                required
                min="1"
                step="1"
                placeholder="0"
                className={inputClass}
                data-testid="input-price"
              />
            </div>

            {/* الكمية */}
            <div className="space-y-1.5">
              <label className="flex items-center gap-1.5 text-sm font-semibold text-slate-700">
                <Hash className="w-3.5 h-3.5 text-slate-400" />
                الكمية <span className="text-red-400">*</span>
              </label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                required
                min="0"
                step="1"
                placeholder="0"
                className={inputClass}
                data-testid="input-quantity"
              />
            </div>
          </div>

          <section className="rounded-2xl border border-amber-100 bg-amber-50/60 p-4 space-y-3" aria-label="بيانات أصالة المنتج">
            <div className="flex items-center gap-2"><BadgeCheck className="w-5 h-5 text-amber-600" /><div><p className="font-bold text-sm text-slate-800">بيانات الأصالة والانتهاء</p><p className="text-[11px] text-slate-500">تساعد المستخدم على التحقق والإبلاغ عن المنتجات المشكوك بها</p></div></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="space-y-1.5 text-xs font-semibold text-slate-700"><span className="flex gap-1"><Factory className="w-3.5 h-3.5" />الشركة المصنعة</span><input className={inputClass} value={manufacturer} onChange={(e) => setManufacturer(e.target.value)} placeholder="اسم الشركة" /></label>
              <label className="space-y-1.5 text-xs font-semibold text-slate-700"><span className="flex gap-1"><Globe2 className="w-3.5 h-3.5" />بلد المنشأ</span><input className={inputClass} value={countryOfOrigin} onChange={(e) => setCountryOfOrigin(e.target.value)} placeholder="مثال: العراق" /></label>
              <label className="space-y-1.5 text-xs font-semibold text-slate-700"><span className="flex gap-1"><Barcode className="w-3.5 h-3.5" />رقم التشغيلة</span><input className={inputClass} value={batchNumber} onChange={(e) => setBatchNumber(e.target.value)} placeholder="LOT / Batch" dir="ltr" /></label>
              <label className="space-y-1.5 text-xs font-semibold text-slate-700"><span className="flex gap-1"><CalendarDays className="w-3.5 h-3.5" />تاريخ الانتهاء</span><input className={inputClass} type="date" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} /></label>
              <label className="space-y-1.5 text-xs font-semibold text-slate-700 sm:col-span-2"><span>السعر قبل الخصم (اختياري)</span><input className={inputClass} type="number" min="0" value={originalPrice} onChange={(e) => setOriginalPrice(e.target.value)} placeholder="0" /></label>
            </div>
            <label className="flex items-start gap-2 text-xs leading-5 text-slate-700"><input type="checkbox" checked={declaredOriginal} onChange={(e) => setDeclaredOriginal(e.target.checked)} className="mt-1 accent-teal-600" /><span>أقر أن المنتج من مصدر موثوق وأن بيانات التشغيلة والانتهاء صحيحة. هذا الإقرار لا يستبدل مراجعة المنصة.</span></label>
          </section>

          {/* صورة الدواء (اختياري) */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-sm font-semibold text-slate-700">
              <ImagePlus className="w-3.5 h-3.5 text-slate-400" />
              صورة {itemLabel} <span className="text-slate-400 font-normal">(اختياري)</span>
            </label>

            {imageUrl ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: 'spring', damping: 20, stiffness: 350 }}
                className="relative rounded-2xl overflow-hidden border border-teal-400/50 shadow-[0_4px_16px_rgb(0,0,0,0.06)]"
              >
                <img src={imageUrl} alt="معاينة الدواء" className="w-full h-36 object-cover" />
                <button
                  type="button"
                  onClick={() => setImageUrl(null)}
                  className="absolute top-2 left-2 w-8 h-8 bg-red-500/90 backdrop-blur-sm rounded-xl flex items-center justify-center"
                  data-testid="button-remove-medicine-image"
                >
                  <Trash2 className="w-4 h-4 text-white" />
                </button>
              </motion.div>
            ) : (
              <motion.button
                type="button"
                whileTap={{ scale: 0.98 }}
                transition={{ type: 'spring', damping: 20, stiffness: 400 }}
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-28 rounded-2xl flex flex-col items-center justify-center gap-2 text-slate-500
                  bg-white/50 backdrop-blur-md
                  border border-white/60 border-dashed
                  hover:border-teal-400/70 hover:text-teal-600
                  shadow-[0_4px_16px_rgb(0,0,0,0.05)]
                  transition-colors"
                data-testid="button-upload-medicine-image"
              >
                {imageProcessing ? <span className="w-6 h-6 rounded-full border-2 border-teal-500 border-t-transparent animate-spin" /> : <ImagePlus className="w-6 h-6" />}
                <span className="text-xs font-semibold">{imageProcessing ? 'جاري تجهيز الصورة...' : `رفع صورة ${isCosmetic ? 'للمنتج' : 'للدواء'}`}</span>
                <span className="text-[10px] text-slate-400">اختر أي صورة من الهاتف — تُضغط تلقائياً</span>
              </motion.button>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,.heic,.heif,.avif"
              className="hidden"
              onChange={handleFileChange}
              data-testid="input-medicine-image"
            />

            <AnimatePresence>
              {imageError && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="text-xs text-red-600 leading-snug"
                >
                  {imageError}
                </motion.p>
              )}
            </AnimatePresence>
          </div>

          {/* تبديل وصفة طبية — للصيدليات فقط */}
          {!isCosmetic && (
            <motion.div
              whileTap={{ scale: 0.98 }}
              transition={{ type: 'spring', damping: 20, stiffness: 400 }}
              className="flex items-center justify-between p-4 rounded-2xl
                bg-white/50 backdrop-blur-md
                border border-white/60
                shadow-[0_2px_8px_rgb(0,0,0,0.04)]"
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${requiresPrescription ? 'bg-teal-100/80' : 'bg-slate-100/80'}`}>
                  <ShieldCheck
                    className={`transition-colors ${requiresPrescription ? 'text-teal-600' : 'text-slate-400'}`}
                    style={{ width: '18px', height: '18px' }}
                  />
                </div>
                <div>
                  <p className="text-slate-800 font-semibold text-sm">يحتاج وصفة طبية</p>
                  <p className="text-slate-400 text-xs mt-0.5">
                    {requiresPrescription ? 'نعم، يستلزم وصفة' : 'لا، يُصرف بحرية'}
                  </p>
                </div>
              </div>
              <ToggleSwitch checked={requiresPrescription} onChange={setRequiresPrescription} />
            </motion.div>
          )}

          {/* الأزرار */}
          <div className="flex gap-3 pt-1 pb-safe">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 h-12 rounded-xl text-slate-600 font-semibold text-sm
                bg-white/60 backdrop-blur-md
                border border-white/60
                shadow-[0_2px_8px_rgb(0,0,0,0.05)]
                hover:bg-white/80 transition-colors"
            >
              إلغاء
            </button>
            <motion.button
              type="submit"
              whileTap={{ scale: 0.96 }}
              transition={{ type: 'spring', damping: 20, stiffness: 400 }}
              disabled={isLoading || imageProcessing || !medicationName.trim() || !price || quantity === ''}
              className="flex-1 h-12 rounded-xl text-white font-bold text-sm
                bg-slate-800/90 backdrop-blur-md
                border border-white/10
                shadow-[0_4px_16px_rgb(0,0,0,0.2)]
                hover:bg-slate-700/90 transition-colors
                disabled:opacity-50 flex items-center justify-center gap-2"
              data-testid="button-add-medicine"
            >
              <AnimatePresence mode="wait">
                {isLoading ? (
                  <motion.div
                    key="spinner"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ type: 'spring', damping: 20, stiffness: 350 }}
                    className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin"
                  />
                ) : (
                  <motion.span
                    key="label"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    {isCosmetic ? 'إضافة المنتج' : 'إضافة الدواء'}
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
