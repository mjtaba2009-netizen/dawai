import { useState } from 'react';
import { AlertTriangle, ClipboardList, Eye, MessageSquareWarning, ShieldCheck, Star } from 'lucide-react';
import { useModerateProductReport, useModerateRating, useOwnerAuditLogs, useOwnerDisputes, useOwnerProductReports, useOwnerRatings, useResolveDispute } from '@/services/hooks';
import { useToast } from '@/hooks/use-toast';
import { getErrorMessage } from '@/lib/error';
import { getDisputeEvidenceSignedUrl, getProductReportEvidenceSignedUrl } from '@/services/api';

const tabs = [
  { id: 'disputes', label: 'الشكاوى', icon: AlertTriangle },
  { id: 'reports', label: 'بلاغات المنتجات', icon: MessageSquareWarning },
  { id: 'ratings', label: 'التقييمات', icon: Star },
  { id: 'audit', label: 'سجل العمليات', icon: ClipboardList },
] as const;

type Tab = typeof tabs[number]['id'];

export function OwnerOperations() {
  const [tab, setTab] = useState<Tab>('disputes');
  const { toast } = useToast();
  const disputes = useOwnerDisputes(); const resolveDispute = useResolveDispute();
  const reports = useOwnerProductReports(); const moderateReport = useModerateProductReport();
  const ratings = useOwnerRatings(); const moderateRating = useModerateRating();
  const audit = useOwnerAuditLogs();

  const act = async (action: () => Promise<unknown>, success: string) => { try { await action(); toast({ title: success }); } catch (error) { toast({ title: 'تعذّر تنفيذ العملية', description: getErrorMessage(error), variant: 'destructive' }); } };
  const openEvidence = async (kind: 'dispute' | 'report', path: string) => {
    try {
      const url = kind === 'dispute' ? await getDisputeEvidenceSignedUrl(path) : await getProductReportEvidenceSignedUrl(path);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (error) {
      toast({ title: 'تعذّر فتح المرفق', description: getErrorMessage(error), variant: 'destructive' });
    }
  };

  return <section className="mt-6 rounded-3xl bg-white border border-slate-200 p-4 shadow-sm" dir="rtl">
    <div className="flex items-center gap-2 mb-4"><ShieldCheck className="w-5 h-5 text-teal-600" /><div><h2 className="font-extrabold text-slate-900">مركز الثقة والمتابعة</h2><p className="text-xs text-slate-400">الشكاوى، بلاغات الأصالة، التقييمات وسجل قرارات المالك</p></div></div>
    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">{tabs.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setTab(id)} className={`flex-shrink-0 h-10 px-3 rounded-xl text-xs font-bold flex items-center gap-1.5 ${tab === id ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'}`}><Icon className="w-4 h-4" />{label}</button>)}</div>

    {tab === 'disputes' && <div className="space-y-3 mt-3">{disputes.isLoading ? <div className="h-24 bg-slate-100 animate-pulse rounded-2xl" /> : !disputes.data?.length ? <Empty text="لا توجد شكاوى" /> : disputes.data.map((item) => <article key={item.id} className="rounded-2xl border border-slate-200 p-3"><div className="flex justify-between gap-2"><div><p className="font-bold text-slate-800">{item.reason}</p><p className="text-xs text-slate-400">{item.userName || 'مستخدم'} · {item.orderTrackingCode || `طلب ${item.orderId}`}</p></div><Status value={item.status} /></div>{item.description && <p className="text-xs text-slate-600 mt-2 leading-5">{item.description}</p>}{item.evidencePath && <button type="button" onClick={() => void openEvidence('dispute', item.evidencePath!)} className="mt-2 h-9 px-3 rounded-xl bg-blue-50 text-blue-700 text-xs font-bold flex items-center gap-1"><Eye className="w-4 h-4" />فتح دليل الشكوى (رابط مؤقت)</button>}<div className="grid grid-cols-3 gap-2 mt-3"><button onClick={() => act(() => resolveDispute.mutateAsync({ id:item.id,status:'under_review',response:'بدأت مراجعة الشكوى' }), 'تم بدء المراجعة')} className="h-9 rounded-xl bg-amber-50 text-amber-700 text-xs font-bold">مراجعة</button><button onClick={() => { const response=window.prompt('اكتب نتيجة الحل للمستخدم')||'تم حل الشكوى'; void act(() => resolveDispute.mutateAsync({id:item.id,status:'resolved',response}), 'تم حل الشكوى'); }} className="h-9 rounded-xl bg-teal-500 text-white text-xs font-bold">حل</button><button onClick={() => act(() => resolveDispute.mutateAsync({id:item.id,status:'rejected',response:'لم تتوفر أدلة كافية'}), 'تم إغلاق الشكوى')} className="h-9 rounded-xl bg-red-50 text-red-700 text-xs font-bold">رفض</button></div></article>)}</div>}

    {tab === 'reports' && <div className="space-y-3 mt-3">{reports.isLoading ? <div className="h-24 bg-slate-100 animate-pulse rounded-2xl" /> : !reports.data?.length ? <Empty text="لا توجد بلاغات عن المنتجات" /> : reports.data.map((item) => <article key={item.id} className="rounded-2xl border border-slate-200 p-3"><div className="flex justify-between"><div><p className="font-bold text-slate-800">{item.medicationName || `منتج ${item.medicationId}`}</p><p className="text-xs text-slate-400">{item.pharmacyName || 'متجر'} · {item.reason}</p></div><Status value={item.status} /></div>{item.details && <p className="text-xs text-slate-600 mt-2">{item.details}</p>}{item.evidencePath && <button type="button" onClick={() => void openEvidence('report', item.evidencePath!)} className="mt-2 h-9 px-3 rounded-xl bg-blue-50 text-blue-700 text-xs font-bold flex items-center gap-1"><Eye className="w-4 h-4" />فتح صورة البلاغ (رابط مؤقت)</button>}<div className="grid grid-cols-3 gap-2 mt-3"><button onClick={() => act(() => moderateReport.mutateAsync({id:item.id,status:'under_review'}), 'تم بدء التحقيق')} className="h-9 rounded-xl bg-amber-50 text-amber-700 text-xs font-bold">تحقيق</button><button onClick={() => act(() => moderateReport.mutateAsync({id:item.id,status:'resolved',notes:'تم تأكيد البلاغ ووضع علامة تحذير على المنتج'}), 'تم اعتماد البلاغ')} className="h-9 rounded-xl bg-red-600 text-white text-xs font-bold">تأكيد البلاغ</button><button onClick={() => act(() => moderateReport.mutateAsync({id:item.id,status:'dismissed'}), 'تم إغلاق البلاغ')} className="h-9 rounded-xl bg-slate-100 text-slate-600 text-xs font-bold">استبعاد</button></div></article>)}</div>}

    {tab === 'ratings' && <div className="space-y-3 mt-3">{ratings.isLoading ? <div className="h-24 bg-slate-100 animate-pulse rounded-2xl" /> : !ratings.data?.length ? <Empty text="لا توجد تقييمات بانتظار المراجعة" /> : ratings.data.map((item) => <article key={item.id} className="rounded-2xl border border-slate-200 p-3"><div className="flex justify-between"><div><p className="font-bold text-slate-800">{item.pharmacyName || 'متجر'}</p><p className="text-xs text-amber-600">{'★'.repeat(item.rating)}{'☆'.repeat(5-item.rating)}</p></div><Status value={item.status} /></div>{item.comment && <p className="text-xs text-slate-600 mt-2">{item.comment}</p>}<div className="grid grid-cols-2 gap-2 mt-3"><button onClick={() => act(() => moderateRating.mutateAsync({id:item.id,status:'published'}), 'تم نشر التقييم')} className="h-9 rounded-xl bg-teal-500 text-white text-xs font-bold">نشر</button><button onClick={() => act(() => moderateRating.mutateAsync({id:item.id,status:'hidden'}), 'تم إخفاء التقييم')} className="h-9 rounded-xl bg-red-50 text-red-700 text-xs font-bold">إخفاء</button></div></article>)}</div>}

    {tab === 'audit' && <div className="space-y-2 mt-3">{audit.isLoading ? <div className="h-24 bg-slate-100 animate-pulse rounded-2xl" /> : !audit.data?.length ? <Empty text="لا توجد عمليات مسجلة" /> : audit.data.slice(0,50).map((item) => <div key={item.id} className="rounded-xl bg-slate-50 p-3 flex gap-3"><Eye className="w-4 h-4 text-slate-400 mt-0.5" /><div><p className="text-xs font-bold text-slate-700">{item.action} · {item.targetType || 'منصة'}</p><p className="text-[10px] text-slate-400">{new Date(item.createdAt).toLocaleString('ar-IQ')} {item.actorName ? `· ${item.actorName}` : ''}</p></div></div>)}</div>}
  </section>;
}

function Empty({ text }: { text: string }) { return <p className="text-center text-sm text-slate-400 py-8">{text}</p>; }
function Status({ value }: { value: string }) { return <span className="h-fit rounded-full bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600">{value}</span>; }
