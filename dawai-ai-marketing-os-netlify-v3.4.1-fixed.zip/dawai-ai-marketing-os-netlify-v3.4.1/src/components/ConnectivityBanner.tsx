import { useEffect, useState } from 'react';
import { WifiOff, Wifi } from 'lucide-react';

export function ConnectivityBanner() {
  const [online, setOnline] = useState(() => navigator.onLine);
  const [justBack, setJustBack] = useState(false);

  useEffect(() => {
    const onOnline = () => {
      setOnline(true);
      setJustBack(true);
      window.setTimeout(() => setJustBack(false), 2500);
    };
    const onOffline = () => setOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  if (online && !justBack) return null;
  return (
    <div role="status" aria-live="polite" className={`fixed top-[env(safe-area-inset-top)] left-1/2 -translate-x-1/2 z-[200] px-4 py-2 rounded-b-2xl shadow-lg text-xs font-bold flex items-center gap-2 ${online ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-white'}`}>
      {online ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
      {online ? 'عاد الاتصال بالإنترنت' : 'أنت بدون إنترنت — سنعرض آخر بيانات محفوظة'}
    </div>
  );
}
