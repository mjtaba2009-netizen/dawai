import { AlertTriangle, RefreshCw } from 'lucide-react';
import { getErrorMessage } from '@/lib/error';

export function ErrorState({ error, onRetry, title = 'تعذّر تحميل البيانات' }: { error: unknown; onRetry?: () => void; title?: string }) {
  return (
    <div role="alert" className="rounded-3xl border border-red-200 bg-red-50 p-5 text-center">
      <AlertTriangle className="w-9 h-9 text-red-500 mx-auto" />
      <h3 className="font-extrabold text-red-900 mt-3">{title}</h3>
      <p className="text-sm text-red-700 mt-2 leading-6">{getErrorMessage(error, 'تحقق من الاتصال وحاول مرة أخرى')}</p>
      {onRetry && <button onClick={onRetry} className="mt-4 h-11 px-5 rounded-xl bg-red-600 text-white font-bold text-sm inline-flex items-center gap-2"><RefreshCw className="w-4 h-4" />إعادة المحاولة</button>}
    </div>
  );
}
