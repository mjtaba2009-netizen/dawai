import { useContext, useEffect } from 'react';
import { AuthContext } from '@/contexts/AuthContext';
import { useMedicineReminders, useUpdateMedicineReminder } from '@/services/hooks';
import { useToast } from '@/hooks/use-toast';

export function ReminderWatcher() {
  const auth = useContext(AuthContext);
  const { data: reminders = [] } = useMedicineReminders(auth?.user?.id);
  const updateReminder = useUpdateMedicineReminder();
  const { toast } = useToast();

  useEffect(() => {
    if (!auth?.user?.id || reminders.length === 0) return;

    const check = () => {
      const now = Date.now();
      for (const reminder of reminders) {
        if (!reminder.isActive || new Date(reminder.nextReminderAt).getTime() > now) continue;
        const seenKey = `dawai_reminder_seen_${reminder.id}_${reminder.nextReminderAt}`;
        if (localStorage.getItem(seenKey)) continue;
        localStorage.setItem(seenKey, '1');

        const title = `حان وقت إعادة طلب ${reminder.medicationName}`;
        toast({ title, description: reminder.notes || `التنبيه يتكرر كل ${reminder.repeatDays} يوم`, duration: 7000 });
        if ('Notification' in window && Notification.permission === 'granted') {
          try { new Notification('منصة دوائي', { body: title, icon: './logo.png' }); } catch { /* iOS may reject constructor */ }
        }

        const next = new Date(reminder.nextReminderAt);
        next.setDate(next.getDate() + Math.max(1, reminder.repeatDays));
        updateReminder.mutate({ id: reminder.id, updates: { nextReminderAt: next.toISOString() } });
      }
    };

    check();
    const timer = window.setInterval(check, 60_000);
    return () => window.clearInterval(timer);
  }, [auth?.user?.id, reminders, toast, updateReminder]);

  return null;
}
