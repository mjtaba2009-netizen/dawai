import { useContext } from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, ChevronLeft, ShieldCheck } from 'lucide-react';
import { AuthContext } from '@/contexts/AuthContext';

export function Navbar() {
  const { user } = useContext(AuthContext)!;
  const location = useLocation();

  if (!user) return null;

  const owner = user.role === 'owner';
  const vendor = user.role === 'pharmacy' || user.role === 'cosmetic';
  const cosmetic = user.role === 'cosmetic';
  const onOwnerDashboard = location.pathname.startsWith('/owner');
  const onVendorDashboard = location.pathname === '/dashboard';

  // لوحة المالك تمتلك ترويسة واسعة خاصة بها.
  if (owner && onOwnerDashboard) return null;
  if (!owner && !vendor) return null;

  return (
    <motion.div
      initial={{ y: -44, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: 'spring', damping: 25, stiffness: 300, mass: 0.8 }}
      className="sticky top-0 z-40 w-full bg-slate-900/90 backdrop-blur-2xl border-b border-white/10 shadow-[0_8px_30px_rgb(0,0,0,0.18)] pt-[calc(env(safe-area-inset-top)+8px)]"
    >
      <div className="flex items-center justify-between px-4 min-h-11 pb-2">
        <span className="text-slate-300/80 text-xs font-medium tracking-wide">
          {owner ? 'وضع الاستخدام العادي' : cosmetic ? 'حساب كوزمتك' : 'حساب صيدلية'}
        </span>

        {owner ? (
          <Link to="/owner">
            <motion.div
              whileTap={{ scale: 0.93 }}
              whileHover={{ scale: 1.04 }}
              className="flex items-center gap-1.5 bg-amber-400/15 hover:bg-amber-400/25 border border-amber-300/25 px-3 py-1.5 rounded-xl transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
              <span className="text-amber-100 text-xs font-bold whitespace-nowrap">لوحة مالك المنصة</span>
              <ChevronLeft className="w-3 h-3 text-amber-300/60" />
            </motion.div>
          </Link>
        ) : onVendorDashboard ? (
          <div className="flex items-center gap-1.5 text-teal-400">
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span className="text-xs font-bold">لوحة الإدارة</span>
          </div>
        ) : (
          <Link to="/dashboard">
            <motion.div
              whileTap={{ scale: 0.93 }}
              whileHover={{ scale: 1.04 }}
              transition={{ type: 'spring', damping: 20, stiffness: 400 }}
              className="flex items-center gap-1.5 bg-teal-500/20 hover:bg-teal-500/35 border border-teal-400/30 backdrop-blur-sm px-3 py-1.5 rounded-xl transition-colors"
            >
              <LayoutDashboard className="w-3.5 h-3.5 text-teal-300" />
              <span className="text-teal-200 text-xs font-bold whitespace-nowrap">{cosmetic ? 'لوحة إدارة الكوزمتك' : 'لوحة إدارة الصيدلية'}</span>
              <ChevronLeft className="w-3 h-3 text-teal-400/60" />
            </motion.div>
          </Link>
        )}
      </div>
    </motion.div>
  );
}
