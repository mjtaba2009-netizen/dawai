import { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Camera, Star, X } from 'lucide-react';
import { useCreateDispute, useSubmitRating } from '@/services/hooks';
import { useToast } from '@/hooks/use-toast';
import { getErrorMessage } from '@/lib/error';

export function DisputeModal({ orderId, onClose }: { orderId: number; onClose: () => void }) {
  const [reason, setReason] = useState('لم يصلني الطلب');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const mutation = useCreateDispute();
  const { toast } = useToast();
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      await mutation.mutateAsync({ orderId, reason, description, evidenceFile: file });
      toast({ title: 'تم فتح الشكوى', description: 'سيتم إشعارك عند مراجعتها من مالك المنصة.' });
      onClose();
    } catch (error) { toast({ title: 'تعذّر فتح الشكوى', description: getErrorMessage(error), variant: 'destructive' }); }
  };
  return <div className="fixed inset-0 z-[160] bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center" dir="rtl">
    <motion.form initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} onSubmit={submit} className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white p-5 pb-[calc(env(safe-area-inset-bottom)+20px)] shadow-2xl">
      <div className="flex items-center justify-between mb-4"><div className="flex gap-2 items-center"><AlertTriangle className="w-5 h-5 text-red-500" /><h2 className="font-extrabold text-slate-900">مشكلة في الطلب</h2></div><button type="button" onClick={onClose} aria-label="إغلاق"><X className="w-5 h-5" /></button></div>
      <label className="text-xs font-bold text-slate-600">نوع المشكلة<select value={reason} onChange={(e) => setReason(e.target.value)} className="mt-1 w-full h-12 rounded-xl border border-slate-200 px-3 bg-slate-50"><option>لم يصلني الطلب</option><option>المنتج مختلف</option><option>المنتج متضرر</option><option>مشكلة في الدفع</option><option>أخرى</option></select></label>
      <label className="block mt-3 text-xs font-bold text-slate-600">التفاصيل<textarea value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 w-full min-h-24 rounded-xl border border-slate-200 p-3 bg-slate-50" placeholder="اكتب تفاصيل واضحة..." /></label>
      <label className="mt-3 flex items-center justify-center gap-2 min-h-12 rounded-xl border border-dashed border-slate-300 text-sm font-bold text-slate-600 cursor-pointer"><Camera className="w-4 h-4" />{file ? file.name : 'إرفاق صورة للمشكلة (اختياري)'}<input type="file" className="hidden" accept="image/*,application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></label>
      <button disabled={mutation.isPending} className="mt-4 w-full h-12 rounded-xl bg-red-600 text-white font-extrabold disabled:opacity-50">{mutation.isPending ? 'جاري الإرسال...' : 'إرسال الشكوى'}</button>
    </motion.form>
  </div>;
}

function Stars({ value, onChange, label }: { value: number; onChange: (value: number) => void; label: string }) {
  return <div className="flex items-center justify-between rounded-xl bg-slate-50 p-3"><span className="text-xs font-bold text-slate-600">{label}</span><div className="flex" dir="ltr">{[1,2,3,4,5].map((n) => <button type="button" key={n} onClick={() => onChange(n)} aria-label={`${label} ${n} من 5`}><Star className={`w-6 h-6 ${n <= value ? 'fill-amber-400 text-amber-400' : 'text-slate-250'}`} /></button>)}</div></div>;
}

export function RatingModal({ orderId, onClose }: { orderId: number; onClose: () => void }) {
  const [rating, setRating] = useState(5); const [speed, setSpeed] = useState(5); const [packaging, setPackaging] = useState(5); const [match, setMatch] = useState(5); const [comment, setComment] = useState('');
  const mutation = useSubmitRating(); const { toast } = useToast();
  const submit = async (event: React.FormEvent) => { event.preventDefault(); try { await mutation.mutateAsync({ orderId, rating, speedRating: speed, packagingRating: packaging, matchRating: match, comment }); toast({ title: 'شكراً لتقييمك', description: 'سيظهر التقييم بعد المراجعة.' }); onClose(); } catch (error) { toast({ title: 'تعذّر حفظ التقييم', description: getErrorMessage(error), variant: 'destructive' }); } };
  return <div className="fixed inset-0 z-[160] bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center" dir="rtl"><motion.form initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} onSubmit={submit} className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white p-5 pb-[calc(env(safe-area-inset-bottom)+20px)] shadow-2xl"><div className="flex justify-between items-center mb-4"><h2 className="font-extrabold text-slate-900">تقييم الطلب بعد الاستلام</h2><button type="button" onClick={onClose}><X className="w-5 h-5" /></button></div><div className="space-y-2"><Stars label="المتجر" value={rating} onChange={setRating} /><Stars label="سرعة التجهيز" value={speed} onChange={setSpeed} /><Stars label="التغليف" value={packaging} onChange={setPackaging} /><Stars label="مطابقة المنتج" value={match} onChange={setMatch} /></div><textarea value={comment} onChange={(e) => setComment(e.target.value)} className="mt-3 w-full min-h-20 rounded-xl border border-slate-200 p-3" placeholder="تعليق اختياري" /><button disabled={mutation.isPending} className="mt-3 w-full h-12 rounded-xl bg-teal-600 text-white font-extrabold disabled:opacity-50">{mutation.isPending ? 'جاري الحفظ...' : 'حفظ التقييم'}</button></motion.form></div>;
}
