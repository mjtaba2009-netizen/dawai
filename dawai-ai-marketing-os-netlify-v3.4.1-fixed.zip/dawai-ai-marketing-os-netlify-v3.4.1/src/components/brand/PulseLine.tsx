import { motion } from "framer-motion";

/**
 * PulseLine — توقيع الهوية: نبضة ECG رفيعة تُعاد من شاشة البداية إلى داخل التطبيق.
 * تُستعمل كعنصر بصري هادئ (رأس الصفحة، الفواصل) لربط التجربة بلغة حركة واحدة.
 */
export function PulseLine({
  className,
  color = "currentColor",
  width = 120,
  height = 24,
  animate = true,
}: {
  className?: string;
  color?: string;
  width?: number;
  height?: number;
  animate?: boolean;
}) {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 120 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <motion.path
        d="M0 12 H32 L38 4 L46 20 L54 8 L60 12 H120"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={animate ? { pathLength: 0, opacity: 0 } : false}
        animate={animate ? { pathLength: 1, opacity: 1 } : undefined}
        transition={animate ? { duration: 1, ease: "easeInOut" } : undefined}
      />
    </svg>
  );
}
