/**
 * DawaiMark — رمز دوائي الرسمي (من الـ Brand Board v2)
 * علامة «+» طبية بحواف مدوّرة (كبسولة) يمرّ خلالها خطّ نبض عنبري.
 * أُعيد رسمه كـ SVG حي: حاد بأي حجم وقابل للتحريك.
 *
 * ألوان الهوية: Teal #12B3A6 · Teal2 #0FA294 · Deep #0A6A63 · Amber #FFB454
 */
export function DawaiMark({
  size = 64,
  variant = "squircle", // squircle: على خلفية تركوازية | bare: الرمز فقط
  className,
}: {
  size?: number;
  variant?: "squircle" | "bare";
  className?: string;
}) {
  const plusFill = variant === "squircle" ? "#FFFFFF" : "#12B3A6";
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      className={className}
      aria-label="دوائي"
    >
      {variant === "squircle" && (
        <>
          <defs>
            <linearGradient id="dw-sq" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0" stopColor="#2FC4B2" />
              <stop offset="1" stopColor="#0A6A63" />
            </linearGradient>
          </defs>
          <rect x="0" y="0" width="100" height="100" rx="27" fill="url(#dw-sq)" />
        </>
      )}
      {/* علامة + بكبسولتين مدوّرتين */}
      <rect x="40.5" y="24" width="19" height="52" rx="9.5" fill={plusFill} />
      <rect x="24" y="40.5" width="52" height="19" rx="9.5" fill={plusFill} />
      {/* خطّ النبض العنبري */}
      <path
        d="M 27 50 H 41 L 45.5 42.5 L 51 58 L 55 50 H 73"
        stroke="#FFB454"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
