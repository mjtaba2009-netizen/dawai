const CACHE = 'dawai-v3.3-direct-sdk-2026-07-13';
const APP_SHELL = ['/', '/index.html', '/logo.png', '/manifest.webmanifest'];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(Promise.all([
    caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key)))),
    self.clients.claim(),
  ]));
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  // لا نتدخل في ملفات OneSignal مطلقًا؛ يجب أن تصل للشبكة مباشرة ومن دون Cache.
  if (url.pathname.startsWith('/onesignal/') || url.pathname === '/OneSignalSDKWorker.js') return;
  // لا نخزن استجابات Supabase أو أي بيانات خارج نطاق الموقع لحماية الوصفات والحسابات.
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request, { cache: 'no-store' })
        .then((response) => {
          if (response.ok) caches.open(CACHE).then((cache) => cache.put('/index.html', response.clone()));
          return response;
        })
        .catch(() => caches.match('/index.html')),
    );
    return;
  }

  const cacheable = ['script', 'style', 'image', 'font', 'manifest'].includes(request.destination);
  if (!cacheable) return;

  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request).then((response) => {
        if (response.ok) caches.open(CACHE).then((cache) => cache.put(request, response.clone()));
        return response;
      });
      return cached || network;
    }),
  );
});
