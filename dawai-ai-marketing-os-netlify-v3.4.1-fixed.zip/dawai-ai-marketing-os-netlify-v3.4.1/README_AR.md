# منصة دوائي 3.3 — إصلاح الإشعارات والفحص الشامل

هذا الإصدار يعالج مهلة OneSignal على iPhone PWA، ويثبت حركة مفاتيح الإعدادات، ويحوّل أقسام الحساب التي كانت شكلية إلى عمليات Supabase فعلية.

## ترتيب النشر

1. شغّل `dawai-v3.3-profile-security-copy.txt` في Supabase SQL Editor مرة واحدة.
2. أبقِ Edge Function الحالية `send-onesignal-notification` منشورة، والأسرار:
   - `ONESIGNAL_APP_ID`
   - `ONESIGNAL_API_KEY`
3. ارفع ملف Netlify الجاهز يدويًا.
4. على iPhone احذف اختصار دوائي القديم وبيانات الموقع، ثم أضف الموقع إلى الشاشة الرئيسية من جديد.
5. افتح دوائي من الأيقونة، انتظر اكتمال تحميل الصفحة، ثم افتح إعدادات الإشعارات واضغط التفعيل.

## إعداد OneSignal Web

- Service worker path: `/onesignal/`
- Filename: `OneSignalSDKWorker.js`
- Scope: `/onesignal/`

## أهم الإصلاحات

- تهيئة OneSignal بالخلفية حسب توصيات React SDK.
- استخدام `OneSignal.Notifications.requestPermission()` بدل طلب المتصفح المباشر.
- إزالة التسجيل اليدوي المتعارض لعامل OneSignal.
- منع PWA cache worker من اعتراض ملفات OneSignal.
- زر نسخ تفاصيل تشخيص الإشعارات.
- إصلاح حركة جميع مفاتيح التبديل المستهدفة باستخدام محور Transform ثابت.
- حفظ الملف الشخصي والعنوان والهاتف وكلمة المرور والتقييمات فعليًا.
- معالجة أخطاء Supabase دون إظهار `[object Object]`.

## الفحص

راجع `dawai-v3.3-test-report-ar.md`. تم اجتياز البناء و39 فحصًا ثابتًا وأمنيًا، و`npm audit` لم يجد ثغرات معروفة. اختبار وصول Push الحقيقي يحتاج النشر وجهاز iPhone فعلي لأن بيئة البناء لا تستطيع منح إذن إشعارات Apple أو الاتصال بحساب Supabase الخاص بك.
