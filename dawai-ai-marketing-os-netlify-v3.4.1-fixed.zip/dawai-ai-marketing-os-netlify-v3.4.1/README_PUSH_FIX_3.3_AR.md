# دوائي 3.3 — إصلاح تهيئة OneSignal على iPhone PWA

## ما تغيّر

- إزالة الاعتماد على حزمة `react-onesignal` من مسار التشغيل.
- تحميل OneSignal Web SDK الرسمي مباشرة من الصفحة وفق نمط `OneSignalDeferred` الرسمي.
- بدء تهيئة SDK قبل تشغيل React حتى تكون الخدمة جاهزة قبل ضغطة المستخدم.
- الإبقاء على عامل OneSignal المخصص في:
  - `/onesignal/OneSignalSDKWorker.js`
  - النطاق `/onesignal/`
- إضافة زر **إصلاح الإشعارات** لتنظيف تسجيلات OneSignal القديمة فقط دون حذف بيانات حساب دوائي.
- إضافة مشاركة وعرض تفاصيل الفحص بدل الاعتماد على Clipboard فقط.
- إضافة أيقونات PWA بالأحجام 192 و256 و384 و512.

## بعد رفع الإصدار

1. افتح دوائي من أيقونة الشاشة الرئيسية.
2. افتح إعدادات الإشعارات.
3. إذا ظهر خطأ قديم، اضغط **إصلاح الإشعارات** مرة واحدة.
4. سيعاد تحميل التطبيق تلقائيًا.
5. انتظر 5 إلى 10 ثوانٍ ثم اضغط **تفعيل الإشعارات الآن**.

## إعداد OneSignal المطلوب

- Path to service worker files: `/onesignal/`
- Service worker filename: `OneSignalSDKWorker.js`
- Service worker registration scope: `/onesignal/`
- Site URL: `https://aesthetic-syrniki-550b9a.netlify.app`

لا يحتاج هذا الإصدار إلى SQL جديد أو إعادة نشر Edge Function.
