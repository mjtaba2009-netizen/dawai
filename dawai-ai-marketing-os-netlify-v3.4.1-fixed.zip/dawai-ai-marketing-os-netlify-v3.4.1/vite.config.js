import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
var __dirname = path.dirname(fileURLToPath(import.meta.url));
// Netlify performs a production build and does not provide a dev-server PORT.
// This config intentionally has no PORT requirement.
export default defineConfig({
    plugins: [react(), tailwindcss()],
    resolve: {
        alias: {
            '@': path.resolve(__dirname, './src'),
        },
    },
    base: '/',
    build: {
        outDir: 'dist',
        sourcemap: false,
        rollupOptions: {
            output: {
                manualChunks: function (id) {
                    if (!id.includes('node_modules'))
                        return undefined;
                    if (id.includes('/react/') ||
                        id.includes('/react-dom/') ||
                        id.includes('/react-router') ||
                        id.includes('/scheduler/'))
                        return 'react-core';
                    if (id.includes('@supabase'))
                        return 'supabase';
                    if (id.includes('@tanstack'))
                        return 'query';
                    if (id.includes('framer-motion'))
                        return 'motion';
                    if (id.includes('lucide-react'))
                        return 'icons';
                    return undefined;
                },
            },
        },
    },
});
